"use client";

import SiteFrame from "./SiteFrame";
import { mediaUrl } from "../lib/media";
import { useSiteContent } from "../lib/use-site-content";

export default function PortfolioPageContent() {
  const content = useSiteContent().portfolio;

  return (
    <SiteFrame current="portfolio">
      <main className="subpage portfolio-page reference-page portfolio-gallery-page">
        <div className="reference-layout">
          <header className="reference-side">
            <h1 className="reference-title preserve-lines">{content.title}</h1>
            <p>{content.description}</p>
          </header>

          <section className="reference-content" aria-label={content.eyebrow}>
            <div className="portfolio-image-grid">
              {content.projects.map((project, index) => (
                <a className={`portfolio-image-link ${project.shape}`} href={`/portfolio/${project.slug}`} key={project.id} aria-label={`${project.title} 상세 보기`}>
                  <figure>
                    <img src={mediaUrl(project.coverSlot)} alt="" loading={index < 2 ? "eager" : "lazy"} />
                  </figure>
                  <span className="portfolio-hover-mark" aria-hidden="true">↗</span>
                </a>
              ))}
            </div>
          </section>
        </div>
      </main>
    </SiteFrame>
  );
}
