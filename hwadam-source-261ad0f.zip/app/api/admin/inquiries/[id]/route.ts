import { updateInquiryStatus } from "../../../../../db/repositories";
import type { InquiryStatus } from "../../../../../lib/admin.types";
import { getAuthorizedAdministrator } from "../../../../../lib/admin-server";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const administrator = await getAuthorizedAdministrator(request);
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  try {
    const { id } = await params;
    const payload = (await request.json()) as { status?: InquiryStatus };
    if (!payload.status) throw new Error("변경할 문의 상태를 선택해 주세요.");
    await updateInquiryStatus(id, payload.status);
    return Response.json({ id, status: payload.status });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "문의 상태를 변경하지 못했습니다." },
      { status: 400 },
    );
  }
}
