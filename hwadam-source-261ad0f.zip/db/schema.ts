import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const administrators = sqliteTable("administrators", {
  userId: text("user_id").primaryKey(),
  email: text("email").notNull(),
  displayName: text("display_name").notNull(),
  role: text("role").notNull().default("owner"),
  createdAt: text("created_at").notNull(),
  lastLoginAt: text("last_login_at").notNull(),
});

export const pricingCatalogs = sqliteTable(
  "pricing_catalogs",
  {
    id: text("id").primaryKey(),
    version: text("version").notNull(),
    catalogJson: text("catalog_json").notNull(),
    isActive: integer("is_active").notNull().default(1),
    updatedBy: text("updated_by").notNull(),
    updatedAt: text("updated_at").notNull(),
  },
  (table) => [index("idx_pricing_catalogs_active_updated").on(table.isActive, table.updatedAt)],
);

export const estimateInquiries = sqliteTable(
  "estimate_inquiries",
  {
    id: text("id").primaryKey(),
    status: text("status").notNull().default("new"),
    createdAt: text("created_at").notNull(),
    updatedAt: text("updated_at").notNull(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    postcode: text("postcode").notNull().default(""),
    baseAddress: text("base_address").notNull().default(""),
    detailAddress: text("detail_address").notNull().default(""),
    city: text("city").notNull(),
    district: text("district").notNull(),
    neighborhood: text("neighborhood").notNull(),
    constructionSchedule: text("construction_schedule").notNull(),
    privacyAgreedAt: text("privacy_agreed_at").notNull(),
    spaceType: text("space_type").notNull(),
    area: integer("area").notNull(),
    selectionsJson: text("selections_json").notNull(),
    midpoint: integer("midpoint").notNull(),
    minimum: integer("minimum").notNull(),
    maximum: integer("maximum").notNull(),
    breakdownJson: text("breakdown_json").notNull(),
    selectedCount: integer("selected_count").notNull(),
    catalogVersion: text("catalog_version").notNull(),
  },
  (table) => [
    index("idx_estimate_inquiries_status_created").on(table.status, table.createdAt),
    index("idx_estimate_inquiries_created").on(table.createdAt),
  ],
);

export const siteMedia = sqliteTable("site_media", {
  slotId: text("slot_id").primaryKey(),
  objectKey: text("object_key").notNull(),
  contentType: text("content_type").notNull(),
  originalName: text("original_name").notNull(),
  size: integer("size").notNull(),
  updatedBy: text("updated_by").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const siteContent = sqliteTable("site_content", {
  id: text("id").primaryKey(),
  version: integer("version").notNull().default(1),
  contentJson: text("content_json").notNull(),
  updatedBy: text("updated_by").notNull(),
  updatedAt: text("updated_at").notNull(),
});
