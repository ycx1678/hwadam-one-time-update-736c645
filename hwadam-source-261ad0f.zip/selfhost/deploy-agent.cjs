const crypto = require("node:crypto");
const fs = require("node:fs");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");

const projectRoot = path.resolve(__dirname, "..");
const deploymentPath = "/__hwadam-deploy";
const deploymentStatusPath = `${deploymentPath}/status`;
const statusFilePath = path.join(__dirname, ".last-deploy-status.json");
const repository = "FlashStudio-KR/hwadam";
const audience = "hwadam-minipc-deploy";
const allowedWorkflow = `${repository}/.github/workflows/deploy-mini-pc.yml@refs/heads/main`;
const port = Number.parseInt(process.env.HWADAM_DEPLOY_AGENT_PORT || "3010", 10);
const maxArchiveBytes = 80 * 1024 * 1024;
const maxTokenAgeSeconds = 5 * 60;
const powerShellPath = path.join(
  process.env.SystemRoot || process.env.WINDIR || "C:\\Windows",
  "System32",
  "WindowsPowerShell",
  "v1.0",
  "powershell.exe",
);
let deploymentRunning = false;
let keyCache = { expiresAt: 0, keys: [] };

function decodeJson(value) {
  return JSON.parse(Buffer.from(value, "base64url").toString("utf8"));
}

async function getGithubActionsKeys() {
  if (Date.now() < keyCache.expiresAt && keyCache.keys.length > 0) {
    return keyCache.keys;
  }
  const response = await fetch("https://token.actions.githubusercontent.com/.well-known/jwks");
  if (!response.ok) {
    throw new Error(`GitHub Actions 공개 키를 읽지 못했습니다. (${response.status})`);
  }
  const payload = await response.json();
  keyCache = { expiresAt: Date.now() + 60 * 60 * 1000, keys: payload.keys || [] };
  return keyCache.keys;
}

async function verifyActionsToken(token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) throw new Error("배포 인증 형식이 올바르지 않습니다.");

  const header = decodeJson(parts[0]);
  const claims = decodeJson(parts[1]);
  if (header.alg !== "RS256" || !header.kid) throw new Error("지원하지 않는 배포 인증서입니다.");

  const signingInput = Buffer.from(`${parts[0]}.${parts[1]}`);
  const signature = Buffer.from(parts[2], "base64url");
  const key = (await getGithubActionsKeys()).find((candidate) => candidate.kid === header.kid);
  if (!key) throw new Error("배포 인증서 공개 키를 찾지 못했습니다.");
  const validSignature = crypto.verify("RSA-SHA256", signingInput, crypto.createPublicKey({ key, format: "jwk" }), signature);
  if (!validSignature) throw new Error("배포 인증서 서명이 일치하지 않습니다.");

  const now = Math.floor(Date.now() / 1000);
  const tokenAudience = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
  if (claims.iss !== "https://token.actions.githubusercontent.com") throw new Error("신뢰할 수 없는 배포 발급자입니다.");
  if (!tokenAudience.includes(audience)) throw new Error("배포 대상이 일치하지 않습니다.");
  if (!claims.exp || claims.exp < now || (claims.nbf && claims.nbf > now)) throw new Error("만료된 배포 인증서입니다.");
  if (claims.repository !== repository || claims.ref !== "refs/heads/main") throw new Error("허용되지 않은 저장소 또는 브랜치입니다.");
  if (claims.workflow_ref !== allowedWorkflow || claims.event_name !== "workflow_dispatch") {
    throw new Error("수동 미니PC 배포 워크플로에서만 실행할 수 있습니다.");
  }
}

function verifyManualSignature(timestamp, signature, archive) {
  const secret = process.env.HWADAM_DEPLOY_SECRET || "";
  if (!secret) throw new Error("수동 배포 키가 설정되지 않았습니다.");
  if (!/^\d+$/.test(String(timestamp || ""))) throw new Error("수동 배포 시각이 올바르지 않습니다.");
  const timestampSeconds = Number.parseInt(timestamp, 10);
  if (Math.abs(Date.now() - timestampSeconds * 1000) > maxTokenAgeSeconds * 1000) {
    throw new Error("수동 배포 요청이 만료되었습니다.");
  }
  const suppliedSignature = String(signature || "").replace(/^sha256=/, "");
  if (!/^[a-f0-9]{64}$/i.test(suppliedSignature)) throw new Error("수동 배포 서명이 올바르지 않습니다.");
  const expectedSignature = crypto.createHmac("sha256", secret).update(`${timestamp}.`).update(archive).digest("hex");
  const supplied = Buffer.from(suppliedSignature, "hex");
  const expected = Buffer.from(expectedSignature, "hex");
  if (!crypto.timingSafeEqual(supplied, expected)) throw new Error("수동 배포 서명이 일치하지 않습니다.");
}

function verifyManualStatusSignature(timestamp, signature) {
  const secret = process.env.HWADAM_DEPLOY_SECRET || "";
  if (!secret) throw new Error("수동 배포 키가 설정되지 않았습니다.");
  if (!/^\d+$/.test(String(timestamp || ""))) throw new Error("상태 조회 시각이 올바르지 않습니다.");
  const timestampSeconds = Number.parseInt(timestamp, 10);
  if (Math.abs(Date.now() - timestampSeconds * 1000) > maxTokenAgeSeconds * 1000) {
    throw new Error("상태 조회 요청이 만료되었습니다.");
  }
  const suppliedSignature = String(signature || "").replace(/^sha256=/, "");
  if (!/^[a-f0-9]{64}$/i.test(suppliedSignature)) throw new Error("상태 조회 서명이 올바르지 않습니다.");
  const expectedSignature = crypto.createHmac("sha256", secret).update(`${timestamp}.status`).digest("hex");
  const supplied = Buffer.from(suppliedSignature, "hex");
  const expected = Buffer.from(expectedSignature, "hex");
  if (!crypto.timingSafeEqual(supplied, expected)) throw new Error("상태 조회 서명이 일치하지 않습니다.");
}

function readDeploymentStatus() {
  const fallback = {
    state: "unknown",
    updatedAt: null,
    message: "아직 기록된 배포 상태가 없습니다.",
    errorLog: "",
  };
  try {
    const stored = JSON.parse(fs.readFileSync(statusFilePath, "utf8").replace(/^\uFEFF/, ""));
    const errorLogPath = path.join(os.homedir(), ".pm2", "logs", "hwadam-site-error.log");
    const errorLog = fs.existsSync(errorLogPath)
      ? fs.readFileSync(errorLogPath, "utf8").split(/\r?\n/).slice(-36).join("\n").slice(-4000)
      : "";
    return { ...fallback, ...stored, errorLog };
  } catch {
    return fallback;
  }
}

function writeDeploymentStatus(state, message) {
  fs.writeFileSync(
    statusFilePath,
    JSON.stringify({ state, message: String(message).slice(0, 1200), updatedAt: new Date().toISOString() }),
    { mode: 0o600 },
  );
}

function reply(response, statusCode, message) {
  response.writeHead(statusCode, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
  response.end(JSON.stringify({ ok: statusCode >= 200 && statusCode < 300, message }));
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    const declaredLength = Number.parseInt(request.headers["content-length"] || "0", 10);
    if (declaredLength > maxArchiveBytes) {
      reject(new Error("배포 파일이 최대 크기를 넘었습니다."));
      request.resume();
      return;
    }
    let totalBytes = 0;
    const chunks = [];
    request.on("data", (chunk) => {
      totalBytes += chunk.length;
      if (totalBytes > maxArchiveBytes) {
        reject(new Error("배포 파일이 최대 크기를 넘었습니다."));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on("end", () => resolve(Buffer.concat(chunks)));
    request.on("error", reject);
  });
}

const server = http.createServer(async (request, response) => {
  const requestPath = new URL(request.url, "http://localhost").pathname;
  // 기존 Caddy 설정은 정확히 /__hwadam-deploy 경로만 수신기로 전달합니다.
  // 따라서 상태 조회도 별도 하위 경로 대신 이 헤더를 사용해 같은 경로에서 처리합니다.
  if (request.method === "POST" && requestPath === deploymentPath && request.headers["x-hwadam-status"] === "1") {
    try {
      verifyManualStatusSignature(request.headers["x-hwadam-timestamp"], request.headers["x-hwadam-signature"]);
      reply(response, 200, readDeploymentStatus());
    } catch {
      reply(response, 401, "상태 조회가 인증되지 않았습니다.");
    }
    return;
  }
  if (request.method === "GET" && requestPath === deploymentStatusPath) {
    try {
      verifyManualStatusSignature(request.headers["x-hwadam-timestamp"], request.headers["x-hwadam-signature"]);
      reply(response, 200, readDeploymentStatus());
    } catch {
      reply(response, 401, "상태 조회가 인증되지 않았습니다.");
    }
    return;
  }
  if (request.method !== "POST" || requestPath !== deploymentPath) {
    reply(response, 404, "Not found");
    return;
  }
  if (deploymentRunning) {
    reply(response, 409, "A deployment is already running.");
    return;
  }

  try {
    const authorization = request.headers.authorization || "";
    const token = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
    const githubActionsRequest = Boolean(token);
    if (githubActionsRequest) await verifyActionsToken(token);
    const archive = await readRequestBody(request);
    if (!githubActionsRequest) {
      verifyManualSignature(request.headers["x-hwadam-timestamp"], request.headers["x-hwadam-signature"], archive);
    }
    if (archive.length < 4 || archive.subarray(0, 2).toString("utf8") !== "PK") {
      throw new Error("올바른 ZIP 배포 파일이 아닙니다.");
    }

    const archivePath = path.join(os.tmpdir(), `hwadam-manual-deploy-${Date.now()}.zip`);
    fs.writeFileSync(archivePath, archive, { mode: 0o600 });
    deploymentRunning = true;
    writeDeploymentStatus("running", "미니PC가 배포 파일을 적용하고 있습니다.");
    const child = spawn(
      powerShellPath,
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path.join(__dirname, "deploy-from-upload.ps1"), "-ArchivePath", archivePath],
      { cwd: projectRoot, detached: true, stdio: "ignore", windowsHide: true }
    );
    child.unref();
    child.on("exit", (code) => {
      deploymentRunning = false;
      if (code !== 0) writeDeploymentStatus("failed", `배포 스크립트가 종료 코드 ${code}로 끝났습니다.`);
      console.log(`[deploy-agent] deployment finished with code ${code}`);
    });
    child.on("error", (error) => {
      deploymentRunning = false;
      writeDeploymentStatus("failed", `배포 스크립트를 시작하지 못했습니다: ${error.message}`);
      console.error(`[deploy-agent] deployment start failed: ${error.message}`);
    });
    console.log(`[deploy-agent] verified ${githubActionsRequest ? "GitHub Actions" : "manual"} deployment accepted`);
    reply(response, 202, "Deployment accepted.");
  } catch (error) {
    console.error(`[deploy-agent] rejected deployment: ${error.message}`);
    reply(response, 401, "Deployment was not authorized.");
  }
});

server.requestTimeout = 10 * 60 * 1000;
server.listen(port, "127.0.0.1", () => {
  console.log(`[deploy-agent] listening on 127.0.0.1:${port}`);
});
