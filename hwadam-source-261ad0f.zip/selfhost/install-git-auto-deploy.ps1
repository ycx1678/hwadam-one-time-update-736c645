param(
  [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"

if (-not $ProjectRoot) {
  $ProjectRoot = Split-Path -Parent $PSScriptRoot
}
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$repository = "FlashStudio-KR/hwadam"
$autoDeployPath = Join-Path $ProjectRoot "selfhost\auto-deploy.ps1"

if (-not (Get-Command gh.exe -ErrorAction SilentlyContinue)) {
  throw "GitHub CLI가 없습니다. 먼저 'winget install --id GitHub.cli'를 실행해 주세요."
}
if (-not (Get-Command git.exe -ErrorAction SilentlyContinue)) {
  throw "Git이 없습니다. Git for Windows를 설치한 뒤 다시 실행해 주세요."
}

& gh.exe auth status --hostname github.com
if ($LASTEXITCODE -ne 0) {
  throw "GitHub 로그인이 필요합니다. 먼저 'gh auth login'을 실행해 주세요."
}

Write-Host "GitHub 로그인 방식의 자동 배포를 설치합니다."
& gh.exe auth setup-git
if ($LASTEXITCODE -ne 0) { throw "GitHub Git 인증 연결에 실패했습니다." }

# The installer can be run from a temporary clone. Copy it into the live site
# before the first force deployment so later updates use the same version.
Copy-Item -LiteralPath (Join-Path $PSScriptRoot "auto-deploy.ps1") -Destination $autoDeployPath -Force

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $autoDeployPath -Force -UseGitHubCli
if ($LASTEXITCODE -ne 0) { throw "첫 배포에 실패했습니다." }

$taskName = "Hwadam Auto Deploy"
$taskAction = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$autoDeployPath`" -UseGitHubCli"
& schtasks.exe /Create /TN $taskName /SC MINUTE /MO 5 /TR $taskAction /F | Out-Null
if ($LASTEXITCODE -ne 0) { throw "5분 자동 배포 작업 등록에 실패했습니다." }

Write-Host "설치 완료: 토큰 없이 GitHub 로그인 권한으로 5분마다 최신 버전을 반영합니다."
