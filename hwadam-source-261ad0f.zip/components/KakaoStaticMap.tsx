"use client";

import { useEffect, useRef, useState } from "react";

// JavaScript keys are designed to be delivered to the browser. This key is
// restricted by the registered Kakao JavaScript SDK domains.
const KAKAO_MAP_APP_KEY = "75bc8d880249fa7afbcc80733542cd5d";
const KAKAO_SDK_URL = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${KAKAO_MAP_APP_KEY}&autoload=false&libraries=services`;
const KAKAO_SDK_ID = "hwadam-kakao-map-sdk";

type KakaoMapNamespace = {
  maps: {
    load(callback: () => void): void;
    LatLng: new (latitude: number, longitude: number) => unknown;
    StaticMap: new (container: HTMLElement, options: {
      center: unknown;
      level: number;
      marker: { position: unknown };
    }) => unknown;
    services: {
      Geocoder: new () => {
        addressSearch(address: string, callback: (result: Array<{ x: string; y: string }>, status: string) => void): void;
      };
      Status: { OK: string };
    };
  };
};

function getKakaoMapNamespace() {
  return (window as unknown as { kakao?: KakaoMapNamespace }).kakao;
}

function loadKakaoMapSdk() {
  if (getKakaoMapNamespace()?.maps?.load) return Promise.resolve();

  return new Promise<void>((resolve, reject) => {
    const existing = document.getElementById(KAKAO_SDK_ID) as HTMLScriptElement | null;
    const script = existing ?? document.createElement("script");

    const complete = () => resolve();
    const failed = () => reject(new Error("카카오 지도 SDK를 불러오지 못했습니다."));

    script.addEventListener("load", complete, { once: true });
    script.addEventListener("error", failed, { once: true });

    if (!existing) {
      script.id = KAKAO_SDK_ID;
      script.src = KAKAO_SDK_URL;
      script.async = true;
      document.head.appendChild(script);
    }
  });
}

function mapSearchAddress(address: string) {
  // 층·호수는 지도 좌표 검색에 필요하지 않아 제외합니다.
  return address.replace(/\s+\d+층.*$/, "").trim();
}

export default function KakaoStaticMap({ address }: { address: string }) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<"loading" | "ready" | "failed">("loading");

  useEffect(() => {
    let cancelled = false;
    const container = mapRef.current;
    if (!container || !address) return;

    async function renderMap() {
      try {
        await loadKakaoMapSdk();
        if (cancelled || !getKakaoMapNamespace()?.maps) return;

        getKakaoMapNamespace()?.maps.load(() => {
          const kakao = getKakaoMapNamespace();
          if (cancelled || !kakao?.maps || !container) return;

          const { maps } = kakao;
          const geocoder = new maps.services.Geocoder();
          geocoder.addressSearch(mapSearchAddress(address), (result, status) => {
            if (cancelled || status !== maps.services.Status.OK || !result[0]) {
              if (!cancelled) setState("failed");
              return;
            }

            const position = new maps.LatLng(Number(result[0].y), Number(result[0].x));
            container.replaceChildren();
            new maps.StaticMap(container, {
              center: position,
              level: 3,
              marker: { position },
            });
            setState("ready");
          });
        });
      } catch {
        if (!cancelled) setState("failed");
      }
    }

    renderMap();
    return () => { cancelled = true; };
  }, [address]);

  return (
    <div className="location-map-frame">
      <div ref={mapRef} className="location-kakao-static-map" aria-label="화담아이디 찾아오는 길 지도" />
      {state === "loading" && <p className="location-map-status">지도를 불러오는 중입니다.</p>}
      {state === "failed" && <p className="location-map-status">지도를 불러오지 못했습니다.</p>}
    </div>
  );
}
