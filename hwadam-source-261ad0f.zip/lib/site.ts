export const SITE_NAME = "화담아이디";
export const SITE_TITLE = "화담아이디 | 상업 인테리어 간편 견적";
export const SITE_DESCRIPTION =
  "카페, 음식점, 사무실, 매장 인테리어의 예상 범위를 직접 계산해 보세요. 현장 중심 상업공간 인테리어, 화담아이디.";
export const SITE_INSTAGRAM_URL = "https://www.instagram.com/hwadam_id/";
export const SITE_KEYWORDS = [
  "상업 인테리어",
  "카페 인테리어",
  "음식점 인테리어",
  "사무실 인테리어",
  "매장 인테리어",
  "인테리어 견적",
  "화담아이디",
] as const;
