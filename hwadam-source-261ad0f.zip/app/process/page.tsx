import type { Metadata } from "next";
import ProcessPageContent from "../../components/ProcessPageContent";

export const metadata: Metadata = {
  title: "프로젝트 진행 과정",
  description: "상담, 현장 실측, 설계, 시공, 마감까지 화담아이디의 상업 인테리어 진행 과정을 안내합니다.",
  alternates: { canonical: "/process" },
  openGraph: {
    title: "프로젝트 진행 과정 | 화담아이디",
    description: "공간의 쓰임을 이해하고 현장에서 완성하는 화담아이디의 작업 과정입니다.",
    url: "/process",
  },
};

export default function ProcessPage() {
  return <ProcessPageContent />;
}
