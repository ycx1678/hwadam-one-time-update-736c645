param(
  [string]$ProjectRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"
$repository = "FlashStudio-KR/hwadam"
$temporaryRoot = Join-Path $env:TEMP "hwadam-auto-deploy-installer"

if (-not (Get-Command gh.exe -ErrorAction SilentlyContinue)) {
  throw "GitHub CLI가 없습니다. 먼저 'winget install --id GitHub.cli'를 실행해 주세요."
}

& gh.exe auth status --hostname github.com
if ($LASTEXITCODE -ne 0) {
  throw "GitHub 로그인이 필요합니다. 먼저 'gh auth login'을 실행해 주세요."
}

Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
& gh.exe repo clone $repository $temporaryRoot -- --depth 1
if ($LASTEXITCODE -ne 0) { throw "자동 배포 설치 파일을 내려받지 못했습니다." }

$installer = Join-Path $temporaryRoot "selfhost\install-git-auto-deploy.ps1"
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $installer -ProjectRoot $ProjectRoot
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
