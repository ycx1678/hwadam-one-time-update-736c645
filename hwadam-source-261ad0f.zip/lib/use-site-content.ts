"use client";

import { useEffect, useState } from "react";
import { DEFAULT_SITE_CONTENT, type SiteContent } from "./site-content";

export function useSiteContent() {
  const [content, setContent] = useState<SiteContent>(DEFAULT_SITE_CONTENT);

  useEffect(() => {
    let active = true;
    fetch("/api/content", { cache: "no-store" })
      .then((response) => response.json() as Promise<{ content?: SiteContent }>)
      .then((payload) => {
        if (active && payload.content) setContent(payload.content);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  return content;
}
