@echo off
setlocal
set "BOOTSTRAP_ROOT=%~dp0."
set "PROJECT_ROOT=%BOOTSTRAP_ROOT%"

rem When the ZIP was extracted beside the live site package, find that common folder automatically.
if not exist "%PROJECT_ROOT%\selfhost\.env" set "PROJECT_ROOT=%USERPROFILE%\Desktop\hwadam-mini-pc-one-click-package"
if not exist "%PROJECT_ROOT%\selfhost\.env" (
  echo [ERROR] Live site folder was not found.
  echo Extract this ZIP into the live site folder, then run this file again.
  echo Expected: %USERPROFILE%\Desktop\hwadam-mini-pc-one-click-package
  echo.
  pause
  exit /b 1
)

copy /Y "%BOOTSTRAP_ROOT%\selfhost\ecosystem.config.cjs" "%PROJECT_ROOT%\selfhost\ecosystem.config.cjs" >nul
copy /Y "%BOOTSTRAP_ROOT%\selfhost\deploy-agent.cjs" "%PROJECT_ROOT%\selfhost\deploy-agent.cjs" >nul
copy /Y "%BOOTSTRAP_ROOT%\selfhost\deploy-from-upload.ps1" "%PROJECT_ROOT%\selfhost\deploy-from-upload.ps1" >nul
copy /Y "%BOOTSTRAP_ROOT%\selfhost\install-manual-deploy.ps1" "%PROJECT_ROOT%\selfhost\install-manual-deploy.ps1" >nul
copy /Y "%BOOTSTRAP_ROOT%\selfhost\manual-deploy-secret.txt" "%PROJECT_ROOT%\selfhost\manual-deploy-secret.txt" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PROJECT_ROOT%\selfhost\install-manual-deploy.ps1" -ProjectRoot "%PROJECT_ROOT%"
echo.
pause
