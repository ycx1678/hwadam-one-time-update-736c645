import assert from "node:assert/strict";
import test from "node:test";
import { calculateEstimate, DEFAULT_PRICING_CATALOG } from "../lib/estimate.ts";
import { createEstimateInquiryDraft } from "../lib/inquiry.ts";
import { createServerInquiryDraft } from "../lib/inquiry-server.ts";
import { applyPricingAdminUpdate } from "../lib/pricing-admin.ts";
import { createPasswordRecord, createSessionToken, verifyPasswordRecord, verifySessionToken } from "../lib/admin-auth-crypto.ts";
import { MEDIA_SLOTS, isPortfolioMediaSlot, mediaUrl, portfolioCoverSlot, portfolioGallerySlot } from "../lib/media.ts";
import { DEFAULT_SITE_CONTENT, normalizeSiteContent } from "../lib/site-content.ts";

test("20평 음식점 예시 견적을 10만원 단위로 계산한다", () => {
  const result = calculateEstimate({
    spaceType: "restaurant",
    area: 20,
    selections: {
      demolition: "partial",
      paint: "all",
      floor: "deco",
      electric: "basic",
    },
  });

  assert.equal(result.midpoint, 11_800_000);
  assert.equal(result.minimum, 10_600_000);
  assert.equal(result.maximum, 13_000_000);
  assert.equal(result.selectedCount, 4);
  assert.equal(result.catalogVersion, "2026.08.1");
});

test("면적 범위와 공정 선택을 검증한다", () => {
  assert.throws(
    () => calculateEstimate({ spaceType: "shop", area: 2, selections: { paint: "wall" } }),
    /3평부터 500평/,
  );
  assert.throws(
    () => calculateEstimate({ spaceType: "shop", area: 20, selections: {} }),
    /한 가지 이상의 공정/,
  );
});

test("관리자 단가표와 같은 데이터 구조를 계산기에 주입할 수 있다", () => {
  const catalog = {
    ...DEFAULT_PRICING_CATALOG,
    version: "admin-test",
    managementCostPerPyeong: 0,
    spaceTypes: [
      { id: "shop", label: "매장", multiplier: 1, description: "테스트 매장" },
    ],
    processGroups: [
      {
        id: "paint",
        label: "페인트",
        description: "테스트 공정",
        options: [{ id: "wall", label: "벽만", amount: 100_000, mode: "perPyeong" }],
      },
    ],
  };

  const result = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { paint: "wall" } },
    catalog,
  );

  assert.equal(result.midpoint, 1_000_000);
  assert.equal(result.catalogVersion, "admin-test");
});

test("같은 공정 안의 여러 옵션을 동시에 선택해 합산한다", () => {
  const catalog = {
    ...DEFAULT_PRICING_CATALOG,
    managementCostPerPyeong: 0,
    businessMarginRate: 0,
    spaceTypes: [{ id: "shop", label: "매장", multiplier: 1, description: "테스트 매장" }],
    processGroups: [{
      id: "paint",
      label: "페인트",
      description: "테스트 공정",
      options: [
        { id: "wall", label: "벽", amount: 100_000, mode: "perPyeong" },
        { id: "ceiling", label: "천장", amount: 50_000, mode: "perPyeong" },
      ],
    }],
  };

  const result = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { paint: ["wall", "ceiling"] } },
    catalog,
  );

  assert.equal(result.selectedCount, 2);
  assert.equal(result.midpoint, 1_500_000);
  assert.deepEqual(result.breakdown.slice(0, 2).map((item) => item.detail), ["벽", "천장"]);
});

test("고객 문의 초안을 서버 전송용 스키마로 정규화한다", () => {
  const estimateInput = {
    spaceType: "shop",
    area: 10,
    selections: { paint: "wall" },
  };
  const estimateResult = calculateEstimate(estimateInput);
  const draft = createEstimateInquiryDraft({
    contact: {
      name: " 홍길동 ",
      phone: "010-1234-5678",
      address: {
        postcode: " 04047 ",
        baseAddress: " 서울특별시 마포구 양화로 45 ",
        detailAddress: " 3층 ",
        city: " 서울 ",
        district: " 마포구 ",
        neighborhood: " 서교동 ",
      },
      constructionSchedule: "3개월 이내",
    },
    privacyAgreed: true,
    estimateInput,
    estimateResult,
    now: new Date("2026-08-13T00:00:00.000Z"),
  });

  assert.equal(draft.createdAt, "2026-08-13T00:00:00.000Z");
  assert.equal(draft.contact.name, "홍길동");
  assert.equal(draft.contact.phone, "01012345678");
  assert.deepEqual(draft.contact.address, {
    postcode: "04047",
    baseAddress: "서울특별시 마포구 양화로 45",
    detailAddress: "3층",
    city: "서울",
    district: "마포구",
    neighborhood: "서교동",
  });
  assert.equal(draft.estimate.result.catalogVersion, "2026.08.1");
});

test("관리자가 변경한 단가를 새 버전의 단가표로 만든다", () => {
  const updated = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 70_000,
      businessMarginRate: 0.1,
      estimateRangeRate: 0.12,
      spaceTypes: structuredClone(DEFAULT_PRICING_CATALOG.spaceTypes),
      processGroups: structuredClone(DEFAULT_PRICING_CATALOG.processGroups),
    },
    new Date("2026-08-13T00:00:00.000Z"),
  );

  assert.equal(updated.version, "2026.08.2");
  assert.equal(updated.effectiveFrom, "2026-08-13");
  assert.equal(updated.managementCostPerPyeong, 70_000);
  assert.equal(updated.businessMarginRate, 0.1);
  assert.equal(updated.estimateRangeRate, 0.12);
});

test("관리자가 옵션과 상세 옵션을 추가하고 견적에 합산한다", () => {
  const processGroups = structuredClone(DEFAULT_PRICING_CATALOG.processGroups);
  processGroups[1].options.push({
    id: "special-paint",
    label: "특수 도장",
    amount: 100_000,
    mode: "perPyeong",
    details: [
      {
        id: "premium-finish",
        label: "프리미엄 마감",
        amount: 50_000,
        mode: "perPyeong",
        details: [
          { id: "micro-texture", label: "미세 질감", amount: 25_000, mode: "perPyeong" },
        ],
      },
    ],
  });
  const catalog = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 0,
      businessMarginRate: 0,
      estimateRangeRate: 0.1,
      spaceTypes: structuredClone(DEFAULT_PRICING_CATALOG.spaceTypes),
      processGroups,
    },
    new Date("2026-08-14T00:00:00.000Z"),
  );

  const legacyResult = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { paint: "special-paint::premium-finish" } },
    catalog,
  );
  const result = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { paint: "special-paint::premium-finish::micro-texture" } },
    catalog,
  );

  assert.equal(catalog.processGroups[1].options.length, 4);
  assert.equal(legacyResult.midpoint, 1_500_000);
  assert.equal(result.midpoint, 1_800_000);
  assert.equal(result.breakdown[0].detail, "특수 도장 · 프리미엄 마감 · 미세 질감");
});

test("관리자가 0원 옵션과 하위 옵션을 저장할 수 있다", () => {
  const catalog = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 0,
      businessMarginRate: 0,
      estimateRangeRate: 0.1,
      spaceTypes: [{ id: "shop", label: "매장", multiplier: 1, description: "테스트 매장" }],
      processGroups: [{
        id: "consultation",
        label: "상담",
        description: "무료 상담 옵션",
        options: [{
          id: "basic",
          label: "기본 상담",
          amount: 0,
          mode: "fixed",
          details: [{ id: "visit", label: "방문 상담", amount: 0, mode: "fixed" }],
        }],
      }],
    },
    new Date("2026-08-29T00:00:00.000Z"),
  );

  const result = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { consultation: "basic::visit" } },
    catalog,
  );

  assert.equal(catalog.processGroups[0].options[0].amount, 0);
  assert.equal(catalog.processGroups[0].options[0].details?.[0].amount, 0);
  assert.equal(result.midpoint, 0);
  assert.equal(result.selectedCount, 1);
});

test("1m당 단가는 저장하되 길이 입력 규칙 전에는 자동 견적에 합산하지 않는다", () => {
  const catalog = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 0,
      businessMarginRate: 0,
      estimateRangeRate: 0.1,
      spaceTypes: [{ id: "shop", label: "매장", multiplier: 1, description: "테스트 매장" }],
      processGroups: [{
        id: "partition",
        label: "파티션",
        description: "길이 기준 공정",
        options: [{ id: "glass", label: "유리 파티션", amount: 180_000, mode: "perMeter" }],
      }],
    },
    new Date("2026-08-30T00:00:00.000Z"),
  );

  const result = calculateEstimate(
    { spaceType: "shop", area: 10, selections: { partition: "glass" } },
    catalog,
  );

  assert.equal(catalog.processGroups[0].options[0].mode, "perMeter");
  assert.equal(result.midpoint, 0);
  assert.equal(result.measurementRequired, true);
  assert.deepEqual(result.breakdown[0], {
    id: "partition",
    label: "파티션",
    detail: "유리 파티션",
    amount: 0,
    requiresMeasurement: true,
  });
});

test("같은 공정 안의 옵션명과 하위 옵션명은 중복 저장할 수 없다", () => {
  const processGroups = structuredClone(DEFAULT_PRICING_CATALOG.processGroups);
  processGroups[0].options[1].label = processGroups[0].options[0].label;

  assert.throws(
    () => applyPricingAdminUpdate(
      DEFAULT_PRICING_CATALOG,
      {
        managementCostPerPyeong: 0,
        businessMarginRate: 0,
        estimateRangeRate: 0.1,
        spaceTypes: structuredClone(DEFAULT_PRICING_CATALOG.spaceTypes),
        processGroups,
      },
    ),
    /같은 이름의 옵션/,
  );
});

test("관리자가 공정 대주제를 추가·수정·삭제하고 견적에 반영한다", () => {
  const processGroups = structuredClone(DEFAULT_PRICING_CATALOG.processGroups)
    .filter((group) => group.id !== "signage");
  processGroups.push({
    id: "air-conditioning",
    label: "냉난방",
    description: "공조 설비 범위를 선택합니다.",
    options: [{ id: "standard", label: "기본 냉난방", amount: 200_000, mode: "perPyeong" }],
  });

  const catalog = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 0,
      businessMarginRate: 0,
      estimateRangeRate: 0.1,
      spaceTypes: structuredClone(DEFAULT_PRICING_CATALOG.spaceTypes),
      processGroups,
    },
    new Date("2026-08-16T00:00:00.000Z"),
  );

  assert.equal(catalog.processGroups.some((group) => group.id === "signage"), false);
  assert.equal(catalog.processGroups.at(-1)?.label, "냉난방");
  assert.equal(catalog.processGroups.at(-1)?.options[0]?.label, "기본 냉난방");
  assert.equal(
    calculateEstimate({ spaceType: "shop", area: 10, selections: { "air-conditioning": "standard" } }, catalog).midpoint,
    2_000_000,
  );
});

test("관리자가 업종을 추가하면 해당 업종의 배수가 견적에 적용된다", () => {
  const spaceTypes = structuredClone(DEFAULT_PRICING_CATALOG.spaceTypes);
  spaceTypes.push({
    id: "academy",
    label: "학원",
    multiplier: 1.15,
    description: "강의실과 학습 공간 중심",
  });
  const catalog = applyPricingAdminUpdate(
    DEFAULT_PRICING_CATALOG,
    {
      managementCostPerPyeong: 0,
      businessMarginRate: 0,
      estimateRangeRate: 0.1,
      spaceTypes,
      processGroups: structuredClone(DEFAULT_PRICING_CATALOG.processGroups),
    },
    new Date("2026-08-15T00:00:00.000Z"),
  );

  const result = calculateEstimate(
    { spaceType: "academy", area: 10, selections: { paint: "wall" } },
    catalog,
  );

  assert.equal(catalog.spaceTypes.at(-1)?.label, "학원");
  assert.equal(result.midpoint, 1_000_000);
});

test("기업 이윤은 현장관리·보양 실비와 분리해 기본 공사비 합계에 적용한다", () => {
  const catalog = {
    ...DEFAULT_PRICING_CATALOG,
    managementCostPerPyeong: 0,
    businessMarginRate: 0.1,
    spaceTypes: [{ id: "shop", label: "매장", multiplier: 1, description: "테스트 매장" }],
    processGroups: [{
      id: "paint",
      label: "페인트",
      description: "테스트 공정",
      options: [{ id: "wall", label: "벽만", amount: 100_000, mode: "perPyeong" }],
    }],
  };

  const result = calculateEstimate({ spaceType: "shop", area: 10, selections: { paint: "wall" } }, catalog);

  assert.equal(result.midpoint, 1_100_000);
  assert.deepEqual(result.breakdown.at(-1), {
    id: "business-margin",
    label: "기업 이윤",
    detail: "기본 공사비의 10%",
    amount: 100_000,
  });
});

test("서버가 고객 입력을 다시 검증하고 최신 단가로 견적을 계산한다", () => {
  const draft = createServerInquiryDraft(
    {
      contact: {
        name: "홍길동",
        phone: "010-1234-5678",
        address: {
          postcode: "04047",
          baseAddress: "서울특별시 마포구 양화로 45",
          detailAddress: "3층",
          city: "서울",
          district: "마포구",
          neighborhood: "서교동",
        },
        constructionSchedule: "1~3개월",
      },
      privacyConsent: { agreed: true },
      estimate: {
        input: {
          spaceType: "restaurant",
          area: 20,
          selections: {
            demolition: "partial",
            paint: "all",
            floor: "deco",
            electric: "basic",
          },
        },
        result: { midpoint: 1 },
      },
    },
    DEFAULT_PRICING_CATALOG,
    new Date("2026-08-13T00:00:00.000Z"),
  );

  assert.equal(draft.estimate.result.midpoint, 11_800_000);
  assert.equal(draft.createdAt, "2026-08-13T00:00:00.000Z");
  assert.throws(
    () => createServerInquiryDraft({ privacyConsent: { agreed: false } }, DEFAULT_PRICING_CATALOG),
    /형식이 올바르지 않습니다/,
  );
});

test("관리자가 교체할 수 있는 사이트 이미지 영역이 중복 없이 정의되어 있다", () => {
  const ids = MEDIA_SLOTS.map((slot) => slot.id);
  assert.equal(ids.length, 13);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(MEDIA_SLOTS.every((slot) => slot.fallback.startsWith("/images/")));
  assert.equal(mediaUrl("home-hero-main-hq"), "/api/media/home-hero-main-hq");
  assert.equal(isPortfolioMediaSlot(portfolioCoverSlot("project-new-space")), true);
  assert.equal(isPortfolioMediaSlot(portfolioGallerySlot("project-new-space", "gallery-first-image")), true);
  assert.equal(isPortfolioMediaSlot("portfolio-project-a-cover"), false);
});

test("관리자가 저장한 사이트 문구를 정규화하고 항목 수를 검증한다", () => {
  const updated = structuredClone(DEFAULT_SITE_CONTENT);
  updated.home.heroTitle = "새로운 공간을 만드는\n화담아이디";
  updated.portfolio.projects[0].title = "카페 프로젝트";
  updated.portfolio.projects.push({
    id: "project-new-cafe",
    slug: "new-cafe-project",
    title: "새 카페 프로젝트",
    category: "새로운 공간",
    type: "카페 인테리어",
    scope: "기획 · 설계 · 시공",
    summary: "새 프로젝트 소개입니다.",
    designNote: "새 프로젝트 디자인 노트입니다.",
    shape: "portrait",
    coverSlot: portfolioCoverSlot("project-new-cafe"),
    gallerySlots: [portfolioGallerySlot("project-new-cafe", "gallery-01-photo")],
  });
  const normalized = normalizeSiteContent(updated);

  assert.equal(normalized.home.heroTitle, "새로운 공간을 만드는\n화담아이디");
  assert.equal(normalized.portfolio.projects[0].title, "카페 프로젝트");
  assert.equal(normalized.portfolio.projects.at(-1)?.slug, "new-cafe-project");
  assert.equal(normalized.portfolio.projects.at(-1)?.gallerySlots.length, 1);
  assert.equal(normalized.location.address, "경기도 하남시 미사강변중앙로 11 4층 W430호");
  assert.equal(normalized.location.consultationPhone, "010-6216-1894");

  const manyPhotos = structuredClone(updated);
  manyPhotos.portfolio.projects[0].gallerySlots = Array.from(
    { length: 31 },
    (_, index) => portfolioGallerySlot("project-restaurant", `gallery-photo-${String(index + 1).padStart(3, "0")}`),
  );
  assert.equal(normalizeSiteContent(manyPhotos).portfolio.projects[0].gallerySlots.length, 31);

  assert.throws(
    () => normalizeSiteContent({ ...updated, portfolio: { ...updated.portfolio, projects: [] } }),
    /항목 수가 올바르지 않습니다/,
  );
});

test("사이트 관리자 비밀번호와 세션 서명을 검증한다", async () => {
  const passwordRecord = await createPasswordRecord(
    "안전한-관리자-비밀번호",
    new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]),
    100_000,
  );
  assert.equal(await verifyPasswordRecord("안전한-관리자-비밀번호", passwordRecord), true);
  assert.equal(await verifyPasswordRecord("틀린-비밀번호", passwordRecord), false);

  const now = Date.parse("2026-08-19T00:00:00.000Z");
  const token = await createSessionToken("admin", "test-session-secret-with-enough-length", now);
  assert.equal(await verifySessionToken(token, "admin", "test-session-secret-with-enough-length", now + 1_000), true);
  assert.equal(await verifySessionToken(token, "other", "test-session-secret-with-enough-length", now + 1_000), false);
  assert.equal(await verifySessionToken(token, "admin", "test-session-secret-with-enough-length", now + 13 * 60 * 60 * 1_000), false);
});
