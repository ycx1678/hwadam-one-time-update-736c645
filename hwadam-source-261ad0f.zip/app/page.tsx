"use client";

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import SiteFrame from "../components/SiteFrame";
import {
  calculateEstimate,
  createProcessSelection,
  DEFAULT_PRICING_CATALOG,
  getSelectedOptions,
  parseProcessSelection,
  type EstimateResult,
  type PricingCatalog,
  type ProcessDetailOption,
  type SpaceTypeId,
} from "../lib/estimate";
import {
  createEstimateInquiryDraft,
  type EstimateInquiryDraft,
  type InquirySubmission,
} from "../lib/inquiry";
import { mediaUrl } from "../lib/media";
import { useSiteContent } from "../lib/use-site-content";
import ConsultationPhoneLink from "../components/ConsultationPhoneLink";

type Step = 1 | 2 | 3 | 4;

interface PostcodeResult {
  zonecode: string;
  address: string;
  roadAddress: string;
  jibunAddress: string;
  userSelectedType: "R" | "J";
  sido: string;
  sigungu: string;
  bname: string;
  roadname: string;
}

interface PostcodeConstructor {
  new (options: { oncomplete: (data: PostcodeResult) => void }): { open: () => void };
}

declare global {
  interface Window {
    kakao?: { Postcode: PostcodeConstructor };
  }
}

interface ContactForm {
  postcode: string;
  baseAddress: string;
  detailAddress: string;
  city: string;
  district: string;
  neighborhood: string;
  name: string;
  phone: string;
  schedule: string;
  privacy: boolean;
}

const INITIAL_CONTACT: ContactForm = {
  postcode: "",
  baseAddress: "",
  detailAddress: "",
  city: "",
  district: "",
  neighborhood: "",
  name: "",
  phone: "",
  schedule: "",
  privacy: false,
};

function formatWon(value: number) {
  if (value >= 100_000_000) {
    const eok = value / 100_000_000;
    return `${Number.isInteger(eok) ? eok : eok.toFixed(1)}억원`;
  }
  return `${Math.round(value / 10_000).toLocaleString("ko-KR")}만원`;
}

function renderEstimateTitle(title: string) {
  const commaIndex = title.indexOf(",");

  if (commaIndex === -1) return title;

  return (
    <>
      <span className="estimate-title-lead">{title.slice(0, commaIndex + 1)}</span>
      <br className="estimate-title-desktop-break" />
      <span className="estimate-title-tail">{title.slice(commaIndex + 1).trimStart()}</span>
    </>
  );
}

function NestedProcessOptions({
  details,
  selection,
  groupId,
  optionId,
  parentPath,
  onSelect,
}: Readonly<{
  details: readonly ProcessDetailOption[];
  selection: ReturnType<typeof parseProcessSelection>;
  groupId: string;
  optionId: string;
  parentPath: readonly string[];
  onSelect: (groupId: string, optionId: string, detailIds: readonly string[]) => void;
}>) {
  const depth = parentPath.length;

  return (
    <div className="process-detail-options" data-depth={depth + 2}>
      <p><span>{depth + 2}단계</span><b>하위 옵션</b><small>선택한 내용을 견적에 반영합니다.</small></p>
      <div className="process-detail-tree-list">
        {details.map((detail) => {
          const detailPath = [...parentPath, detail.id];
          const detailChecked = selection.detailIds[depth] === detail.id;
          return (
            <div className="process-detail-option-tree" key={detail.id}>
              <label className={detailChecked ? "selected" : ""}>
                <input
                  type="checkbox"
                  checked={detailChecked}
                  onChange={() => onSelect(groupId, optionId, detailPath)}
                />
                <span aria-hidden="true">{detailChecked ? "✓" : ""}</span>
                <b>{detail.label}</b>
              </label>
              {detailChecked && (detail.details ?? []).length > 0 && (
                <NestedProcessOptions
                  details={detail.details ?? []}
                  selection={selection}
                  groupId={groupId}
                  optionId={optionId}
                  parentPath={detailPath}
                  onSelect={onSelect}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function Home() {
  const siteContent = useSiteContent();
  const [step, setStep] = useState<Step>(1);
  const [spaceType, setSpaceType] = useState<SpaceTypeId | "">("");
  const [area, setArea] = useState("");
  const [selections, setSelections] = useState<Record<string, string[]>>({});
  const [contact, setContact] = useState<ContactForm>(INITIAL_CONTACT);
  const [error, setError] = useState("");
  const [inquiryDraft, setInquiryDraft] = useState<EstimateInquiryDraft | null>(null);
  const [submission, setSubmission] = useState<InquirySubmission | null>(null);
  const [pricingCatalog, setPricingCatalog] = useState<PricingCatalog>(DEFAULT_PRICING_CATALOG);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showEstimateNotice, setShowEstimateNotice] = useState(false);
  const calculatorRef = useRef<HTMLDivElement>(null);
  const estimateSectionRef = useRef<HTMLElement>(null);
  const detailAddressRef = useRef<HTMLInputElement>(null);
  const [estimateVisible, setEstimateVisible] = useState(false);
  const [postcodeStatus, setPostcodeStatus] = useState<"loading" | "ready" | "failed">("loading");

  useEffect(() => {
    let active = true;
    fetch("/api/pricing", { cache: "no-store" })
      .then((response) => response.json() as Promise<{ catalog?: PricingCatalog }>)
      .then((payload) => {
        if (active && payload.catalog) setPricingCatalog(payload.catalog);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    const scriptId = "kakao-postcode-script";
    const handleLoad = () => setPostcodeStatus("ready");
    const handleError = () => setPostcodeStatus("failed");

    if (window.kakao?.Postcode) {
      handleLoad();
      return;
    }

    const existingScript = document.getElementById(scriptId) as HTMLScriptElement | null;
    const script = existingScript ?? document.createElement("script");
    if (!existingScript) {
      script.id = scriptId;
      script.src = "https://t1.kakaocdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js";
      script.async = true;
      document.head.appendChild(script);
    }

    script.addEventListener("load", handleLoad);
    script.addEventListener("error", handleError);
    return () => {
      script.removeEventListener("load", handleLoad);
      script.removeEventListener("error", handleError);
    };
  }, []);

  useEffect(() => {
    const section = estimateSectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      ([entry]) => setEstimateVisible(entry.isIntersecting),
      { threshold: 0.08 },
    );
    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  const selectedOptions = useMemo(
    () => getSelectedOptions(selections, pricingCatalog),
    [pricingCatalog, selections],
  );
  const selectedRequiresMeasurement = selectedOptions.some(({ option, details }) =>
    [option, ...details].some((item) => item.mode === "perMeter"),
  );
  const selectedSpace = pricingCatalog.spaceTypes.find((candidate) => candidate.id === spaceType);
  const result: EstimateResult | null = inquiryDraft?.estimate.result ?? null;

  const scrollToCalculator = () => {
    calculatorRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const goToStep = (nextStep: Step) => {
    setError("");
    setStep(nextStep);
    window.setTimeout(scrollToCalculator, 20);
  };

  const validateSpace = () => {
    const numericArea = Number(area);
    if (!spaceType) {
      setError("업종을 선택해 주세요.");
      return false;
    }
    if (
      !Number.isFinite(numericArea) ||
      numericArea < pricingCatalog.minimumArea ||
      numericArea > pricingCatalog.maximumArea
    ) {
      setError(
        `면적은 ${pricingCatalog.minimumArea}평부터 ${pricingCatalog.maximumArea}평까지 입력해 주세요.`,
      );
      return false;
    }
    goToStep(2);
    return true;
  };

  const validateProcesses = () => {
    if (selectedOptions.length === 0) {
      setError("한 가지 이상의 공정을 선택해 주세요.");
      return false;
    }
    goToStep(3);
    return true;
  };

  const updateContact = <K extends keyof ContactForm>(key: K, value: ContactForm[K]) => {
    setContact((current) => ({ ...current, [key]: value }));
  };

  const openAddressSearch = () => {
    const Postcode = window.kakao?.Postcode;
    if (!Postcode) {
      setError(postcodeStatus === "failed" ? "주소 검색 서비스를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요." : "주소 검색 서비스를 준비하고 있습니다. 잠시 후 다시 시도해 주세요.");
      return;
    }

    new Postcode({
      oncomplete: (data) => {
        const baseAddress = data.userSelectedType === "R" ? data.roadAddress : data.jibunAddress;
        const neighborhood = data.bname.trim() || data.roadname.trim() || baseAddress;
        setContact((current) => ({
          ...current,
          postcode: data.zonecode,
          baseAddress,
          city: data.sido,
          district: data.sigungu || data.sido,
          neighborhood,
        }));
        setError("");
        window.setTimeout(() => detailAddressRef.current?.focus(), 50);
      },
    }).open();
  };

  const validateContact = () => {
    const digits = contact.phone.replace(/\D/g, "");
    if (
      !contact.postcode.trim() ||
      !contact.baseAddress.trim() ||
      !contact.city.trim() ||
      !contact.district.trim() ||
      !contact.neighborhood.trim() ||
      !contact.name.trim() ||
      !contact.schedule
    ) {
      setError("필수 정보를 모두 입력해 주세요.");
      return false;
    }
    if (!/^01[016789]\d{7,8}$/.test(digits)) {
      setError("연락처를 정확히 입력해 주세요.");
      return false;
    }
    if (!contact.privacy) {
      setError("개인정보 수집·이용 안내에 동의해 주세요.");
      return false;
    }
    return true;
  };

  const requestEstimate = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validateContact()) return;
    setShowEstimateNotice(true);
  };

  const submitEstimate = async () => {
    if (!validateContact()) {
      setShowEstimateNotice(false);
      return;
    }

    try {
      const estimateInput = {
        spaceType: spaceType as SpaceTypeId,
        area: Number(area),
        selections,
      };
      const estimateResult = calculateEstimate(estimateInput, pricingCatalog);
      const draft = createEstimateInquiryDraft({
          contact: {
            name: contact.name,
            phone: contact.phone,
            address: {
              postcode: contact.postcode,
              baseAddress: contact.baseAddress,
              detailAddress: contact.detailAddress,
              city: contact.city,
              district: contact.district,
              neighborhood: contact.neighborhood,
            },
            constructionSchedule: contact.schedule,
          },
          privacyAgreed: contact.privacy,
          estimateInput,
          estimateResult,
        });
      setIsSubmitting(true);
      const response = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(draft),
      });
      const payload = (await response.json()) as {
        submission?: InquirySubmission;
        estimateResult?: EstimateResult;
        error?: string;
      };
      if (!response.ok || !payload.submission || !payload.estimateResult) {
        throw new Error(payload.error ?? "견적 문의를 접수하지 못했습니다.");
      }
      setInquiryDraft({
        ...draft,
        estimate: { ...draft.estimate, result: payload.estimateResult },
      });
      setSubmission(payload.submission);
      setShowEstimateNotice(false);
      goToStep(4);
    } catch (estimateError) {
      setError(estimateError instanceof Error ? estimateError.message : "견적을 계산하지 못했습니다.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetEstimate = () => {
    setStep(1);
    setSpaceType("");
    setArea("");
    setSelections({});
    setContact(INITIAL_CONTACT);
    setInquiryDraft(null);
    setSubmission(null);
    setShowEstimateNotice(false);
    setError("");
    window.setTimeout(scrollToCalculator, 20);
  };

  const selectProcess = (groupId: string, optionId: string) => {
    setSelections((current) => {
      const currentSelections = current[groupId] ?? [];
      const alreadySelected = currentSelections.some(
        (value) => parseProcessSelection(value).optionId === optionId,
      );
      const nextSelections = alreadySelected
        ? currentSelections.filter((value) => parseProcessSelection(value).optionId !== optionId)
        : [...currentSelections, createProcessSelection(optionId)];
      if (nextSelections.length) return { ...current, [groupId]: nextSelections };

      const next = { ...current };
      delete next[groupId];
      return next;
    });
    setError("");
  };

  const selectProcessDetail = (groupId: string, optionId: string, detailIds: readonly string[]) => {
    setSelections((current) => {
      const nextValue = createProcessSelection(optionId, detailIds);
      const currentSelections = current[groupId] ?? [];
      return {
        ...current,
        [groupId]: currentSelections.map((value) => {
          if (parseProcessSelection(value).optionId !== optionId) return value;
          return value === nextValue
            ? createProcessSelection(optionId, detailIds.slice(0, -1))
            : nextValue;
        }),
      };
    });
    setError("");
  };

  return (
    <SiteFrame current="home">
    <main className="home-page">
      <section className="image-hero" id="처음" aria-labelledby="hero-title">
        <h1 className="image-hero-title" id="hero-title">화담아이디 상업공간 인테리어</h1>
        <a className="image-hero-project" href="/portfolio" aria-label="포트폴리오 보기">
          <figure>
            <img src={mediaUrl("home-hero-main-hq")} alt="자연광이 들어오는 음식점 인테리어" />
          </figure>
        </a>
        <div className="image-hero-meta" aria-label="대표 프로젝트 안내">
          <div>
            <a href="/portfolio/restaurant-space">작업 보기 <i aria-hidden="true">↗</i></a>
            <a href="#간편견적">견적 계산하기 <i aria-hidden="true">↓</i></a>
          </div>
        </div>
      </section>

      <section className="estimate-section" id="간편견적" ref={estimateSectionRef}>
        <div className="section-heading estimate-heading">
          <h2>{renderEstimateTitle(siteContent.home.estimateTitle)}</h2>
        </div>

        <div className="calculator-layout">
          <div className="calculator-card" ref={calculatorRef}>
            <ol className="stepper" aria-label="견적 진행 단계">
              {[1, 2, 3, 4].map((item) => (
                <li key={item} className={step >= item ? "active" : ""} aria-current={step === item ? "step" : undefined}>
                  <span>{String(item).padStart(2, "0")}</span>
                  <b>{["공간", "공정", "정보", "결과"][item - 1]}</b>
                </li>
              ))}
            </ol>

            {step === 1 && (
              <div className="calculator-body">
                <div className="step-title">
                  <span>01</span>
                  <div>
                    <h3>어떤 공간을 준비하고 계신가요?</h3>
                    <p>업종과 실사용 면적을 알려주세요.</p>
                  </div>
                </div>

                <fieldset className="choice-fieldset">
                  <legend>업종 선택</legend>
                  <div className="space-grid">
                    {pricingCatalog.spaceTypes.map((type) => (
                      <label key={type.id} className={`space-choice ${spaceType === type.id ? "selected" : ""}`}>
                        <input
                          type="radio"
                          name="space-type"
                          value={type.id}
                          checked={spaceType === type.id}
                          onChange={() => {
                            setSpaceType(type.id);
                            setError("");
                          }}
                        />
                        <span className="choice-check" aria-hidden="true" />
                        <strong>{type.label}</strong>
                        <small>{type.description}</small>
                      </label>
                    ))}
                  </div>
                </fieldset>

                <label className="area-field">
                  <span>공사 면적</span>
                  <span className="area-input-wrap">
                    <input
                      type="number"
                      inputMode="decimal"
                      min="3"
                      max="500"
                      step="0.5"
                      value={area}
                      placeholder="예: 20"
                      onChange={(event) => {
                        setArea(event.target.value);
                        setError("");
                      }}
                      aria-describedby="area-help"
                    />
                    <b>평</b>
                  </span>
                  <small id="area-help">3평부터 500평까지 입력할 수 있습니다.</small>
                </label>

                {error && <p className="form-error" role="alert">{error}</p>}
                <div className="step-actions desktop-action">
                  <button type="button" className="primary-button" onClick={validateSpace}>
                    공정 선택하기 <span aria-hidden="true">→</span>
                  </button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="calculator-body">
                <div className="step-title">
                  <span>02</span>
                  <div>
                    <h3>필요한 공정을 선택해 주세요.</h3>
                    <p>필요한 옵션은 여러 개 선택할 수 있습니다.</p>
                  </div>
                </div>

                <div className="process-list">
                  {pricingCatalog.processGroups.map((group) => (
                    <fieldset className="process-group" key={group.id}>
                      <legend>
                        <strong>{group.label}</strong>
                        <span>{group.description}</span>
                      </legend>
                      <div className="process-options">
                        {group.options.map((option) => {
                          const selectionValue = (selections[group.id] ?? []).find(
                            (value) => parseProcessSelection(value).optionId === option.id,
                          );
                          const selection = parseProcessSelection(selectionValue);
                          const checked = Boolean(selectionValue);
                          return (
                            <div className={`process-option-item ${checked ? "selected" : ""} ${checked && (option.details ?? []).length > 0 ? "with-details" : ""}`} key={option.id}>
                              <label className={checked ? "selected" : ""}>
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  onChange={() => selectProcess(group.id, option.id)}
                                />
                                <span className="option-check" aria-hidden="true">{checked ? "✓" : ""}</span>
                                <b>{option.label}</b>
                              </label>
                              {checked && (option.details ?? []).length > 0 && (
                                <NestedProcessOptions
                                  details={option.details ?? []}
                                  selection={selection}
                                  groupId={group.id}
                                  optionId={option.id}
                                  parentPath={[]}
                                  onSelect={selectProcessDetail}
                                />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </fieldset>
                  ))}
                </div>

                <p className="management-note">현장관리·보양 실비는 선택 공정에 자동 포함됩니다. 기업 이윤은 관리자 설정에 따라 별도 합산됩니다.</p>
                {selectedRequiresMeasurement && <p className="measurement-note">1m당 단가 항목은 길이·수량 기준을 확정한 뒤 현장 실측 금액으로 별도 반영됩니다.</p>}
                {error && <p className="form-error" role="alert">{error}</p>}
                <div className="step-actions desktop-action split">
                  <button type="button" className="text-button" onClick={() => goToStep(1)}>이전</button>
                  <button type="button" className="primary-button" onClick={validateProcesses}>
                    고객 정보 입력 <span aria-hidden="true">→</span>
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <form className="calculator-body" id="contact-form" onSubmit={requestEstimate} noValidate>
                <div className="step-title">
                  <span>03</span>
                  <div>
                    <h3>견적 확인을 위한 정보를 입력해 주세요.</h3>
                    <p>정확한 상담을 위해 기본 정보를 입력해 주세요.</p>
                  </div>
                </div>

                <div className="form-grid address-grid address-search-grid">
                  <label className="base-address-field">
                    <span>현장 주소</span>
                    <div className="address-search-control">
                      <input value={contact.baseAddress} readOnly placeholder="주소 검색을 눌러 선택해 주세요" autoComplete="street-address" />
                      <button type="button" className="address-search-button" onClick={openAddressSearch} disabled={postcodeStatus === "loading"}>
                        {postcodeStatus === "loading" ? "준비 중" : "주소 검색"}
                      </button>
                    </div>
                  </label>
                  <label className="detail-address-field">
                    <span>상세 주소 <small>선택</small></span>
                    <input ref={detailAddressRef} value={contact.detailAddress} onChange={(event) => updateContact("detailAddress", event.target.value)} placeholder="상세 주소를 입력해 주세요" autoComplete="address-line2" />
                  </label>
                </div>

                <div className="form-grid contact-grid">
                  <label>
                    <span>이름</span>
                    <input value={contact.name} onChange={(event) => updateContact("name", event.target.value)} placeholder="이름을 입력해 주세요" autoComplete="name" />
                  </label>
                  <label>
                    <span>연락처</span>
                    <input value={contact.phone} onChange={(event) => updateContact("phone", event.target.value)} placeholder="010-0000-0000" inputMode="tel" autoComplete="tel" />
                  </label>
                  <label>
                    <span>공사 예상 시기</span>
                    <select value={contact.schedule} onChange={(event) => updateContact("schedule", event.target.value)}>
                      <option value="">선택해 주세요</option>
                      <option value="1개월 이내">1개월 이내</option>
                      <option value="1~3개월">1~3개월</option>
                      <option value="3~6개월">3~6개월</option>
                      <option value="6개월 이후">6개월 이후</option>
                      <option value="미정">아직 미정</option>
                    </select>
                  </label>
                </div>

                <label className="privacy-check">
                  <input type="checkbox" checked={contact.privacy} onChange={(event) => updateContact("privacy", event.target.checked)} />
                  <span aria-hidden="true">{contact.privacy ? "✓" : ""}</span>
                  <b>개인정보 수집·이용 안내에 동의합니다.</b>
                  <small>수집 항목: 이름, 연락처, 공사 예정 주소, 공사 예상 시기</small>
                </label>

                {error && <p className="form-error" role="alert">{error}</p>}
                <div className="step-actions desktop-action split">
                  <button type="button" className="text-button" onClick={() => goToStep(2)}>이전</button>
                  <button type="submit" className="primary-button" disabled={isSubmitting}>
                    {isSubmitting ? "견적 접수 중" : "견적 조회하기"} <span aria-hidden="true">→</span>
                  </button>
                </div>
              </form>
            )}

            {step === 4 && result && (
              <div className="calculator-body result-body" aria-live="polite">
                <div className="result-kicker">예상 견적 계산이 완료되었습니다.</div>
                <h3>{contact.name}님의 공간은<br />이 범위에서 시작할 수 있어요.</h3>
                <div className="result-range">
                  <span>예상 견적 범위</span>
                  <strong>{formatWon(result.minimum)} ~ {formatWon(result.maximum)}</strong>
                  <p>기준 금액 {formatWon(result.midpoint)} · 부가세 별도</p>
                </div>

                <div className="result-summary">
                  <div><span>공간</span><b>{selectedSpace?.label}</b></div>
                  <div><span>면적</span><b>{area}평</b></div>
                  <div><span>선택 공정</span><b>{result.selectedCount}개</b></div>
                  <div><span>예상 시기</span><b>{contact.schedule}</b></div>
                </div>

                <div className="breakdown">
                  <h4>공정별 예상 내역</h4>
                  <ul>
                    {result.breakdown.map((item) => (
                      <li key={item.id}>
                        <span>
                          <b>{item.label}</b>
                          {item.id !== "management" && item.id !== "business-margin" && <small>{item.detail}</small>}
                        </span>
                        <strong>{item.requiresMeasurement ? (item.amount > 0 ? `${formatWon(item.amount)} + 실측` : "실측 후 산정") : formatWon(item.amount)}</strong>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="result-disclaimer">
                  현장 상태, 자재 등급, 설계 범위에 따라 실제 금액은 달라질 수 있습니다. 정확한 견적은 현장 실측 후 안내됩니다.{result.measurementRequired ? " 선택한 1m당 단가 항목은 길이·수량을 실측한 뒤 최종 견적에 반영됩니다." : ""}
                </div>

                <div className="result-actions">
                  <ConsultationPhoneLink className="primary-button" phone={siteContent.location.consultationPhone}>
                    즉시 상담하기 <span aria-hidden="true">↗</span>
                  </ConsultationPhoneLink>
                  <button type="button" className="text-button" onClick={resetEstimate}>다시 계산하기</button>
                </div>
              </div>
            )}
          </div>

          <aside className="estimate-summary" aria-label="견적 요약">
            <h3>나의 공간 견적</h3>
            <dl>
              <div><dt>업종</dt><dd>{selectedSpace?.label ?? "선택 전"}</dd></div>
              <div><dt>면적</dt><dd>{area ? `${area}평` : "입력 전"}</dd></div>
              <div><dt>선택 공정</dt><dd>{selectedOptions.length ? `${selectedOptions.length}개` : "선택 전"}</dd></div>
            </dl>
            {selectedOptions.length > 0 && (
              <ul className="selected-list">
                {selectedOptions.slice(0, 5).map(({ group, option, details }) => (
                  <li key={group.id}><span>{group.label}</span><b>{[option, ...details].map((item) => item.label).join(" · ")}</b></li>
                ))}
                {selectedOptions.length > 5 && <li className="more">외 {selectedOptions.length - 5}개 공정</li>}
              </ul>
            )}
            <div className="locked-price">
              {step === 4 && result ? (
                <><span>기준 예상 금액</span><strong>{formatWon(result.midpoint)}</strong></>
              ) : (
                <><span aria-hidden="true">＋</span><p>정보 입력 후<br />예상 금액이 공개됩니다.</p></>
              )}
            </div>
            <small className="summary-footnote">현장 실측 후 최종 견적을 안내드립니다.</small>
          </aside>
        </div>
      </section>

      {step < 4 && (
        <div className={`mobile-action ${estimateVisible ? "visible" : ""}`}>
          {step > 1 && <button type="button" className="mobile-back" onClick={() => goToStep((step - 1) as Step)} aria-label="이전 단계">←</button>}
          {step === 1 && <button type="button" className="primary-button" onClick={validateSpace}>공정 선택하기 →</button>}
          {step === 2 && <button type="button" className="primary-button" onClick={validateProcesses}>고객 정보 입력 →</button>}
          {step === 3 && <button type="submit" form="contact-form" className="primary-button" disabled={isSubmitting}>{isSubmitting ? "견적 접수 중" : "견적 조회하기 →"}</button>}
        </div>
      )}

      {showEstimateNotice && (
        <div className="estimate-confirm-modal" role="presentation" onClick={() => setShowEstimateNotice(false)}>
          <section className="estimate-confirm-modal-card" role="dialog" aria-modal="true" aria-labelledby="estimate-confirm-title" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="estimate-confirm-close" aria-label="안내 닫기" onClick={() => setShowEstimateNotice(false)}>×</button>
            <p>견적 확인 전 안내</p>
            <h3 id="estimate-confirm-title">실측 전 예상 견적입니다.</h3>
            <div>해당 견적서는 실측 전 견적서로, 상담 후 금액이 변동할 수 있는 점 참고 부탁드립니다.</div>
            <footer>
              <button type="button" className="text-button" onClick={() => setShowEstimateNotice(false)}>이전</button>
              <button type="button" className="primary-button" onClick={() => void submitEstimate()} disabled={isSubmitting}>{isSubmitting ? "견적 접수 중" : "확인 후 견적 보기"}</button>
            </footer>
          </section>
        </div>
      )}

    </main>
    </SiteFrame>
  );
}
