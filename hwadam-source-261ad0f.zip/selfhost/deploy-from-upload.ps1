param(
  [Parameter(Mandatory = $true)]
  [string]$ArchivePath
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$lockPath = Join-Path $PSScriptRoot ".manual-deploy.lock"
$statusPath = Join-Path $PSScriptRoot ".last-deploy-status.json"
$lock = $null

function Get-Pm2ErrorTail {
  $errorLog = Join-Path $env:USERPROFILE ".pm2\logs\hwadam-site-error.log"
  if (-not (Test-Path -LiteralPath $errorLog)) { return "" }
  $tail = (Get-Content -LiteralPath $errorLog -Tail 35 -ErrorAction SilentlyContinue) -join "`n"
  if ($tail.Length -gt 4000) { return $tail.Substring(0, 4000) }
  return $tail
}

function Write-DeploymentStatus {
  param(
    [string]$State,
    [string]$Message,
    [string]$ErrorLog = ""
  )
  @{ state = $State; message = $Message; errorLog = $ErrorLog; updatedAt = (Get-Date).ToUniversalTime().ToString("o") } |
    ConvertTo-Json -Compress |
    Set-Content -LiteralPath $statusPath -Encoding utf8
}

try {
  $lock = [System.IO.File]::Open($lockPath, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
} catch {
  # A detached deployment process can survive an interrupted PM2 restart.
  # Report the contention explicitly so the sender never remains stuck at
  # "running" while no new archive is being applied.
  Write-DeploymentStatus -State "failed" -Message "이전 배포 작업이 아직 종료되지 않아 새 배포를 시작하지 못했습니다. 미니PC에서 기존 배포 작업을 종료한 뒤 다시 시도해 주세요." -ErrorLog (Get-Pm2ErrorTail)
  exit 1
}

try {
  Write-DeploymentStatus -State "running" -Message "배포 파일 압축을 적용하고 있습니다."
  if (-not (Test-Path -LiteralPath $ArchivePath)) { throw "배포 ZIP 파일을 찾지 못했습니다." }
  $temporaryRoot = Join-Path $env:TEMP "hwadam-manual-deploy-$([guid]::NewGuid().ToString('N'))"
  New-Item -ItemType Directory -Path $temporaryRoot -Force | Out-Null
  Expand-Archive -LiteralPath $ArchivePath -DestinationPath $temporaryRoot -Force
  if (-not (Test-Path -LiteralPath (Join-Path $temporaryRoot "package.json"))) { throw "배포 ZIP의 사이트 파일 구성이 올바르지 않습니다." }

  Write-Host "[$(Get-Date -Format s)] GitHub Actions 배포 파일을 적용합니다."
  $sourceDirectories = @(".openai", "app", "build", "components", "db", "drizzle", "examples", "lib", "public", "selfhost", "tests", "worker")
  foreach ($directory in $sourceDirectories) {
    $sourceDirectory = Join-Path $temporaryRoot $directory
    if (-not (Test-Path -LiteralPath $sourceDirectory)) { continue }
    $destinationDirectory = Join-Path $appRoot $directory
    & robocopy.exe $sourceDirectory $destinationDirectory /E /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -gt 7) { throw "$directory 파일 복사에 실패했습니다. (robocopy: $LASTEXITCODE)" }
  }

  $sourceFiles = @(".gitignore", "drizzle.config.ts", "eslint.config.mjs", "next-env.d.ts", "next.config.ts", "package-lock.json", "package.json", "postcss.config.mjs", "README.md", "tsconfig.json", "vite.config.ts")
  foreach ($file in $sourceFiles) {
    $sourceFile = Join-Path $temporaryRoot $file
    if (Test-Path -LiteralPath $sourceFile) { Copy-Item -LiteralPath $sourceFile -Destination (Join-Path $appRoot $file) -Force }
  }

  Push-Location $appRoot
  $siteStopped = $false
  try {
    # npm ci can replace native build files used by the live Node process.
    # Stop only the site first; the deployment receiver stays online to report status.
    & pm2.cmd stop hwadam-site
    if ($LASTEXITCODE -ne 0) { throw "사이트 중지에 실패했습니다." }
    $siteStopped = $true
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw "npm ci 실행에 실패했습니다." }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw "사이트 빌드에 실패했습니다." }
    & pm2.cmd restart hwadam-site
    if ($LASTEXITCODE -ne 0) { throw "사이트 재시작에 실패했습니다." }
    $siteStopped = $false
    & pm2.cmd restart hwadam-deploy-agent
    if ($LASTEXITCODE -ne 0) { throw "배포 수신기 재시작에 실패했습니다." }
    & pm2.cmd save
    if ($LASTEXITCODE -ne 0) { throw "PM2 설정 저장에 실패했습니다." }
    Start-Sleep -Seconds 3
    $health = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:3000/" -TimeoutSec 15
    if ($health.StatusCode -ne 200) { throw "사이트 상태 점검이 실패했습니다. (HTTP $($health.StatusCode))" }
  } finally {
    if ($siteStopped) { & pm2.cmd restart hwadam-site | Out-Null }
    Pop-Location
  }
  Write-DeploymentStatus -State "succeeded" -Message "배포와 사이트 상태 점검이 완료되었습니다."
  Write-Host "[$(Get-Date -Format s)] 수동 배포가 완료되었습니다."
} catch {
  Write-DeploymentStatus -State "failed" -Message $_.Exception.Message -ErrorLog (Get-Pm2ErrorTail)
  Write-Error "수동 배포 실패: $($_.Exception.Message)"
  exit 1
} finally {
  if ($temporaryRoot) { Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue }
  Remove-Item -LiteralPath $ArchivePath -Force -ErrorAction SilentlyContinue
  if ($lock) { $lock.Dispose() }
  Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
}
