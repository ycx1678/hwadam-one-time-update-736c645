import { getActivePricingCatalog } from "../../../db/repositories";

export const dynamic = "force-dynamic";

export async function GET() {
  const catalog = await getActivePricingCatalog();
  return Response.json(
    { catalog },
    { headers: { "Cache-Control": "no-store" } },
  );
}
