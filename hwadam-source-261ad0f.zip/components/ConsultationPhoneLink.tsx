"use client";

import { useState } from "react";

function phoneDigits(phone: string) {
  return phone.replace(/\D/g, "");
}

function formatPhone(phone: string) {
  const digits = phoneDigits(phone);
  if (digits.length === 11) return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
  return phone;
}

function isDesktopPhoneExperience() {
  return window.matchMedia("(hover: hover) and (pointer: fine)").matches;
}

export default function ConsultationPhoneLink({
  phone,
  className,
  children,
}: Readonly<{
  phone: string;
  className: string;
  children: React.ReactNode;
}>) {
  const [showPhone, setShowPhone] = useState(false);
  const digits = phoneDigits(phone);
  const visiblePhone = formatPhone(phone);

  const handleClick = (event: React.MouseEvent<HTMLAnchorElement>) => {
    if (!isDesktopPhoneExperience()) return;
    event.preventDefault();
    setShowPhone(true);
  };

  return (
    <span className="consultation-phone-action">
      <a className={className} href={`tel:${digits}`} onClick={handleClick}>
        {children}
      </a>
      {showPhone && (
        <span className="consultation-phone-popover" role="status">
          <span>전화 상담</span>
          <strong>{visiblePhone}</strong>
          <button type="button" aria-label="전화번호 안내 닫기" onClick={() => setShowPhone(false)}>×</button>
        </span>
      )}
    </span>
  );
}
