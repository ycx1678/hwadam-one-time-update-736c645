import { DEFAULT_PRICING_CATALOG } from "./estimate.catalog";
import type {
  EstimateBreakdown,
  EstimateInput,
  ProcessSelectionValue,
  ProcessSelections,
  EstimateResult,
  PricingCatalog,
} from "./estimate.types";

export function roundToHundredThousand(value: number) {
  return Math.round(value / 100_000) * 100_000;
}

const DETAIL_SEPARATOR = "::";

export function createProcessSelection(optionId: string, detailIds: string | readonly string[] = []) {
  const path = typeof detailIds === "string" ? [detailIds] : detailIds;
  return [optionId, ...path.filter(Boolean)].join(DETAIL_SEPARATOR);
}

export function parseProcessSelection(value: string | undefined) {
  const [optionId = "", ...detailIds] = (value ?? "").split(DETAIL_SEPARATOR).filter(Boolean);
  return { optionId, detailId: detailIds[0], detailIds };
}

export function processSelectionValues(value: ProcessSelectionValue | undefined) {
  const values = typeof value === "string" ? [value] : Array.isArray(value) ? value : [];
  return [...new Set(values.filter((candidate): candidate is string => typeof candidate === "string" && candidate.length > 0))];
}

export function getSelectedOptions(
  selections: ProcessSelections,
  catalog: PricingCatalog = DEFAULT_PRICING_CATALOG,
) {
  return catalog.processGroups.flatMap((group) => {
    return processSelectionValues(selections[group.id]).flatMap((selectionValue) => {
      const { optionId, detailIds } = parseProcessSelection(selectionValue);
      const option = group.options.find((candidate) => candidate.id === optionId);
      if (!option) return [];
      const details = [];
      let candidates = option.details ?? [];
      for (const detailId of detailIds) {
        const detail = candidates.find((candidate) => candidate.id === detailId);
        if (!detail) return [];
        details.push(detail);
        candidates = detail.details ?? [];
      }
      return [{ group, option, detail: details.at(-1), details }];
    });
  });
}

export function calculateEstimate(
  input: EstimateInput,
  catalog: PricingCatalog = DEFAULT_PRICING_CATALOG,
): EstimateResult {
  const spaceType = catalog.spaceTypes.find((candidate) => candidate.id === input.spaceType);
  if (!spaceType) throw new Error("유효한 업종을 선택해 주세요.");
  if (
    !Number.isFinite(input.area) ||
    input.area < catalog.minimumArea ||
    input.area > catalog.maximumArea
  ) {
    throw new Error(
      `면적은 ${catalog.minimumArea}평부터 ${catalog.maximumArea}평까지 입력할 수 있습니다.`,
    );
  }

  const selected = getSelectedOptions(input.selections, catalog);
  if (selected.length === 0) throw new Error("한 가지 이상의 공정을 선택해 주세요.");

  const perPyeong = selected.reduce(
    (total, { option, details }) =>
      total + [option, ...details].reduce((sum, item) => sum + (item.mode === "perPyeong" ? item.amount : 0), 0),
    0,
  );
  const fixed = selected.reduce(
    (total, { option, details }) =>
      total + [option, ...details].reduce((sum, item) => sum + (item.mode === "fixed" ? item.amount : 0), 0),
    0,
  );

  const variableTotal =
    input.area * (perPyeong + catalog.managementCostPerPyeong) * spaceType.multiplier;
  const baseTotal = variableTotal + fixed;
  // 이미 저장된 이전 단가표에는 이 필드가 없을 수 있으므로 0%로 안전하게 처리합니다.
  const businessMarginRate = catalog.businessMarginRate ?? 0;
  const businessMargin = baseTotal * businessMarginRate;
  const midpoint = roundToHundredThousand(baseTotal + businessMargin);

  const breakdown: EstimateBreakdown[] = selected.map(({ group, option, details }) => {
    const selectedItems = [option, ...details];
    const amount = selectedItems.reduce(
      (total, item) => total + (
        item.mode === "fixed"
          ? item.amount
          : item.mode === "perPyeong"
            ? input.area * item.amount * spaceType.multiplier
            : 0
      ),
      0,
    );
    return {
      id: group.id,
      label: group.label,
      detail: selectedItems.map((item) => item.label).join(" · "),
      amount,
      requiresMeasurement: selectedItems.some((item) => item.mode === "perMeter"),
    };
  });

  breakdown.push({
    id: "management",
    label: "현장관리·보양 실비",
    detail: "공정 선택 시 자동 포함",
    amount: input.area * catalog.managementCostPerPyeong * spaceType.multiplier,
  });

  if (businessMarginRate > 0) {
    breakdown.push({
      id: "business-margin",
      label: "기업 이윤",
      detail: `기본 공사비의 ${Math.round(businessMarginRate * 100)}%`,
      amount: businessMargin,
    });
  }

  return {
    catalogId: catalog.id,
    catalogVersion: catalog.version,
    currency: catalog.currency,
    midpoint,
    minimum: roundToHundredThousand(midpoint * (1 - catalog.estimateRangeRate)),
    maximum: roundToHundredThousand(midpoint * (1 + catalog.estimateRangeRate)),
    breakdown,
    selectedCount: selected.length,
    measurementRequired: breakdown.some((item) => item.requiresMeasurement),
  };
}
