import type { Metadata } from "next";
import { headers } from "next/headers";
import { notFound } from "next/navigation";
import PortfolioDetailPageContent from "../../../components/PortfolioDetailPageContent";
import { getSiteContent } from "../../../db/repositories";
import { mediaUrl } from "../../../lib/media";

type PageProps = { params: Promise<{ slug: string }> };

function getOrigin(host: string) {
  return host.includes("localhost") ? `http://${host}` : `https://${host}`;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const project = (await getSiteContent()).portfolio.projects.find((candidate) => candidate.slug === slug);

  if (!project) return {};

  const incomingHeaders = await headers();
  const host = incomingHeaders.get("x-forwarded-host") ?? incomingHeaders.get("host") ?? "localhost:3000";
  const origin = getOrigin(host);
  const url = `${origin}/portfolio/${project.slug}`;
  const image = new URL(mediaUrl(project.coverSlot), origin).toString();
  const title = `${project.title} | 포트폴리오`;

  return {
    title,
    description: project.summary,
    alternates: { canonical: `/portfolio/${project.slug}` },
    openGraph: {
      title,
      description: project.summary,
      url,
      images: [{ url: image, alt: `${project.title} 인테리어` }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description: project.summary,
      images: [image],
    },
  };
}

export default async function PortfolioDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const project = (await getSiteContent()).portfolio.projects.find((candidate) => candidate.slug === slug);

  if (!project) notFound();

  return <PortfolioDetailPageContent project={project} />;
}
