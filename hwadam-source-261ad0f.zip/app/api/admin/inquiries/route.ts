import { listEstimateInquiries } from "../../../../db/repositories";
import { getAuthorizedAdministrator } from "../../../../lib/admin-server";

export const dynamic = "force-dynamic";

export async function GET() {
  const administrator = await getAuthorizedAdministrator();
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  const inquiries = await listEstimateInquiries();
  return Response.json(
    { inquiries },
    { headers: { "Cache-Control": "no-store" } },
  );
}
