param(
  [switch]$Force,
  [switch]$UseGitHubCli
)

$ErrorActionPreference = "Stop"

$appRoot = Split-Path -Parent $PSScriptRoot
$markerPath = Join-Path $PSScriptRoot ".deployed-commit"
$lockPath = Join-Path $PSScriptRoot ".auto-deploy.lock"
$repository = "FlashStudio-KR/hwadam"
$branch = "main"
$lock = $null

function Get-DeployToken {
  if ($env:GITHUB_DEPLOY_TOKEN) { return $env:GITHUB_DEPLOY_TOKEN.Trim() }
  $environmentFile = Join-Path $PSScriptRoot ".env"
  if (-not (Test-Path -LiteralPath $environmentFile)) { return "" }
  $line = Get-Content -LiteralPath $environmentFile | Where-Object { $_ -match '^GITHUB_DEPLOY_TOKEN=' } | Select-Object -First 1
  if (-not $line) { return "" }
  return ($line -replace '^GITHUB_DEPLOY_TOKEN=', '').Trim().Trim('"').Trim("'")
}

function Get-RemoteCommit {
  param([string]$DeployToken)

  if ($DeployToken) {
    $headers = @{ "User-Agent" = "Hwadam-MiniPC-AutoDeploy"; "Authorization" = "Bearer $DeployToken"; "Accept" = "application/vnd.github+json" }
    $commit = Invoke-RestMethod -Uri "https://api.github.com/repos/$repository/commits/$branch" -Headers $headers
    return [string]$commit.sha
  }

  if (-not (Get-Command git.exe -ErrorAction SilentlyContinue)) {
    throw "Git을 찾지 못했습니다. GitHub CLI 방식은 Git과 GitHub CLI 로그인이 필요합니다."
  }
  $remoteReference = & git.exe ls-remote "https://github.com/$repository.git" "refs/heads/$branch"
  if ($LASTEXITCODE -ne 0 -or -not $remoteReference) {
    throw "GitHub 저장소를 읽지 못했습니다. gh auth login과 gh auth setup-git을 먼저 실행해 주세요."
  }
  return (($remoteReference | Select-Object -First 1) -split "\s+")[0]
}

function Get-SourceRoot {
  param(
    [string]$DeployToken,
    [string]$TemporaryRoot
  )

  if ($DeployToken) {
    $headers = @{ "User-Agent" = "Hwadam-MiniPC-AutoDeploy"; "Authorization" = "Bearer $DeployToken"; "Accept" = "application/vnd.github+json" }
    $zipPath = "$TemporaryRoot.zip"
    New-Item -ItemType Directory -Path $TemporaryRoot -Force | Out-Null
    Invoke-WebRequest -Uri "https://github.com/$repository/archive/refs/heads/$branch.zip" -Headers $headers -OutFile $zipPath
    Expand-Archive -LiteralPath $zipPath -DestinationPath $TemporaryRoot -Force
    $sourceRoot = Get-ChildItem -LiteralPath $TemporaryRoot -Directory | Select-Object -First 1
    if (-not $sourceRoot) { throw "배포 파일을 찾지 못했습니다." }
    return $sourceRoot
  }

  $sourceRoot = Join-Path $TemporaryRoot "source"
  New-Item -ItemType Directory -Path $TemporaryRoot -Force | Out-Null
  & git.exe clone --depth 1 --branch $branch "https://github.com/$repository.git" $sourceRoot
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $sourceRoot)) {
    throw "GitHub 저장소 내려받기에 실패했습니다. gh auth login과 gh auth setup-git을 확인해 주세요."
  }
  return Get-Item -LiteralPath $sourceRoot
}

try {
  # Do not run two deployments at the same time when the scheduled check overlaps.
  $lock = [System.IO.File]::Open(
    $lockPath,
    [System.IO.FileMode]::OpenOrCreate,
    [System.IO.FileAccess]::ReadWrite,
    [System.IO.FileShare]::None
  )
} catch {
  exit 0
}

try {
  $deployToken = if ($UseGitHubCli) { "" } else { Get-DeployToken }
  $remoteCommit = Get-RemoteCommit -DeployToken $deployToken
  $currentCommit = if (Test-Path -LiteralPath $markerPath) { (Get-Content -LiteralPath $markerPath -Raw).Trim() } else { "" }

  if (-not $Force -and $currentCommit -eq $remoteCommit) {
    exit 0
  }

  Write-Host "[$(Get-Date -Format s)] 새 사이트 버전($remoteCommit)을 적용합니다."
  $temporaryRoot = Join-Path $env:TEMP "hwadam-deploy-$remoteCommit"
  $zipPath = "$temporaryRoot.zip"
  Remove-Item -LiteralPath $temporaryRoot -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue
  $sourceRoot = Get-SourceRoot -DeployToken $deployToken -TemporaryRoot $temporaryRoot

  $sourceDirectories = @(".openai", "app", "build", "components", "db", "drizzle", "examples", "lib", "public", "selfhost", "tests", "worker")
  foreach ($directory in $sourceDirectories) {
    $sourceDirectory = Join-Path $sourceRoot.FullName $directory
    if (-not (Test-Path -LiteralPath $sourceDirectory)) { continue }
    $destinationDirectory = Join-Path $appRoot $directory
    & robocopy.exe $sourceDirectory $destinationDirectory /E /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -gt 7) { throw "$directory 파일 복사에 실패했습니다. (robocopy: $LASTEXITCODE)" }
  }

  $sourceFiles = @(".gitignore", "drizzle.config.ts", "eslint.config.mjs", "next-env.d.ts", "next.config.ts", "package-lock.json", "package.json", "postcss.config.mjs", "README.md", "tsconfig.json", "vite.config.ts")
  foreach ($file in $sourceFiles) {
    $sourceFile = Join-Path $sourceRoot.FullName $file
    if (Test-Path -LiteralPath $sourceFile) { Copy-Item -LiteralPath $sourceFile -Destination (Join-Path $appRoot $file) -Force }
  }

  Push-Location $appRoot
  $siteStopped = $false
  try {
    & pm2.cmd stop hwadam-site
    if ($LASTEXITCODE -ne 0) { throw "사이트 중지에 실패했습니다." }
    $siteStopped = $true
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw "npm ci 실행에 실패했습니다." }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw "사이트 빌드에 실패했습니다." }
    & pm2.cmd restart hwadam-site
    if ($LASTEXITCODE -ne 0) { throw "사이트 재시작에 실패했습니다." }
    $siteStopped = $false
    & pm2.cmd save
    if ($LASTEXITCODE -ne 0) { throw "PM2 설정 저장에 실패했습니다." }
  } finally {
    if ($siteStopped) { & pm2.cmd restart hwadam-site | Out-Null }
    Pop-Location
  }

  Set-Content -LiteralPath $markerPath -Value $remoteCommit -NoNewline
  Write-Host "[$(Get-Date -Format s)] 배포가 완료되었습니다."
} catch {
  Write-Error "자동 배포 실패: $($_.Exception.Message)"
  exit 1
} finally {
  if ($lock) { $lock.Dispose() }
  Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue
}
