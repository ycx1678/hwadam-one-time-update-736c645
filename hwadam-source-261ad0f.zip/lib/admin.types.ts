import type { EstimateBreakdown, PricingCatalog, ProcessSelections, SpaceTypeId } from "./estimate";
import type { SiteContent } from "./site-content";

export type InquiryStatus = "new" | "contacted" | "quoted" | "closed";

export interface AdminInquiry {
  readonly id: string;
  readonly status: InquiryStatus;
  readonly createdAt: string;
  readonly name: string;
  readonly phone: string;
  readonly address: string;
  readonly constructionSchedule: string;
  readonly spaceType: SpaceTypeId;
  readonly area: number;
  readonly midpoint: number;
  readonly minimum: number;
  readonly maximum: number;
  readonly selectedCount: number;
  readonly catalogVersion: string;
  readonly catalogEffectiveFrom: string;
  readonly breakdown: readonly EstimateBreakdown[];
  readonly selections: ProcessSelections;
}

export interface PricingAdminUpdate {
  readonly managementCostPerPyeong: number;
  readonly businessMarginRate: number;
  readonly estimateRangeRate: number;
  readonly spaceTypes: PricingCatalog["spaceTypes"];
  readonly processGroups: PricingCatalog["processGroups"];
}

export interface AdminDashboardData {
  readonly catalog: PricingCatalog;
  readonly inquiries: readonly AdminInquiry[];
  readonly content: SiteContent;
}
