import { getSiteContent } from "../../../db/repositories";

export const dynamic = "force-dynamic";

export async function GET() {
  const content = await getSiteContent();
  return Response.json({ content }, { headers: { "Cache-Control": "no-store" } });
}
