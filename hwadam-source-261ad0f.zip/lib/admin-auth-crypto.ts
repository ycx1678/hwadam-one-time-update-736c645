const encoder = new TextEncoder();
const PASSWORD_ALGORITHM = "pbkdf2-sha256";
const DEFAULT_PASSWORD_ITERATIONS = 210_000;
const SESSION_DURATION_MS = 12 * 60 * 60 * 1000;

function bytesToBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlToBytes(value: string) {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function constantTimeEqual(left: Uint8Array, right: Uint8Array) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}

async function derivePasswordHash(password: string, salt: Uint8Array, iterations: number) {
  const material = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations },
    material,
    256,
  );
  return new Uint8Array(bits);
}

export async function createPasswordRecord(
  password: string,
  salt = crypto.getRandomValues(new Uint8Array(16)),
  iterations = DEFAULT_PASSWORD_ITERATIONS,
) {
  const hash = await derivePasswordHash(password, salt, iterations);
  return `${PASSWORD_ALGORITHM}$${iterations}$${bytesToBase64Url(salt)}$${bytesToBase64Url(hash)}`;
}

export async function verifyPasswordRecord(password: string, record: string) {
  const [algorithm, iterationText, saltText, hashText] = record.split("$");
  const iterations = Number(iterationText);
  if (
    algorithm !== PASSWORD_ALGORITHM ||
    !Number.isInteger(iterations) ||
    iterations < 100_000 ||
    !saltText ||
    !hashText
  ) return false;

  try {
    const expected = base64UrlToBytes(hashText);
    const actual = await derivePasswordHash(password, base64UrlToBytes(saltText), iterations);
    return constantTimeEqual(actual, expected);
  } catch {
    return false;
  }
}

async function sign(value: string, secret: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", key, encoder.encode(value));
  return bytesToBase64Url(new Uint8Array(signature));
}

export async function createSessionToken(username: string, secret: string, now = Date.now()) {
  const payload = bytesToBase64Url(encoder.encode(JSON.stringify({
    username,
    issuedAt: now,
    expiresAt: now + SESSION_DURATION_MS,
  })));
  return `${payload}.${await sign(payload, secret)}`;
}

export async function verifySessionToken(token: string, username: string, secret: string, now = Date.now()) {
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return false;

  try {
    const expectedSignature = base64UrlToBytes(await sign(payload, secret));
    const actualSignature = base64UrlToBytes(signature);
    if (!constantTimeEqual(actualSignature, expectedSignature)) return false;
    const parsed = JSON.parse(new TextDecoder().decode(base64UrlToBytes(payload))) as {
      username?: unknown;
      issuedAt?: unknown;
      expiresAt?: unknown;
    };
    return parsed.username === username &&
      typeof parsed.issuedAt === "number" && parsed.issuedAt <= now + 60_000 &&
      typeof parsed.expiresAt === "number" && parsed.expiresAt > now;
  } catch {
    return false;
  }
}
