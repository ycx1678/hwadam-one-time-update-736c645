"use client";

import SiteFrame from "./SiteFrame";
import ConsultationPhoneLink from "./ConsultationPhoneLink";
import KakaoStaticMap from "./KakaoStaticMap";
import { useSiteContent } from "../lib/use-site-content";

export default function LocationPageContent() {
  const { location } = useSiteContent();
  const address = location.address.trim();

  return (
    <SiteFrame current="location">
      <main className="location-page">
        <section className="location-shell" aria-labelledby="location-title">
          <header className="location-heading">
            <p>찾아오는 길</p>
            <h1 id="location-title">방문 상담은<br />사전 예약으로 진행합니다.</h1>
            <span>현장 상담 또는 방문 미팅을 원하시면 먼저 편하게 연락해 주세요.<br />일정에 맞춰 정확한 위치와 안내를 전달드립니다.</span>
          </header>

          {address && <KakaoStaticMap address={address} />}

          <article className="location-contact-card">
            <div>
              <span>상담 예약</span>
              <h2>공간에 대한 이야기를<br />먼저 들려주세요.</h2>
              <p>{address ? <>방문 주소: {address}</> : "방문 상담 장소는 예약 확정 후 안내드립니다."}</p>
            </div>
            <div className="location-contact-actions">
              <ConsultationPhoneLink className="location-consult-link" phone={location.consultationPhone}>
                즉시 상담하기 <i aria-hidden="true">↗</i>
              </ConsultationPhoneLink>
            </div>
          </article>
        </section>
      </main>
    </SiteFrame>
  );
}
