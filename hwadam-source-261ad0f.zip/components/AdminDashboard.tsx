"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type {
  AdminDashboardData,
  AdminInquiry,
  InquiryStatus,
  PricingAdminUpdate,
} from "../lib/admin.types";
import {
  getSelectedOptions,
  type PricingCatalog,
  type PricingMode,
  type ProcessOption,
  type SpaceType,
} from "../lib/estimate";
import { MEDIA_SECTIONS, MEDIA_SLOTS, mediaUrl, portfolioCoverSlot, portfolioGallerySlot } from "../lib/media";
import type { PortfolioImageShape, SiteContent } from "../lib/site-content";

const STATUS_LABELS: Record<InquiryStatus, string> = {
  new: "신규",
  contacted: "연락 완료",
  quoted: "견적 진행",
  closed: "종료",
};

const PRICING_MODE_LABELS: Record<PricingMode, string> = {
  perPyeong: "평당",
  fixed: "고정",
  perMeter: "1m당",
};

type AdminSection = "inquiries" | "pricing" | "media" | "content";
type ContentSection = "home" | "portfolio" | "process" | "location";
type InquiryFilter = "all" | InquiryStatus;
type OptionPath = readonly string[];

type EditablePricingOption = {
  id: string;
  label: string;
  amount: number;
  mode: PricingMode;
  details?: EditablePricingOption[];
};

type EditableProcessGroup = {
  id: string;
  label: string;
  description: string;
  options: EditablePricingOption[];
};

const ADMIN_SECTIONS: Array<{ id: AdminSection; label: string }> = [
  { id: "inquiries", label: "견적 문의" },
  { id: "pricing", label: "단가 관리" },
  { id: "media", label: "이미지 관리" },
  { id: "content", label: "텍스트 관리" },
];

const CONTENT_SECTIONS: Array<{
  id: ContentSection;
  label: string;
  description: string;
  href: string;
  locations: readonly string[];
}> = [
  { id: "home", label: "메인 화면", description: "간편 견적 영역에 노출되는 제목", href: "/#간편견적", locations: ["메인 페이지", "간편 견적 섹션", "상단 큰 제목"] },
  { id: "portfolio", label: "포트폴리오", description: "소개 문구와 시공 사례·사진 관리", href: "/portfolio", locations: ["포트폴리오 페이지", "왼쪽 소개 영역", "시공 사례 목록·상세 페이지"] },
  { id: "process", label: "진행 과정", description: "진행 과정 페이지의 상단과 단계별 설명", href: "/process", locations: ["진행 과정 페이지", "상단 소개", "단계별 텍스트"] },
  { id: "location", label: "찾아오는 길", description: "찾아오는 길의 방문 주소, 지도, 즉시 상담 전화번호", href: "/location", locations: ["찾아오는 길 페이지", "상담 예약 카드", "방문 주소·카카오 지도·즉시 상담 버튼"] },
];

const INQUIRY_FILTERS: Array<{ id: InquiryFilter; label: string }> = [
  { id: "all", label: "전체 문의" },
  { id: "new", label: "신규" },
  { id: "contacted", label: "연락 완료" },
  { id: "quoted", label: "견적 진행" },
  { id: "closed", label: "종료" },
];

function formatWon(value: number) {
  return `${Math.round(value / 10_000).toLocaleString("ko-KR")}만원`;
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("ko-KR", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

function formatDateOnly(value: string) {
  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(value));
}

function clonePricingOption(option: ProcessOption): EditablePricingOption {
  return {
    ...option,
    details: option.details?.map((detail) => clonePricingOption(detail)),
  };
}

function cloneProcessGroups(groups: PricingCatalog["processGroups"]): EditableProcessGroup[] {
  return groups.map((group) => ({
    ...group,
    options: group.options.map(clonePricingOption),
  }));
}

function updateOptionAtPath(
  groups: PricingCatalog["processGroups"],
  groupId: string,
  path: OptionPath,
  update: (option: EditablePricingOption) => void,
) {
  const nextGroups = cloneProcessGroups(groups);
  const group = nextGroups.find((candidate) => candidate.id === groupId);
  if (!group || path.length === 0) return groups;

  let options = group.options;
  for (const [index, optionId] of path.entries()) {
    const option = options.find((candidate) => candidate.id === optionId);
    if (!option) return groups;
    if (index === path.length - 1) {
      update(option);
      return nextGroups;
    }
    options = option.details ?? [];
  }
  return groups;
}

function removeOptionAtPath(groups: PricingCatalog["processGroups"], groupId: string, path: OptionPath) {
  const nextGroups = cloneProcessGroups(groups);
  const group = nextGroups.find((candidate) => candidate.id === groupId);
  if (!group || path.length < 2) return groups;

  let options = group.options;
  for (const [index, optionId] of path.entries()) {
    if (index === path.length - 1) {
      const position = options.findIndex((candidate) => candidate.id === optionId);
      if (position < 0) return groups;
      options.splice(position, 1);
      return nextGroups;
    }
    const option = options.find((candidate) => candidate.id === optionId);
    if (!option) return groups;
    options = option.details ?? [];
  }
  return groups;
}

function countNestedOptions(options: readonly ProcessOption[]): number {
  return options.reduce((total, option) => total + 1 + countNestedOptions(option.details ?? []), 0);
}

function catalogToUpdate(catalog: PricingCatalog): PricingAdminUpdate {
  return {
    managementCostPerPyeong: catalog.managementCostPerPyeong,
    businessMarginRate: catalog.businessMarginRate ?? 0,
    estimateRangeRate: catalog.estimateRangeRate,
    spaceTypes: catalog.spaceTypes.map((spaceType) => ({ ...spaceType })),
    processGroups: cloneProcessGroups(catalog.processGroups),
  };
}

function createPricingId(prefix: "option" | "detail" | "space" | "group" | "project" | "gallery") {
  // 일부 모바일 브라우저·사내 WebView에는 crypto.randomUUID가 없습니다.
  // 추가 버튼은 서버 저장 전의 임시 식별자만 필요하므로, 이 경우에도 충돌 가능성이
  // 매우 낮은 식별자를 만들어 편집 화면이 멈추지 않게 합니다.
  const randomUuid = globalThis.crypto?.randomUUID;
  const uniquePart = typeof randomUuid === "function"
    ? randomUuid.call(globalThis.crypto)
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  return `${prefix}-${uniquePart}`;
}

function csvCell(value: string | number) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function TextEditorField({
  label,
  value,
  onChange,
  multiline = false,
  placeholder,
}: Readonly<{
  label: string;
  value: string;
  onChange: (value: string) => void;
  multiline?: boolean;
  placeholder?: string;
}>) {
  return (
    <label className="content-field">
      <span>{label}</span>
      {multiline ? (
        <textarea rows={3} value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
      ) : (
        <input value={value} placeholder={placeholder} onChange={(event) => onChange(event.target.value)} />
      )}
    </label>
  );
}

function ContentLocationGuide({
  section,
}: Readonly<{
  section: (typeof CONTENT_SECTIONS)[number];
}>) {
  return (
    <aside className="content-location-guide">
      <div>
        <span>이 문구가 표시되는 위치</span>
        <strong>{section.label}</strong>
        <p>{section.description}</p>
      </div>
      <ol aria-label={`${section.label} 화면 위치`}>
        {section.locations.map((location, index) => <li key={location}><span>{index + 1}</span>{location}</li>)}
      </ol>
      <a href={section.href} target="_blank" rel="noreferrer">실제 화면에서 보기 <span aria-hidden="true">↗</span></a>
    </aside>
  );
}

function NestedPricingOptionList({
  groupId,
  options,
  parentPath,
  onUpdate,
  onAdd,
  onRemove,
}: Readonly<{
  groupId: string;
  options: readonly ProcessOption[];
  parentPath: OptionPath;
  onUpdate: (groupId: string, path: OptionPath, patch: Partial<Pick<ProcessOption, "label" | "amount" | "mode">>) => void;
  onAdd: (groupId: string, parentPath: OptionPath, mode: PricingMode) => void;
  onRemove: (groupId: string, path: OptionPath) => void;
}>) {
  return (
    <div className="pricing-detail-list">
      {options.map((option) => {
        const path = [...parentPath, option.id];
        return (
          <section className="pricing-detail-node" data-depth={path.length} key={option.id}>
            <div className="pricing-detail-row">
              <span>{path.length}단계</span>
              <label><span>옵션명</span><input value={option.label} onChange={(event) => onUpdate(groupId, path, { label: event.target.value })} /></label>
              <label>
                <span>계산 방식</span>
                <select value={option.mode} onChange={(event) => onUpdate(groupId, path, { mode: event.target.value as PricingMode })}>
                  <option value="perPyeong">평당 단가</option>
                  <option value="fixed">고정 금액</option>
                  <option value="perMeter">1m당 단가 · 실측 후 산정</option>
                </select>
              </label>
              <label><span>추가 단가</span><div><input type="number" min="0" step="10000" value={option.amount} onChange={(event) => onUpdate(groupId, path, { amount: Number(event.target.value) })} /><small>원 · 0원 가능</small></div></label>
              <button type="button" className="pricing-detail-add-button" onClick={() => onAdd(groupId, path, option.mode)}>＋ 하위</button>
              <button type="button" aria-label={`${option.label} 삭제`} onClick={() => onRemove(groupId, path)}>삭제</button>
            </div>
            {(option.details ?? []).length > 0 && (
              <div className="pricing-detail-children">
                <NestedPricingOptionList
                  groupId={groupId}
                  options={option.details ?? []}
                  parentPath={path}
                  onUpdate={onUpdate}
                  onAdd={onAdd}
                  onRemove={onRemove}
                />
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}

export default function AdminDashboard({
  initialData,
  signOutHref,
}: Readonly<{
  initialData: AdminDashboardData;
  signOutHref: string;
}>) {
  const [catalog, setCatalog] = useState(initialData.catalog);
  const [inquiries, setInquiries] = useState([...initialData.inquiries]);
  const [siteContent, setSiteContent] = useState<SiteContent>(initialData.content);
  const [pricingUpdate, setPricingUpdate] = useState(() => catalogToUpdate(initialData.catalog));
  const [savingPricing, setSavingPricing] = useState(false);
  const [message, setMessage] = useState("");
  const [activeSection, setActiveSection] = useState<AdminSection>("inquiries");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [priceDetailInquiry, setPriceDetailInquiry] = useState<AdminInquiry | null>(null);
  const [inquiryFilter, setInquiryFilter] = useState<InquiryFilter>("all");
  const [pricingSection, setPricingSection] = useState("settings");
  const [expandedPricingOption, setExpandedPricingOption] = useState<string | null>(null);
  const [mediaSection, setMediaSection] = useState<(typeof MEDIA_SECTIONS)[number]["id"]>("home");
  const [contentSection, setContentSection] = useState<ContentSection>("home");
  const [mediaVersions, setMediaVersions] = useState<Record<string, number>>({});
  const [uploadingSlot, setUploadingSlot] = useState("");
  const [savingContent, setSavingContent] = useState(false);

  const newInquiryCount = useMemo(
    () => inquiries.filter((inquiry) => inquiry.status === "new").length,
    [inquiries],
  );
  const filteredInquiries = useMemo(
    () => inquiryFilter === "all" ? inquiries : inquiries.filter((inquiry) => inquiry.status === inquiryFilter),
    [inquiries, inquiryFilter],
  );
  const activeSectionMeta = ADMIN_SECTIONS.find((section) => section.id === activeSection) ?? ADMIN_SECTIONS[0];
  const activeContentSection = CONTENT_SECTIONS.find((section) => section.id === contentSection) ?? CONTENT_SECTIONS[0];

  const refreshInquiries = useCallback(async () => {
    const response = await fetch("/api/admin/inquiries", { cache: "no-store" });
    if (!response.ok) return;
    const payload = (await response.json()) as { inquiries?: AdminInquiry[] };
    if (payload.inquiries) setInquiries(payload.inquiries);
  }, []);

  useEffect(() => {
    const timer = window.setInterval(refreshInquiries, 30_000);
    return () => window.clearInterval(timer);
  }, [refreshInquiries]);

  useEffect(() => {
    if (!priceDetailInquiry) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setPriceDetailInquiry(null);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [priceDetailInquiry]);

  const changeInquiryStatus = async (inquiry: AdminInquiry, status: InquiryStatus) => {
    setMessage("");
    const response = await fetch(`/api/admin/inquiries/${inquiry.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const payload = (await response.json()) as { error?: string };
    if (!response.ok) {
      setMessage(payload.error ?? "문의 상태를 변경하지 못했습니다.");
      return;
    }
    setInquiries((current) =>
      current.map((item) => (item.id === inquiry.id ? { ...item, status } : item)),
    );
  };

  const savePricing = async () => {
    setSavingPricing(true);
    setMessage("");
    try {
      const response = await fetch("/api/admin/pricing", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(pricingUpdate),
      });
      const payload = (await response.json()) as { catalog?: PricingCatalog; error?: string };
      if (!response.ok || !payload.catalog) {
        throw new Error(payload.error ?? "단가를 저장하지 못했습니다.");
      }
      setCatalog(payload.catalog);
      setPricingUpdate(catalogToUpdate(payload.catalog));
      setMessage(`단가표 ${payload.catalog.version}이 적용되었습니다.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "단가를 저장하지 못했습니다.");
    } finally {
      setSavingPricing(false);
    }
  };

  const updateProcessOption = (
    groupId: string,
    optionId: string,
    patch: Partial<Pick<ProcessOption, "label" | "amount" | "mode">>,
  ) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: updateOptionAtPath(current.processGroups, groupId, [optionId], (option) => {
        Object.assign(option, patch);
      }),
    }));
  };

  const updateProcessGroup = (
    groupId: string,
    patch: Partial<Pick<EditableProcessGroup, "label" | "description">>,
  ) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: current.processGroups.map((group) =>
        group.id === groupId ? { ...group, ...patch } : group,
      ),
    }));
  };

  const addProcessGroup = () => {
    const groupId = createPricingId("group");
    setPricingUpdate((current) => ({
      ...current,
      processGroups: [
        ...current.processGroups,
        {
          id: groupId,
          label: "새 공정",
          description: "필요한 공정 범위를 안내해 주세요.",
          options: [{
            id: createPricingId("option"),
            label: "기본 옵션",
            amount: 0,
            mode: "perPyeong",
            details: [],
          }],
        },
      ],
    }));
    setPricingSection(groupId);
    setExpandedPricingOption(null);
    setMessage("새 공정을 추가했습니다. 공정명과 옵션을 입력한 뒤 ‘변경 단가 적용’을 눌러 저장해 주세요.");
  };

  const removeProcessGroup = (groupId: string) => {
    setPricingUpdate((current) => {
      if (current.processGroups.length === 1) return current;
      return {
        ...current,
        processGroups: current.processGroups.filter((group) => group.id !== groupId),
      };
    });
    setPricingSection("settings");
    setExpandedPricingOption(null);
  };

  const updateSpaceType = (
    spaceTypeId: string,
    patch: Partial<Pick<SpaceType, "label" | "multiplier" | "description">>,
  ) => {
    setPricingUpdate((current) => ({
      ...current,
      spaceTypes: current.spaceTypes.map((spaceType) =>
        spaceType.id === spaceTypeId ? { ...spaceType, ...patch } : spaceType,
      ),
    }));
  };

  const addSpaceType = () => {
    setPricingUpdate((current) => ({
      ...current,
      spaceTypes: [
        ...current.spaceTypes,
        {
          id: createPricingId("space"),
          label: "새 업종",
          multiplier: 1,
          description: "견적 배수 조정이 필요한 업종",
        },
      ],
    }));
    setMessage("새 업종을 추가했습니다. 업종명과 배수를 입력한 뒤 ‘변경 단가 적용’을 눌러 저장해 주세요.");
  };

  const removeSpaceType = (spaceTypeId: string) => {
    if (pricingUpdate.spaceTypes.length <= 1) {
      setMessage("견적 계산을 위해 업종은 최소 1개가 필요합니다.");
      return;
    }
    setPricingUpdate((current) => ({
      ...current,
      spaceTypes: current.spaceTypes.filter((spaceType) => spaceType.id !== spaceTypeId),
    }));
    setMessage("업종을 삭제했습니다. ‘변경 단가 적용’을 누르기 전에는 새로고침으로 되돌릴 수 있습니다.");
  };

  const addProcessOption = (groupId: string) => {
    const optionId = createPricingId("option");
    setPricingUpdate((current) => ({
      ...current,
      processGroups: current.processGroups.map((group) =>
        group.id === groupId
          ? {
              ...group,
              options: [
                ...group.options,
                {
                  id: optionId,
                  label: "새 옵션",
                  amount: 0,
                  mode: "perPyeong" as const,
                  details: [],
                },
              ],
            }
          : group,
      ),
    }));
    setExpandedPricingOption(`${groupId}:${optionId}`);
    setMessage("새 옵션을 추가했습니다. 내용을 입력한 뒤 ‘변경 단가 적용’을 눌러 저장해 주세요.");
  };

  const removeProcessOption = (groupId: string, optionId: string) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: current.processGroups.map((group) =>
        group.id === groupId && group.options.length > 1
          ? { ...group, options: group.options.filter((option) => option.id !== optionId) }
          : group,
      ),
    }));
    setExpandedPricingOption((current) => current === `${groupId}:${optionId}` ? null : current);
  };

  const updateDetailOption = (
    groupId: string,
    path: OptionPath,
    patch: Partial<Pick<ProcessOption, "label" | "amount" | "mode">>,
  ) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: updateOptionAtPath(current.processGroups, groupId, path, (option) => {
        Object.assign(option, patch);
      }),
    }));
  };

  const addDetailOption = (groupId: string, parentPath: OptionPath, mode: PricingMode) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: updateOptionAtPath(current.processGroups, groupId, parentPath, (option) => {
        option.details ??= [];
        option.details.push({
          id: createPricingId("detail"),
          label: "새 하위 옵션",
          amount: 0,
          mode,
          details: [],
        });
      }),
    }));
    setMessage("새 하위 옵션을 추가했습니다. 내용을 입력한 뒤 ‘변경 단가 적용’을 눌러 저장해 주세요.");
  };

  const removeDetailOption = (groupId: string, path: OptionPath) => {
    setPricingUpdate((current) => ({
      ...current,
      processGroups: removeOptionAtPath(current.processGroups, groupId, path),
    }));
  };

  const downloadInquiriesCsv = () => {
    const rows = inquiries.map((inquiry) => {
      const selectedProcesses = getSelectedOptions(inquiry.selections, catalog)
        .map(({ group, option, details }) =>
          `${group.label}: ${[option, ...details].map((item) => item.label).join(" · ")}`,
        )
        .join(" / ");
      return [
        inquiry.createdAt,
        STATUS_LABELS[inquiry.status],
        inquiry.name,
        inquiry.phone,
        inquiry.address,
        inquiry.constructionSchedule,
        inquiry.area,
        selectedProcesses,
        inquiry.midpoint,
        inquiry.minimum,
        inquiry.maximum,
        inquiry.catalogVersion,
      ];
    });
    const headers = [
      "접수일시",
      "상태",
      "이름",
      "연락처",
      "주소",
      "공사 예상 시기",
      "면적(평)",
      "선택 공정",
      "기준 금액(원)",
      "최저 금액(원)",
      "최고 금액(원)",
      "단가표 버전",
    ];
    const csv = [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `화담아이디_견적문의_${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const uploadMedia = async (slotId: string, file: File) => {
    setUploadingSlot(slotId);
    setMessage("");
    try {
      const formData = new FormData();
      formData.append("image", file);
      const response = await fetch(`/api/media/${slotId}`, { method: "POST", body: formData });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "이미지를 교체하지 못했습니다.");
      setMediaVersions((current) => ({ ...current, [slotId]: Date.now() }));
      setMessage("이미지가 사이트에 적용되었습니다.");
      return true;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "이미지를 교체하지 못했습니다.");
      return false;
    } finally {
      setUploadingSlot("");
    }
  };

  const resetMedia = async (slotId: string) => {
    setUploadingSlot(slotId);
    setMessage("");
    try {
      const response = await fetch(`/api/media/${slotId}`, { method: "DELETE" });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "기본 이미지로 되돌리지 못했습니다.");
      setMediaVersions((current) => ({ ...current, [slotId]: Date.now() }));
      setMessage("기본 이미지로 되돌렸습니다.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "기본 이미지로 되돌리지 못했습니다.");
    } finally {
      setUploadingSlot("");
    }
  };

  const saveContent = async () => {
    setSavingContent(true);
    setMessage("");
    try {
      const response = await fetch("/api/admin/content", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(siteContent),
      });
      const payload = (await response.json()) as { content?: SiteContent; error?: string };
      if (!response.ok || !payload.content) throw new Error(payload.error ?? "사이트 문구를 저장하지 못했습니다.");
      setSiteContent(payload.content);
      setMessage("사이트 문구가 저장되었습니다.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "사이트 문구를 저장하지 못했습니다.");
    } finally {
      setSavingContent(false);
    }
  };

  const updateHome = <K extends keyof SiteContent["home"]>(key: K, value: SiteContent["home"][K]) => {
    setSiteContent((current) => ({ ...current, home: { ...current.home, [key]: value } }));
  };

  const updatePortfolio = <K extends keyof SiteContent["portfolio"]>(key: K, value: SiteContent["portfolio"][K]) => {
    setSiteContent((current) => ({ ...current, portfolio: { ...current.portfolio, [key]: value } }));
  };

  const updatePortfolioProject = (
    projectId: string,
    patch: Partial<SiteContent["portfolio"]["projects"][number]>,
  ) => {
    setSiteContent((current) => ({
      ...current,
      portfolio: {
        ...current.portfolio,
        projects: current.portfolio.projects.map((project) => (
          project.id === projectId ? { ...project, ...patch } : project
        )),
      },
    }));
  };

  const addPortfolioProject = () => {
    const id = createPricingId("project");
    setSiteContent((current) => ({
      ...current,
      portfolio: {
        ...current.portfolio,
        projects: [
          ...current.portfolio.projects,
          {
            id,
            slug: id,
            title: "새 포트폴리오",
            category: "공간 소개",
            type: "상업 공간 인테리어",
            scope: "기획 · 설계 · 시공",
            summary: "프로젝트 개요를 입력해 주세요.",
            designNote: "디자인 노트를 입력해 주세요.",
            shape: "landscape",
            coverSlot: portfolioCoverSlot(id),
            gallerySlots: [],
          },
        ],
      },
    }));
    setMessage("새 포트폴리오를 추가했습니다. 내용과 대표 이미지를 입력한 뒤 ‘문구 저장’을 눌러 주세요.");
  };

  const removePortfolioProject = (projectId: string) => {
    setSiteContent((current) => {
      if (current.portfolio.projects.length <= 1) return current;
      return {
        ...current,
        portfolio: {
          ...current.portfolio,
          projects: current.portfolio.projects.filter((project) => project.id !== projectId),
        },
      };
    });
    setMessage("포트폴리오를 목록에서 삭제했습니다. 변경을 확정하려면 ‘문구 저장’을 눌러 주세요.");
  };

  const addPortfolioGalleryImages = async (projectId: string, selectedFiles: FileList | readonly File[]) => {
    const project = siteContent.portfolio.projects.find((candidate) => candidate.id === projectId);
    if (!project) return;

    const remainingSlots = 10 - project.gallerySlots.length;
    const files = Array.from(selectedFiles).slice(0, Math.max(remainingSlots, 0));
    if (files.length === 0) {
      setMessage("상세 사진은 프로젝트당 최대 10장까지 등록할 수 있습니다.");
      return;
    }

    const addedSlots: string[] = [];
    for (const file of files) {
      const slotId = portfolioGallerySlot(project.id, createPricingId("gallery"));
      if (await uploadMedia(slotId, file)) addedSlots.push(slotId);
    }

    if (addedSlots.length === 0) return;

    setSiteContent((current) => ({
      ...current,
      portfolio: {
        ...current.portfolio,
        projects: current.portfolio.projects.map((candidate) => (
          candidate.id === projectId
            ? { ...candidate, gallerySlots: [...candidate.gallerySlots, ...addedSlots] }
            : candidate
        )),
      },
    }));
    const omittedCount = Math.max(0, Array.from(selectedFiles).length - files.length);
    setMessage(`${addedSlots.length}장의 상세 사진을 추가했습니다.${omittedCount ? " 프로젝트당 최대 10장까지만 등록됩니다." : ""} 목록에 반영하려면 ‘문구 저장’을 눌러 주세요.`);
  };

  const removePortfolioGalleryImage = async (projectId: string, slotId: string) => {
    setUploadingSlot(slotId);
    setMessage("");
    try {
      const response = await fetch(`/api/media/${slotId}`, { method: "DELETE" });
      const payload = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "상세 사진을 삭제하지 못했습니다.");
      setMediaVersions((current) => ({ ...current, [slotId]: Date.now() }));
      setSiteContent((current) => ({
        ...current,
        portfolio: {
          ...current.portfolio,
          projects: current.portfolio.projects.map((project) => (
            project.id === projectId
              ? { ...project, gallerySlots: project.gallerySlots.filter((slot) => slot !== slotId) }
              : project
          )),
        },
      }));
      setMessage("상세 사진을 삭제했습니다. 목록에 반영하려면 ‘문구 저장’을 눌러 주세요.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "상세 사진을 삭제하지 못했습니다.");
    } finally {
      setUploadingSlot("");
    }
  };

  const updateProcess = <K extends keyof SiteContent["process"]>(key: K, value: SiteContent["process"][K]) => {
    setSiteContent((current) => ({ ...current, process: { ...current.process, [key]: value } }));
  };

  const updateLocation = <K extends keyof SiteContent["location"]>(key: K, value: SiteContent["location"][K]) => {
    setSiteContent((current) => ({ ...current, location: { ...current.location, [key]: value } }));
  };

  return (
    <main className={`admin-shell ${sidebarCollapsed ? "sidebar-collapsed" : ""}`}>
      <aside className={`admin-sidebar ${sidebarCollapsed ? "is-collapsed" : ""}`}>
        <div className="admin-sidebar-brand">
          <strong>화담아이디</strong>
          <button
            className="admin-sidebar-toggle"
            type="button"
            aria-label={sidebarCollapsed ? "사이드바 펼치기" : "사이드바 접기"}
            aria-expanded={!sidebarCollapsed}
            onClick={() => setSidebarCollapsed((collapsed) => !collapsed)}
          >
            <span aria-hidden="true">{sidebarCollapsed ? "›" : "‹"}</span>
          </button>
        </div>
        <nav aria-label="관리 메뉴">
          <div className="admin-primary-nav">
            {ADMIN_SECTIONS.map((section) => (
              <button
                type="button"
                key={section.id}
                className={activeSection === section.id ? "active" : ""}
                aria-current={activeSection === section.id ? "page" : undefined}
                data-label={section.label}
                title={sidebarCollapsed ? section.label : undefined}
                onClick={() => setActiveSection(section.id)}
              >
                <span className={`admin-nav-icon admin-nav-icon--${section.id}`} aria-hidden="true">
                  {section.id === "inquiries" ? "○" : section.id === "pricing" ? "₩" : section.id === "media" ? "▣" : "가"}
                </span>
                <strong>{section.label}</strong>
              </button>
            ))}
          </div>
        </nav>
        <div className="admin-sidebar-footer">
          <a href="/" aria-label="사이트 보기" title={sidebarCollapsed ? "사이트 보기" : undefined}>사이트 보기 ↗</a>
          <a href={signOutHref} aria-label="로그아웃" title={sidebarCollapsed ? "로그아웃" : undefined}>로그아웃</a>
        </div>
      </aside>

      <div className="admin-workspace">
        <section className="admin-overview">
          <div className="admin-page-title">
            <p>화담아이디 관리자</p>
            <h1>{activeSectionMeta.label}</h1>
          </div>
          {activeSection === "inquiries" && (
            <div className="admin-metrics">
              <article><span>신규 문의</span><strong>{newInquiryCount}</strong></article>
              <article><span>전체 문의</span><strong>{inquiries.length}</strong></article>
            </div>
          )}
        </section>

        {message && <p className="admin-message" role="status">{message}</p>}

      {activeSection === "inquiries" && (
        <section className="admin-section" role="tabpanel">
          <div className="admin-section-heading">
            <div><h2>{INQUIRY_FILTERS.find((filter) => filter.id === inquiryFilter)?.label ?? "견적 문의"}</h2><p>고객이 접수한 견적 요청을 확인하고 진행 상태를 변경할 수 있습니다.</p></div>
            <div className="admin-heading-actions"><small>30초마다 자동 업데이트</small><button type="button" onClick={refreshInquiries}>새로고침</button><button type="button" onClick={downloadInquiriesCsv} disabled={inquiries.length === 0}>엑셀용 CSV 다운로드</button></div>
          </div>
          <nav className="admin-section-tabs" aria-label="견적 문의 상태">
            {INQUIRY_FILTERS.map((filter) => (
              <button type="button" key={filter.id} className={inquiryFilter === filter.id ? "active" : ""} onClick={() => setInquiryFilter(filter.id)}>
                <span>{filter.label}</span><b>{filter.id === "all" ? inquiries.length : inquiries.filter((inquiry) => inquiry.status === filter.id).length}</b>
              </button>
            ))}
          </nav>
          {filteredInquiries.length === 0 ? (
            <div className="admin-empty"><strong>해당 상태의 문의가 없습니다.</strong><p>새 문의가 접수되거나 상태가 변경되면 이곳에 표시됩니다.</p></div>
          ) : (
            <div className="inquiry-table-wrap">
              <table className="inquiry-table">
                <thead><tr><th>접수</th><th>고객</th><th>공간</th><th>예상 견적</th><th>단가 기준</th><th>상태</th></tr></thead>
                <tbody>
                  {filteredInquiries.map((inquiry) => (
                    <tr key={inquiry.id}>
                      <td><strong>{formatDate(inquiry.createdAt)}</strong><small>{inquiry.id.slice(0, 8)}</small></td>
                      <td><strong>{inquiry.name}</strong><a href={`tel:${inquiry.phone}`}>{inquiry.phone}</a><small>{inquiry.address}</small></td>
                      <td><strong>{inquiry.area}평 · {inquiry.selectedCount}개 공정</strong><small>{inquiry.constructionSchedule}</small></td>
                      <td><strong>{formatWon(inquiry.midpoint)}</strong><small>{formatWon(inquiry.minimum)} ~ {formatWon(inquiry.maximum)}</small></td>
                      <td>
                        <button className="inquiry-rate-button" type="button" onClick={() => setPriceDetailInquiry(inquiry)}>
                          단가 확인
                        </button>
                      </td>
                      <td>
                        <select value={inquiry.status} onChange={(event) => changeInquiryStatus(inquiry, event.target.value as InquiryStatus)} aria-label={`${inquiry.name} 문의 상태`}>
                          {Object.entries(STATUS_LABELS).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {priceDetailInquiry && (
        <div className="inquiry-rate-modal" role="presentation" onClick={() => setPriceDetailInquiry(null)}>
          <section
            className="inquiry-rate-modal-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="inquiry-rate-modal-title"
            onClick={(event) => event.stopPropagation()}
          >
            <header>
              <div>
                <p>견적 단가 기준</p>
                <h2 id="inquiry-rate-modal-title">{priceDetailInquiry.name}님의 견적</h2>
              </div>
              <button type="button" className="inquiry-rate-modal-close" aria-label="단가 기준 닫기" onClick={() => setPriceDetailInquiry(null)}>×</button>
            </header>

            <dl className="inquiry-rate-summary">
              <div><dt>적용 단가표</dt><dd>{priceDetailInquiry.catalogVersion}</dd></div>
              <div><dt>적용 시점</dt><dd>{formatDateOnly(priceDetailInquiry.catalogEffectiveFrom)}부터</dd></div>
              <div><dt>기준 예상 금액</dt><dd>{formatWon(priceDetailInquiry.midpoint)}</dd></div>
              <div><dt>예상 범위</dt><dd>{formatWon(priceDetailInquiry.minimum)} ~ {formatWon(priceDetailInquiry.maximum)}</dd></div>
            </dl>

            <section className="inquiry-rate-breakdown">
              <div><h3>공정별 반영 금액</h3><p>접수 당시 선택한 공정과 단가를 기준으로 계산된 금액입니다.</p></div>
              {priceDetailInquiry.breakdown.length > 0 ? (
                <ul>
                  {priceDetailInquiry.breakdown.map((item) => (
                    <li key={item.id}>
                      <div><strong>{item.label}</strong><span>{item.detail}</span></div>
                      <b>{formatWon(item.amount)}</b>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="inquiry-rate-empty">이 문의에는 공정별 단가 내역이 저장되지 않았습니다.</p>
              )}
            </section>
          </section>
        </div>
      )}

      {activeSection === "pricing" && (
        <section className="admin-section pricing-admin" role="tabpanel">
          <div className="admin-section-heading">
            <div><h2>단가 관리</h2><p>변경한 단가는 고객 견적 계산에 바로 적용됩니다.</p></div>
            <button className="admin-save" type="button" onClick={savePricing} disabled={savingPricing}>{savingPricing ? "저장 중" : "변경 단가 적용"}</button>
          </div>
          <nav className="admin-section-tabs pricing-section-tabs" aria-label="단가 관리 항목">
            <button type="button" className={pricingSection === "settings" ? "active" : ""} onClick={() => { setPricingSection("settings"); setExpandedPricingOption(null); }}><span>기본 설정</span></button>
            <button type="button" className={pricingSection === "multipliers" ? "active" : ""} onClick={() => { setPricingSection("multipliers"); setExpandedPricingOption(null); }}><span>업종별 배수</span></button>
            <i aria-hidden="true" />
            {pricingUpdate.processGroups.map((group) => (
              <button type="button" key={group.id} className={pricingSection === group.id ? "active" : ""} onClick={() => { setPricingSection(group.id); setExpandedPricingOption(null); }}>
                <span>{group.label}</span><b>{group.options.length}</b>
              </button>
            ))}
            <button type="button" className="pricing-process-group-add" onClick={addProcessGroup}><span>＋ 공정 추가</span></button>
          </nav>

          {pricingSection === "settings" && (
            <div className="admin-subsection-panel">
              <div className="admin-subsection-heading"><span>01</span><div><h3>기본 설정</h3><p>전체 견적에 공통으로 적용되는 기준입니다.</p></div></div>
              <div className="pricing-settings-grid">
                <label><span>현장관리·보양 실비</span><div><input type="number" min="0" step="10000" value={pricingUpdate.managementCostPerPyeong} onChange={(event) => setPricingUpdate((current) => ({ ...current, managementCostPerPyeong: Number(event.target.value) }))} /><small>원 / 평</small></div><p>인력·안전·보양 등 현장 운영비이며 기업 이윤과 별도입니다.</p></label>
                <label><span>기업 이윤율</span><div><input type="number" min="0" max="50" step="1" value={Math.round(pricingUpdate.businessMarginRate * 100)} onChange={(event) => setPricingUpdate((current) => ({ ...current, businessMarginRate: Number(event.target.value) / 100 }))} /><small>%</small></div><p>기본 공사비와 현장 실비 합계에 적용됩니다. 0%면 별도 합산하지 않습니다.</p></label>
                <label><span>예상 견적 오차 범위</span><div><input type="number" min="1" max="50" step="1" value={Math.round(pricingUpdate.estimateRangeRate * 100)} onChange={(event) => setPricingUpdate((current) => ({ ...current, estimateRangeRate: Number(event.target.value) / 100 }))} /><small>%</small></div><p>현장 조건에 따라 안내되는 예상 견적의 범위입니다.</p></label>
              </div>
            </div>
          )}

          {pricingSection === "multipliers" && (
            <div className="admin-subsection-panel">
              <div className="admin-subsection-heading"><span>02</span><div><h3>업종별 배수</h3><p>업종을 추가하고 공간 성격에 따라 견적 배수를 설정합니다.</p></div></div>
              <div className="multiplier-editor">
                <div className="multiplier-editor-grid">
                  {pricingUpdate.spaceTypes.map((spaceType) => (
                    <article className="multiplier-editor-card" key={spaceType.id}>
                      <label><span>업종명</span><input value={spaceType.label} maxLength={30} onChange={(event) => updateSpaceType(spaceType.id, { label: event.target.value })} /></label>
                      <label><span>견적 배수</span><input type="number" min="0.5" max="3" step="0.05" value={spaceType.multiplier} onChange={(event) => updateSpaceType(spaceType.id, { multiplier: Number(event.target.value) })} /></label>
                      <label className="multiplier-description"><span>설명</span><input value={spaceType.description} maxLength={120} onChange={(event) => updateSpaceType(spaceType.id, { description: event.target.value })} /></label>
                      <button
                        type="button"
                        className="multiplier-remove-button"
                        disabled={pricingUpdate.spaceTypes.length === 1}
                        onClick={() => removeSpaceType(spaceType.id)}
                      >
                        업종 삭제
                      </button>
                    </article>
                  ))}
                </div>
                <button type="button" className="pricing-add-button multiplier-add-button" onClick={addSpaceType}>＋ 업종 추가</button>
              </div>
            </div>
          )}

          {pricingSection !== "settings" && pricingSection !== "multipliers" && (
          <div className="process-price-editor">
            {pricingUpdate.processGroups.filter((group) => group.id === pricingSection).map((group) => (
              <article key={group.id}>
                <header>
                  <div className="pricing-group-heading-fields">
                    <label><span>공정명</span><input value={group.label} maxLength={40} onChange={(event) => updateProcessGroup(group.id, { label: event.target.value })} /></label>
                    <label><span>고객 안내 문구</span><input value={group.description} maxLength={120} onChange={(event) => updateProcessGroup(group.id, { description: event.target.value })} /></label>
                  </div>
                  <div className="pricing-group-heading-actions">
                    <button type="button" className="pricing-add-button" onClick={() => addProcessOption(group.id)}>＋ 옵션 추가</button>
                    <button type="button" className="pricing-remove-button" disabled={pricingUpdate.processGroups.length === 1} onClick={() => removeProcessGroup(group.id)}>공정 삭제</button>
                  </div>
                </header>
                <div className="pricing-option-list">
                  {group.options.map((option, optionIndex) => {
                    const optionKey = `${group.id}:${option.id}`;
                    const expanded = expandedPricingOption === optionKey;
                    return (
                      <section className={`pricing-option-card ${expanded ? "expanded" : ""}`} key={option.id}>
                        <div className="pricing-option-summary">
                          <span>{String(optionIndex + 1).padStart(2, "0")}</span>
                          <div><strong>{option.label}</strong><small>{PRICING_MODE_LABELS[option.mode]} · {formatWon(option.amount)} · 하위 {countNestedOptions(option.details ?? [])}개</small></div>
                          <button type="button" className="pricing-option-toggle" aria-expanded={expanded} onClick={() => setExpandedPricingOption(expanded ? null : optionKey)}>{expanded ? "접기" : "편집"}</button>
                          <button type="button" className="pricing-remove-button" disabled={group.options.length === 1} onClick={() => removeProcessOption(group.id, option.id)}>삭제</button>
                        </div>

                        {expanded && (
                          <div className="pricing-option-body">
                            <div className="pricing-option-fields">
                              <label><span>옵션명</span><input value={option.label} onChange={(event) => updateProcessOption(group.id, option.id, { label: event.target.value })} /></label>
                              <label>
                                <span>계산 방식</span>
                                <select value={option.mode} onChange={(event) => updateProcessOption(group.id, option.id, { mode: event.target.value as PricingMode })}>
                                  <option value="perPyeong">평당 단가</option>
                                  <option value="fixed">고정 금액</option>
                                  <option value="perMeter">1m당 단가 · 실측 후 산정</option>
                                </select>
                              </label>
                              <label><span>기본 단가</span><div><input type="number" min="0" step="10000" value={option.amount} onChange={(event) => updateProcessOption(group.id, option.id, { amount: Number(event.target.value) })} /><small>원 · 0원 가능</small></div></label>
                            </div>

                            <div className="pricing-detail-editor">
                              <header>
                                <span>하위 옵션 <small>각 하위 옵션 아래에 다시 옵션을 계속 추가할 수 있습니다.</small></span>
                                <button type="button" onClick={() => addDetailOption(group.id, [option.id], option.mode)}>＋ 하위 옵션 추가</button>
                              </header>
                              {(option.details ?? []).length > 0 ? (
                                <NestedPricingOptionList
                                  groupId={group.id}
                                  options={option.details ?? []}
                                  parentPath={[option.id]}
                                  onUpdate={updateDetailOption}
                                  onAdd={addDetailOption}
                                  onRemove={removeDetailOption}
                                />
                              ) : (
                                <p>등록된 하위 옵션이 없습니다.</p>
                              )}
                            </div>
                          </div>
                        )}
                      </section>
                    );
                  })}
                </div>
              </article>
            ))}
          </div>
          )}
        </section>
      )}

      {activeSection === "media" && (
        <section className="admin-section media-admin" role="tabpanel">
          <div className="admin-section-heading">
            <div><h2>이미지 관리</h2><p>JPG, PNG, WEBP, AVIF 형식의 12MB 이하 이미지를 사용할 수 있습니다.</p></div>
          </div>
          <nav className="admin-section-tabs" aria-label="이미지 영역">
            {MEDIA_SECTIONS.map((section) => (
              <button type="button" key={section.id} className={mediaSection === section.id ? "active" : ""} onClick={() => setMediaSection(section.id)}>
                <span>{section.label}</span><b>{MEDIA_SLOTS.filter((slot) => slot.section === section.id).length}</b>
              </button>
            ))}
          </nav>

          {MEDIA_SECTIONS.filter((section) => section.id === mediaSection).map((section) => (
            <div className="media-section" key={section.id}>
              <header>
                <div><h3>{section.label}</h3><p>{section.description}</p></div>
                <div className="media-section-location"><span>현재 위치</span><strong>{section.location}</strong><a href={section.href} target="_blank" rel="noreferrer">페이지에서 보기 <i aria-hidden="true">↗</i></a></div>
              </header>
              <div className="media-grid">
                {MEDIA_SLOTS.filter((slot) => slot.section === section.id).map((slot) => {
                  const busy = uploadingSlot === slot.id;
                  const previewUrl = `/api/media/${slot.id}?v=${mediaVersions[slot.id] ?? 0}`;
                  return (
                    <article className="media-card" key={slot.id}>
                      <figure className={`media-preview ${slot.ratio}`}><img src={previewUrl} alt={`${slot.label} 현재 이미지`} /><figcaption>{slot.location}</figcaption></figure>
                      <div className="media-card-body">
                        <strong>{slot.label}</strong>
                        <small>{slot.ratio === "responsive" ? "가로·세로 모두 가능" : slot.ratio === "landscape" ? "가로형 권장" : slot.ratio === "portrait" ? "세로형 권장" : "정사각형 권장"}</small>
                        <p className="media-slot-description">{slot.description}</p>
                        <a className="media-location-link" href={slot.href} target="_blank" rel="noreferrer">이 위치 보기 <span aria-hidden="true">↗</span></a>
                        <div className="media-card-actions">
                          <label className="media-upload-button">
                            <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" disabled={busy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void uploadMedia(slot.id, file); event.target.value = ""; }} />
                            {busy ? "처리 중" : "이미지 교체"}
                          </label>
                          <button type="button" disabled={busy} onClick={() => resetMedia(slot.id)}>기본 이미지</button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </div>
          ))}
        </section>
      )}

      {activeSection === "content" && (
        <section className="admin-section content-admin" role="tabpanel">
          <div className="admin-section-heading">
            <div><h2>텍스트 관리</h2><p>줄바꿈이 필요한 제목은 입력란에서 엔터로 구분할 수 있습니다.</p></div>
            <button className="admin-save" type="button" onClick={saveContent} disabled={savingContent}>{savingContent ? "저장 중" : "문구 저장"}</button>
          </div>
          <nav className="admin-section-tabs" aria-label="텍스트 페이지">
            {CONTENT_SECTIONS.map((section) => (
              <button type="button" key={section.id} className={contentSection === section.id ? "active" : ""} onClick={() => setContentSection(section.id)}>
                <span>{section.label}</span>
              </button>
            ))}
          </nav>

          <ContentLocationGuide section={activeContentSection} />

          <div className="content-editor-sections">
            {contentSection === "home" && <article>
              <header><h3>간편 견적 제목</h3><p>메인 페이지에서 이미지 영역 아래, 견적 계산기가 시작되는 지점의 큰 제목입니다.</p></header>
              <div className="content-fields-grid">
                <TextEditorField label="큰 제목 · 견적 섹션 상단" value={siteContent.home.estimateTitle} onChange={(value) => updateHome("estimateTitle", value)} multiline />
              </div>
            </article>}

            {contentSection === "portfolio" && <article className="portfolio-content-admin">
              <header>
                <div>
                  <h3>포트폴리오 소개와 시공 사례</h3>
                  <p>왼쪽 소개 문구와 각 사례의 대표 이미지·상세 사진을 이곳에서 관리합니다.</p>
                </div>
                <button type="button" className="admin-secondary-action" onClick={addPortfolioProject}>＋ 포트폴리오 추가</button>
              </header>
              <div className="content-fields-grid">
                <TextEditorField label="큰 제목 · 왼쪽 소개 영역" value={siteContent.portfolio.title} onChange={(value) => updatePortfolio("title", value)} multiline />
                <TextEditorField label="설명 · 왼쪽 소개 영역" value={siteContent.portfolio.description} onChange={(value) => updatePortfolio("description", value)} multiline />
              </div>

              <div className="portfolio-editor-list">
                {siteContent.portfolio.projects.map((project, index) => (
                  <fieldset className="portfolio-editor-card" key={project.id}>
                    <legend>{String(index + 1).padStart(2, "0")} · {project.title}</legend>
                    <div className="portfolio-editor-heading">
                      <div>
                        <strong>시공 사례 정보</strong>
                        <span>상세 페이지 주소: /portfolio/{project.slug}</span>
                      </div>
                      <button
                        type="button"
                        className="admin-text-danger"
                        disabled={siteContent.portfolio.projects.length <= 1}
                        onClick={() => removePortfolioProject(project.id)}
                      >
                        사례 삭제
                      </button>
                    </div>

                    <div className="portfolio-editor-fields">
                      <TextEditorField label="프로젝트명" value={project.title} onChange={(value) => updatePortfolioProject(project.id, { title: value })} />
                      <TextEditorField label="주소용 이름 · 영문 소문자/숫자/하이픈" value={project.slug} onChange={(value) => updatePortfolioProject(project.id, { slug: value.toLowerCase().replace(/[^a-z0-9-]/g, "-") })} />
                      <TextEditorField label="프로젝트 유형" value={project.type} onChange={(value) => updatePortfolioProject(project.id, { type: value })} />
                      <TextEditorField label="진행 범위" value={project.scope} onChange={(value) => updatePortfolioProject(project.id, { scope: value })} />
                      <TextEditorField label="작업 키워드" value={project.category} onChange={(value) => updatePortfolioProject(project.id, { category: value })} />
                      <label className="content-field">
                        <span>목록 이미지 형태</span>
                        <select value={project.shape} onChange={(event) => updatePortfolioProject(project.id, { shape: event.target.value as PortfolioImageShape })}>
                          <option value="landscape">가로형</option>
                          <option value="portrait">세로형</option>
                          <option value="square">정사각형</option>
                        </select>
                      </label>
                      <TextEditorField label="프로젝트 개요" value={project.summary} onChange={(value) => updatePortfolioProject(project.id, { summary: value })} multiline />
                      <TextEditorField label="디자인 노트" value={project.designNote} onChange={(value) => updatePortfolioProject(project.id, { designNote: value })} multiline />
                    </div>

                    <div className="portfolio-image-editor">
                      <section>
                        <header>
                          <div><strong>대표 이미지</strong><p>포트폴리오 목록과 상세 페이지 맨 위에 표시됩니다.</p></div>
                          <label className="admin-upload-button">
                            <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => { const file = event.target.files?.[0]; if (file) void uploadMedia(project.coverSlot, file); event.currentTarget.value = ""; }} />
                            {uploadingSlot === project.coverSlot ? "업로드 중..." : "대표 이미지 변경"}
                          </label>
                        </header>
                        <figure className="portfolio-cover-preview">
                          <img src={`${mediaUrl(project.coverSlot)}?v=${mediaVersions[project.coverSlot] ?? 0}`} alt={`${project.title} 대표 이미지 미리보기`} />
                        </figure>
                      </section>

                      <section>
                        <header>
                          <div><strong>상세 사진</strong><p>한 번에 여러 장을 선택할 수 있으며, 프로젝트당 최대 10장까지 등록할 수 있습니다.</p></div>
                          <label className="admin-upload-button">
                            <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple onChange={(event) => { const files = event.target.files; if (files?.length) void addPortfolioGalleryImages(project.id, files); event.currentTarget.value = ""; }} />
                            상세 사진 여러 장 추가
                          </label>
                        </header>
                        {project.gallerySlots.length > 0 ? (
                          <div className="portfolio-gallery-preview-grid">
                            {project.gallerySlots.map((slot, galleryIndex) => (
                              <figure key={slot}>
                                <img src={`${mediaUrl(slot)}?v=${mediaVersions[slot] ?? 0}`} alt={`${project.title} 상세 사진 ${galleryIndex + 1}`} />
                                <button type="button" aria-label={`${galleryIndex + 1}번째 상세 사진 삭제`} disabled={uploadingSlot === slot} onClick={() => void removePortfolioGalleryImage(project.id, slot)}>
                                  {uploadingSlot === slot ? "삭제 중..." : "삭제"}
                                </button>
                              </figure>
                            ))}
                          </div>
                        ) : <p className="portfolio-gallery-empty">아직 등록한 상세 사진이 없습니다.</p>}
                      </section>
                    </div>
                  </fieldset>
                ))}
              </div>
            </article>}

            {contentSection === "process" && <article>
              <header><h3>진행 과정 소개와 단계</h3><p>상단 제목과 설명, 그리고 각 단계의 왼쪽 텍스트입니다. 각 단계 오른쪽 사진은 이미지 관리에서 바꿉니다.</p></header>
              <div className="content-fields-grid">
                <TextEditorField label="큰 제목 · 페이지 상단" value={siteContent.process.title} onChange={(value) => updateProcess("title", value)} multiline />
                <TextEditorField label="설명 · 페이지 상단" value={siteContent.process.description} onChange={(value) => updateProcess("description", value)} multiline />
              </div>
              <div className="content-repeat-grid">
                {siteContent.process.steps.map((step, index) => <fieldset key={index}><legend>{index + 1}단계 · 왼쪽 텍스트</legend><TextEditorField label="단계 제목" value={step.title} onChange={(value) => updateProcess("steps", siteContent.process.steps.map((item, itemIndex) => itemIndex === index ? { ...item, title: value } : item))} /><TextEditorField label="단계 설명" value={step.description} onChange={(value) => updateProcess("steps", siteContent.process.steps.map((item, itemIndex) => itemIndex === index ? { ...item, description: value } : item))} multiline /></fieldset>)}
              </div>
            </article>}

            {contentSection === "location" && <article>
              <header><h3>방문 주소, 지도와 즉시 상담</h3><p>주소를 입력하면 카카오 지도가 표시됩니다. 즉시 상담 버튼은 PC에서 전화번호를 보여주고, 모바일에서 전화 앱을 엽니다.</p></header>
              <div className="content-fields-grid">
                <TextEditorField label="방문 주소 · 상담 예약 카드" value={siteContent.location.address} onChange={(value) => updateLocation("address", value)} placeholder="예: 경기도 하남시 ..." />
                <TextEditorField label="카카오 지도 링크 · 선택" value={siteContent.location.kakaoMapUrl} onChange={(value) => updateLocation("kakaoMapUrl", value)} placeholder="https://map.kakao.com/..." />
                <TextEditorField label="즉시 상담 전화번호 · PC 안내 / 모바일 전화 앱" value={siteContent.location.consultationPhone} onChange={(value) => updateLocation("consultationPhone", value)} placeholder="010-0000-0000" />
              </div>
            </article>}

          </div>
        </section>
      )}
      </div>
    </main>
  );
}
