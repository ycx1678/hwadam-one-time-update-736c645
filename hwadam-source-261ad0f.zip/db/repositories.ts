import type { AdminInquiry, InquiryStatus } from "../lib/admin.types";
import { DEFAULT_PRICING_CATALOG, type EstimateBreakdown, type PricingCatalog } from "../lib/estimate";
import type { EstimateInquiryDraft, InquirySubmission } from "../lib/inquiry";
import { getWorkerBinding } from "../lib/runtime-env";
import { DEFAULT_SITE_CONTENT, normalizeSiteContent, type SiteContent } from "../lib/site-content";

const INQUIRY_STATUSES = new Set<InquiryStatus>(["new", "contacted", "quoted", "closed"]);

type LocalRepositories = typeof import("./repositories.local");

function useLocalStorage() {
  return typeof process !== "undefined" && process.env.HWADAM_STORAGE === "local";
}

async function getLocalRepositories(): Promise<LocalRepositories | null> {
  if (!useLocalStorage()) return null;
  return import("./repositories.local");
}

async function getD1() {
  const database = await getWorkerBinding<D1Database>("DB");
  if (!database) throw new Error("영구 저장소에 연결할 수 없습니다.");
  return database;
}

async function getMediaBucket() {
  const bucket = await getWorkerBinding<R2Bucket>("MEDIA");
  if (!bucket) throw new Error("이미지 저장소에 연결할 수 없습니다.");
  return bucket;
}

export interface SiteMediaRecord {
  slotId: string;
  objectKey: string;
  contentType: string;
  originalName: string;
  size: number;
  updatedAt: string;
}

export async function getSiteMedia(slotId: string): Promise<SiteMediaRecord | null> {
  const local = await getLocalRepositories();
  if (local) return local.getSiteMedia(slotId);
  return (await getD1())
    .prepare(
      `SELECT slot_id AS slotId, object_key AS objectKey, content_type AS contentType,
        original_name AS originalName, size, updated_at AS updatedAt
      FROM site_media WHERE slot_id = ? LIMIT 1`,
    )
    .bind(slotId)
    .first<SiteMediaRecord>();
}

export async function getSiteMediaObject(slotId: string) {
  const local = await getLocalRepositories();
  if (local) return local.getSiteMediaObject(slotId);
  const media = await getSiteMedia(slotId);
  if (!media) return null;
  const object = await (await getMediaBucket()).get(media.objectKey);
  return object ? { media, object } : null;
}

export async function replaceSiteMedia(
  slotId: string,
  file: File,
  updatedBy: string,
) {
  const local = await getLocalRepositories();
  if (local) return local.replaceSiteMedia(slotId, file, updatedBy);
  const database = await getD1();
  const bucket = await getMediaBucket();
  const previous = await getSiteMedia(slotId);
  const extension = file.type.split("/")[1]?.replace("jpeg", "jpg") ?? "bin";
  const objectKey = `site/${slotId}/${crypto.randomUUID()}.${extension}`;
  const updatedAt = new Date().toISOString();

  await bucket.put(objectKey, file.stream(), {
    httpMetadata: { contentType: file.type },
    customMetadata: { slotId, originalName: file.name },
  });

  try {
    await database
      .prepare(
        `INSERT INTO site_media (slot_id, object_key, content_type, original_name, size, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(slot_id) DO UPDATE SET object_key = excluded.object_key,
          content_type = excluded.content_type, original_name = excluded.original_name,
          size = excluded.size, updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
      )
      .bind(slotId, objectKey, file.type, file.name, file.size, updatedBy, updatedAt)
      .run();
  } catch (error) {
    await bucket.delete(objectKey);
    throw error;
  }

  if (previous && previous.objectKey !== objectKey) {
    await bucket.delete(previous.objectKey);
  }

  return { slotId, objectKey, contentType: file.type, originalName: file.name, size: file.size, updatedAt };
}

export async function removeSiteMedia(slotId: string) {
  const local = await getLocalRepositories();
  if (local) return local.removeSiteMedia(slotId);
  const database = await getD1();
  const previous = await getSiteMedia(slotId);
  if (!previous) return;
  await database.prepare("DELETE FROM site_media WHERE slot_id = ?").bind(slotId).run();
  await (await getMediaBucket()).delete(previous.objectKey);
}

export async function getSiteContent(): Promise<SiteContent> {
  const local = await getLocalRepositories();
  if (local) return local.getSiteContent();
  try {
    const row = await (await getD1())
      .prepare("SELECT content_json AS contentJson FROM site_content WHERE id = 'main' LIMIT 1")
      .first<{ contentJson: string }>();
    return row ? normalizeSiteContent(JSON.parse(row.contentJson)) : DEFAULT_SITE_CONTENT;
  } catch {
    return DEFAULT_SITE_CONTENT;
  }
}

export async function saveSiteContent(content: SiteContent, updatedBy: string) {
  const local = await getLocalRepositories();
  if (local) return local.saveSiteContent(content, updatedBy);
  const database = await getD1();
  const updatedAt = new Date().toISOString();
  await database
    .prepare(
      `INSERT INTO site_content (id, version, content_json, updated_by, updated_at)
      VALUES ('main', 1, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET version = site_content.version + 1,
        content_json = excluded.content_json, updated_by = excluded.updated_by,
        updated_at = excluded.updated_at`,
    )
    .bind(JSON.stringify(content), updatedBy, updatedAt)
    .run();
  return content;
}

export async function getActivePricingCatalog(): Promise<PricingCatalog> {
  const local = await getLocalRepositories();
  if (local) return local.getActivePricingCatalog();
  try {
    const row = await (await getD1())
      .prepare(
        "SELECT catalog_json AS catalogJson FROM pricing_catalogs WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1",
      )
      .first<{ catalogJson: string }>();
    if (!row) return DEFAULT_PRICING_CATALOG;
    return JSON.parse(row.catalogJson) as PricingCatalog;
  } catch {
    return DEFAULT_PRICING_CATALOG;
  }
}

export async function savePricingCatalog(catalog: PricingCatalog, updatedBy: string) {
  const local = await getLocalRepositories();
  if (local) return local.savePricingCatalog(catalog, updatedBy);
  const database = await getD1();
  const now = new Date().toISOString();
  const id = crypto.randomUUID();
  await database.batch([
    database.prepare("UPDATE pricing_catalogs SET is_active = 0 WHERE is_active = 1"),
    database
      .prepare(
        "INSERT INTO pricing_catalogs (id, version, catalog_json, is_active, updated_by, updated_at) VALUES (?, ?, ?, 1, ?, ?)",
      )
      .bind(id, catalog.version, JSON.stringify(catalog), updatedBy, now),
  ]);
  return catalog;
}

export async function insertEstimateInquiry(
  draft: EstimateInquiryDraft,
): Promise<InquirySubmission> {
  const local = await getLocalRepositories();
  if (local) return local.insertEstimateInquiry(draft);
  const database = await getD1();
  const id = crypto.randomUUID();
  await database
    .prepare(
      `INSERT INTO estimate_inquiries (
        id, status, created_at, updated_at, name, phone, postcode, base_address, detail_address, city, district, neighborhood,
        construction_schedule, privacy_agreed_at, space_type, area, selections_json,
        midpoint, minimum, maximum, breakdown_json, selected_count, catalog_version
      ) VALUES (?, 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .bind(
      id,
      draft.createdAt,
      draft.createdAt,
      draft.contact.name,
      draft.contact.phone,
      draft.contact.address.postcode,
      draft.contact.address.baseAddress,
      draft.contact.address.detailAddress,
      draft.contact.address.city,
      draft.contact.address.district,
      draft.contact.address.neighborhood,
      draft.contact.constructionSchedule,
      draft.privacyConsent.agreedAt,
      draft.estimate.input.spaceType,
      draft.estimate.input.area,
      JSON.stringify(draft.estimate.input.selections),
      draft.estimate.result.midpoint,
      draft.estimate.result.minimum,
      draft.estimate.result.maximum,
      JSON.stringify(draft.estimate.result.breakdown),
      draft.estimate.result.selectedCount,
      draft.estimate.result.catalogVersion,
    )
    .run();

  return { id, status: "received", receivedAt: draft.createdAt };
}

interface InquiryRow {
  id: string;
  status: InquiryStatus;
  createdAt: string;
  name: string;
  phone: string;
  postcode: string;
  baseAddress: string;
  detailAddress: string;
  city: string;
  district: string;
  neighborhood: string;
  constructionSchedule: string;
  spaceType: AdminInquiry["spaceType"];
  area: number;
  midpoint: number;
  minimum: number;
  maximum: number;
  selectedCount: number;
  catalogVersion: string;
  breakdownJson: string;
  selectionsJson: string;
}

interface PricingCatalogHistoryRow {
  version: string;
  catalogJson: string;
  updatedAt: string;
}

function parseBreakdown(value: string): EstimateBreakdown[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed as EstimateBreakdown[] : [];
  } catch {
    return [];
  }
}

export async function listEstimateInquiries(limit = 100): Promise<AdminInquiry[]> {
  const local = await getLocalRepositories();
  if (local) return local.listEstimateInquiries(limit);
  const database = await getD1();
  const [rows, catalogHistory] = await Promise.all([
    database
    .prepare(
      `SELECT id, status, created_at AS createdAt, name, phone, postcode, base_address AS baseAddress,
        detail_address AS detailAddress, city, district, neighborhood,
        construction_schedule AS constructionSchedule, space_type AS spaceType, area, midpoint,
        minimum, maximum, breakdown_json AS breakdownJson, selected_count AS selectedCount,
        catalog_version AS catalogVersion, selections_json AS selectionsJson
      FROM estimate_inquiries ORDER BY created_at DESC LIMIT ?`,
    )
    .bind(Math.min(Math.max(limit, 1), 200))
    .all<InquiryRow>(),
    database
      .prepare("SELECT version, catalog_json AS catalogJson, updated_at AS updatedAt FROM pricing_catalogs")
      .all<PricingCatalogHistoryRow>(),
  ]);

  const catalogEffectiveDates = new Map<string, string>([
    [DEFAULT_PRICING_CATALOG.version, DEFAULT_PRICING_CATALOG.effectiveFrom],
  ]);
  for (const history of catalogHistory.results) {
    try {
      const catalog = JSON.parse(history.catalogJson) as Pick<PricingCatalog, "effectiveFrom">;
      catalogEffectiveDates.set(history.version, catalog.effectiveFrom || history.updatedAt.slice(0, 10));
    } catch {
      catalogEffectiveDates.set(history.version, history.updatedAt.slice(0, 10));
    }
  }

  return rows.results.map((row) => ({
    id: row.id,
    status: row.status,
    createdAt: row.createdAt,
    name: row.name,
    phone: row.phone,
    address: [row.postcode && `(${row.postcode})`, row.baseAddress || `${row.city} ${row.district} ${row.neighborhood}`, row.detailAddress]
      .filter(Boolean)
      .join(" "),
    constructionSchedule: row.constructionSchedule,
    spaceType: row.spaceType,
    area: row.area,
    midpoint: row.midpoint,
    minimum: row.minimum,
    maximum: row.maximum,
    selectedCount: row.selectedCount,
    catalogVersion: row.catalogVersion,
    catalogEffectiveFrom: catalogEffectiveDates.get(row.catalogVersion) ?? row.createdAt.slice(0, 10),
    breakdown: parseBreakdown(row.breakdownJson),
    selections: JSON.parse(row.selectionsJson) as AdminInquiry["selections"],
  }));
}

export async function updateInquiryStatus(id: string, status: InquiryStatus) {
  const local = await getLocalRepositories();
  if (local) return local.updateInquiryStatus(id, status);
  if (!INQUIRY_STATUSES.has(status)) throw new Error("유효한 문의 상태가 아닙니다.");
  const result = await (await getD1())
    .prepare("UPDATE estimate_inquiries SET status = ?, updated_at = ? WHERE id = ?")
    .bind(status, new Date().toISOString(), id)
    .run();
  if (!result.meta.changes) throw new Error("문의 정보를 찾을 수 없습니다.");
}
