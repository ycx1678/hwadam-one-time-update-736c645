import { createHash } from "node:crypto";
import { mkdirSync } from "node:fs";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import type { AdminInquiry, InquiryStatus } from "../lib/admin.types";
import { DEFAULT_PRICING_CATALOG, type EstimateBreakdown, type PricingCatalog } from "../lib/estimate";
import type { EstimateInquiryDraft, InquirySubmission } from "../lib/inquiry";
import { DEFAULT_SITE_CONTENT, normalizeSiteContent, type SiteContent } from "../lib/site-content";
import type { SiteMediaRecord } from "./repositories";

const INQUIRY_STATUSES = new Set<InquiryStatus>(["new", "contacted", "quoted", "closed"]);

let database: DatabaseSync | null = null;
let activeDataDirectory: string | null = null;

function getDataDirectory() {
  const configured = process.env.LOCAL_DATA_DIR?.trim();
  return resolve(configured || ".local-data");
}

function getDatabase() {
  const dataDirectory = getDataDirectory();
  if (database && activeDataDirectory === dataDirectory) return database;

  database?.close();
  mkdirSync(dataDirectory, { recursive: true });
  const localDatabase = new DatabaseSync(join(dataDirectory, "hwadam.sqlite"));
  localDatabase.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS administrators (
      user_id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'owner',
      created_at TEXT NOT NULL,
      last_login_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS pricing_catalogs (
      id TEXT PRIMARY KEY,
      version TEXT NOT NULL,
      catalog_json TEXT NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_pricing_catalogs_active_updated
      ON pricing_catalogs(is_active, updated_at);

    CREATE TABLE IF NOT EXISTS estimate_inquiries (
      id TEXT PRIMARY KEY,
      status TEXT NOT NULL DEFAULT 'new',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      postcode TEXT NOT NULL DEFAULT '',
      base_address TEXT NOT NULL DEFAULT '',
      detail_address TEXT NOT NULL DEFAULT '',
      city TEXT NOT NULL,
      district TEXT NOT NULL,
      neighborhood TEXT NOT NULL,
      construction_schedule TEXT NOT NULL,
      privacy_agreed_at TEXT NOT NULL,
      space_type TEXT NOT NULL,
      area INTEGER NOT NULL,
      selections_json TEXT NOT NULL,
      midpoint INTEGER NOT NULL,
      minimum INTEGER NOT NULL,
      maximum INTEGER NOT NULL,
      breakdown_json TEXT NOT NULL,
      selected_count INTEGER NOT NULL,
      catalog_version TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_estimate_inquiries_status_created
      ON estimate_inquiries(status, created_at);
    CREATE INDEX IF NOT EXISTS idx_estimate_inquiries_created
      ON estimate_inquiries(created_at);

    CREATE TABLE IF NOT EXISTS site_media (
      slot_id TEXT PRIMARY KEY,
      object_key TEXT NOT NULL,
      content_type TEXT NOT NULL,
      original_name TEXT NOT NULL,
      size INTEGER NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS site_content (
      id TEXT PRIMARY KEY,
      version INTEGER NOT NULL DEFAULT 1,
      content_json TEXT NOT NULL,
      updated_by TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  database = localDatabase;
  activeDataDirectory = dataDirectory;
  return localDatabase;
}

function mediaPath(objectKey: string) {
  return join(getDataDirectory(), objectKey);
}

function localMedia(slotId: string): SiteMediaRecord | null {
  return getDatabase()
    .prepare(
      `SELECT slot_id AS slotId, object_key AS objectKey, content_type AS contentType,
        original_name AS originalName, size, updated_at AS updatedAt
      FROM site_media WHERE slot_id = ? LIMIT 1`,
    )
    .get(slotId) as SiteMediaRecord | undefined ?? null;
}

export async function getSiteMedia(slotId: string): Promise<SiteMediaRecord | null> {
  return localMedia(slotId);
}

export async function getSiteMediaObject(slotId: string) {
  const media = localMedia(slotId);
  if (!media) return null;

  try {
    const bytes = new Uint8Array(await readFile(mediaPath(media.objectKey)));
    return {
      media,
      object: {
        body: new Blob([bytes]).stream(),
        httpEtag: `\"${createHash("sha256").update(bytes).digest("hex")}\"`,
      },
    };
  } catch {
    return null;
  }
}

export async function replaceSiteMedia(slotId: string, file: File, updatedBy: string) {
  const previous = localMedia(slotId);
  const extension = file.type.split("/")[1]?.replace("jpeg", "jpg").replace(/[^a-z0-9]/gi, "") || "bin";
  const objectKey = `media/${slotId}/${crypto.randomUUID()}.${extension}`;
  const target = mediaPath(objectKey);
  const updatedAt = new Date().toISOString();

  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, new Uint8Array(await file.arrayBuffer()));

  try {
    getDatabase()
      .prepare(
        `INSERT INTO site_media (slot_id, object_key, content_type, original_name, size, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(slot_id) DO UPDATE SET object_key = excluded.object_key,
          content_type = excluded.content_type, original_name = excluded.original_name,
          size = excluded.size, updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
      )
      .run(slotId, objectKey, file.type, file.name, file.size, updatedBy, updatedAt);
  } catch (error) {
    await rm(target, { force: true });
    throw error;
  }

  if (previous && previous.objectKey !== objectKey) {
    await rm(mediaPath(previous.objectKey), { force: true });
  }

  return { slotId, objectKey, contentType: file.type, originalName: file.name, size: file.size, updatedAt };
}

export async function removeSiteMedia(slotId: string) {
  const previous = localMedia(slotId);
  if (!previous) return;
  getDatabase().prepare("DELETE FROM site_media WHERE slot_id = ?").run(slotId);
  await rm(mediaPath(previous.objectKey), { force: true });
}

export async function getSiteContent(): Promise<SiteContent> {
  try {
    const row = getDatabase()
      .prepare("SELECT content_json AS contentJson FROM site_content WHERE id = 'main' LIMIT 1")
      .get() as { contentJson: string } | undefined;
    return row ? normalizeSiteContent(JSON.parse(row.contentJson)) : DEFAULT_SITE_CONTENT;
  } catch {
    return DEFAULT_SITE_CONTENT;
  }
}

export async function saveSiteContent(content: SiteContent, updatedBy: string) {
  const updatedAt = new Date().toISOString();
  getDatabase()
    .prepare(
      `INSERT INTO site_content (id, version, content_json, updated_by, updated_at)
      VALUES ('main', 1, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET version = site_content.version + 1,
        content_json = excluded.content_json, updated_by = excluded.updated_by,
        updated_at = excluded.updated_at`,
    )
    .run(JSON.stringify(content), updatedBy, updatedAt);
  return content;
}

export async function getActivePricingCatalog(): Promise<PricingCatalog> {
  try {
    const row = getDatabase()
      .prepare("SELECT catalog_json AS catalogJson FROM pricing_catalogs WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1")
      .get() as { catalogJson: string } | undefined;
    return row ? JSON.parse(row.catalogJson) as PricingCatalog : DEFAULT_PRICING_CATALOG;
  } catch {
    return DEFAULT_PRICING_CATALOG;
  }
}

export async function savePricingCatalog(catalog: PricingCatalog, updatedBy: string) {
  const db = getDatabase();
  const now = new Date().toISOString();
  try {
    db.exec("BEGIN IMMEDIATE");
    db.prepare("UPDATE pricing_catalogs SET is_active = 0 WHERE is_active = 1").run();
    db.prepare(
      "INSERT INTO pricing_catalogs (id, version, catalog_json, is_active, updated_by, updated_at) VALUES (?, ?, ?, 1, ?, ?)",
    ).run(crypto.randomUUID(), catalog.version, JSON.stringify(catalog), updatedBy, now);
    db.exec("COMMIT");
  } catch (error) {
    try { db.exec("ROLLBACK"); } catch { /* no transaction to roll back */ }
    throw error;
  }
  return catalog;
}

export async function insertEstimateInquiry(draft: EstimateInquiryDraft): Promise<InquirySubmission> {
  const id = crypto.randomUUID();
  getDatabase()
    .prepare(
      `INSERT INTO estimate_inquiries (
        id, status, created_at, updated_at, name, phone, postcode, base_address, detail_address, city, district, neighborhood,
        construction_schedule, privacy_agreed_at, space_type, area, selections_json,
        midpoint, minimum, maximum, breakdown_json, selected_count, catalog_version
      ) VALUES (?, 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      draft.createdAt,
      draft.createdAt,
      draft.contact.name,
      draft.contact.phone,
      draft.contact.address.postcode,
      draft.contact.address.baseAddress,
      draft.contact.address.detailAddress,
      draft.contact.address.city,
      draft.contact.address.district,
      draft.contact.address.neighborhood,
      draft.contact.constructionSchedule,
      draft.privacyConsent.agreedAt,
      draft.estimate.input.spaceType,
      draft.estimate.input.area,
      JSON.stringify(draft.estimate.input.selections),
      draft.estimate.result.midpoint,
      draft.estimate.result.minimum,
      draft.estimate.result.maximum,
      JSON.stringify(draft.estimate.result.breakdown),
      draft.estimate.result.selectedCount,
      draft.estimate.result.catalogVersion,
    );

  return { id, status: "received", receivedAt: draft.createdAt };
}

interface InquiryRow {
  id: string;
  status: InquiryStatus;
  createdAt: string;
  name: string;
  phone: string;
  postcode: string;
  baseAddress: string;
  detailAddress: string;
  city: string;
  district: string;
  neighborhood: string;
  constructionSchedule: string;
  spaceType: AdminInquiry["spaceType"];
  area: number;
  midpoint: number;
  minimum: number;
  maximum: number;
  selectedCount: number;
  catalogVersion: string;
  breakdownJson: string;
  selectionsJson: string;
}

interface PricingCatalogHistoryRow {
  version: string;
  catalogJson: string;
  updatedAt: string;
}

function parseBreakdown(value: string): EstimateBreakdown[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed as EstimateBreakdown[] : [];
  } catch {
    return [];
  }
}

function parseSelections(value: string) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? parsed as AdminInquiry["selections"]
      : {};
  } catch {
    return {};
  }
}

export async function listEstimateInquiries(limit = 100): Promise<AdminInquiry[]> {
  const db = getDatabase();
  const rows = db.prepare(
    `SELECT id, status, created_at AS createdAt, name, phone, postcode, base_address AS baseAddress,
      detail_address AS detailAddress, city, district, neighborhood,
      construction_schedule AS constructionSchedule, space_type AS spaceType, area, midpoint,
      minimum, maximum, breakdown_json AS breakdownJson, selected_count AS selectedCount,
      catalog_version AS catalogVersion, selections_json AS selectionsJson
    FROM estimate_inquiries ORDER BY created_at DESC LIMIT ?`,
  ).all(Math.min(Math.max(limit, 1), 200)) as unknown as InquiryRow[];
  const catalogHistory = db.prepare(
    "SELECT version, catalog_json AS catalogJson, updated_at AS updatedAt FROM pricing_catalogs",
  ).all() as unknown as PricingCatalogHistoryRow[];

  const catalogEffectiveDates = new Map<string, string>([
    [DEFAULT_PRICING_CATALOG.version, DEFAULT_PRICING_CATALOG.effectiveFrom],
  ]);
  for (const history of catalogHistory) {
    try {
      const catalog = JSON.parse(history.catalogJson) as Pick<PricingCatalog, "effectiveFrom">;
      catalogEffectiveDates.set(history.version, catalog.effectiveFrom || history.updatedAt.slice(0, 10));
    } catch {
      catalogEffectiveDates.set(history.version, history.updatedAt.slice(0, 10));
    }
  }

  return rows.map((row) => ({
    id: row.id,
    status: row.status,
    createdAt: row.createdAt,
    name: row.name,
    phone: row.phone,
    address: [row.postcode && `(${row.postcode})`, row.baseAddress || `${row.city} ${row.district} ${row.neighborhood}`, row.detailAddress]
      .filter(Boolean)
      .join(" "),
    constructionSchedule: row.constructionSchedule,
    spaceType: row.spaceType,
    area: row.area,
    midpoint: row.midpoint,
    minimum: row.minimum,
    maximum: row.maximum,
    selectedCount: row.selectedCount,
    catalogVersion: row.catalogVersion,
    catalogEffectiveFrom: catalogEffectiveDates.get(row.catalogVersion) ?? row.createdAt.slice(0, 10),
    breakdown: parseBreakdown(row.breakdownJson),
    selections: parseSelections(row.selectionsJson),
  }));
}

export async function updateInquiryStatus(id: string, status: InquiryStatus) {
  if (!INQUIRY_STATUSES.has(status)) throw new Error("유효한 문의 상태가 아닙니다.");
  const result = getDatabase()
    .prepare("UPDATE estimate_inquiries SET status = ?, updated_at = ? WHERE id = ?")
    .run(status, new Date().toISOString(), id);
  if (!Number(result.changes)) throw new Error("문의 정보를 찾을 수 없습니다.");
}
