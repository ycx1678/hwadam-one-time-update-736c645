import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${pathname}`, {
      headers: { accept: "text/html", host: "localhost" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("화담아이디 견적 랜딩을 서버 렌더링한다", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<html lang="ko">/);
  assert.match(html, /화담아이디 \| 상업 인테리어 간편 견적/);
  assert.match(html, /공간의 쓰임을 이해하는/);
  assert.match(html, /image-hero/);
  assert.match(html, /menu-panel/);
  assert.match(html, /aria-controls="전체메뉴"/);
  assert.doesNotMatch(html, /site-rail/);
  assert.match(html, /\/api\/media\/home-hero-main-hq/);
  assert.match(html, /\/og\.png/);
  assert.match(html, /application\/ld\+json/);
  assert.match(html, /ProfessionalService/);
  assert.match(html, /rel="canonical"/);
  assert.doesNotMatch(html, /codex-preview|react-loading-skeleton|Your site is taking shape/);
});

test("포트폴리오와 진행 과정을 서브페이지로 제공한다", async () => {
  const pages = await Promise.all([
    render("/portfolio"),
    render("/process"),
    render("/portfolio/restaurant-space"),
    render("/location"),
    render("/sitemap.xml"),
  ]);

  for (const response of pages) {
    assert.equal(response.status, 200);
  }

  const [portfolio, process, portfolioDetail, location, sitemap] = await Promise.all(pages.map((response) => response.text()));
  assert.match(portfolio, /현장에서 완성한/);
  assert.match(portfolio, /portfolio-image-grid/);
  assert.match(portfolio, /\/api\/media\/portfolio-1-hq/);
  assert.match(portfolio, /<title>시공 포트폴리오 \| 화담아이디<\/title>/);
  assert.match(process, /프로젝트 진행 과정/);
  assert.match(process, /현장 실측/);
  assert.match(process, /<title>프로젝트 진행 과정 \| 화담아이디<\/title>/);
  assert.match(portfolioDetail, /음식점 공간/);
  assert.match(portfolioDetail, /프로젝트 개요/);
  assert.match(portfolioDetail, /\/api\/media\/portfolio-1-hq/);
  assert.match(location, /찾아오는 길/);
  assert.match(location, /location-map-frame/);
  assert.match(location, /href="tel:01062161894"/);
  assert.match(sitemap, /https:\/\/hwadamid\.com\/portfolio\/restaurant-space/);
});

test("관리자 페이지는 사이트 자체 로그인 화면을 구성한다", async () => {
  const [adminPage, adminLogin] = await Promise.all([
    readFile(new URL("../app/admin/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/AdminLogin.tsx", import.meta.url), "utf8"),
  ]);
  assert.match(adminPage, /AdminLogin/);
  assert.match(adminLogin, /관리자 로그인/);
  assert.match(adminLogin, /\/api\/admin\/session/);
  assert.doesNotMatch(adminPage, /signin-with-chatgpt|ChatGPT/);
});

test("실사진과 최종 메타데이터만 배포한다", async () => {
  const [page, portfolioPage, processPage, portfolioContent, processContent, adminPage, adminLogin, adminAuth, adminDashboard, inquiryApi, mediaApi, contentApi, mediaConfig, siteContent, layout, pricingCatalog, inquiry, inquiryServer, schema, repositories, styles, packageJson] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/portfolio/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/process/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/PortfolioPageContent.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/ProcessPageContent.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/admin/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/AdminLogin.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/admin-auth.ts", import.meta.url), "utf8"),
    readFile(new URL("../components/AdminDashboard.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/api/inquiries/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/media/[slot]/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/admin/content/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/media.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/site-content.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/estimate.catalog.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/inquiry.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/inquiry-server.ts", import.meta.url), "utf8"),
    readFile(new URL("../db/schema.ts", import.meta.url), "utf8"),
    readFile(new URL("../db/repositories.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
    readFile(new URL("../package.json", import.meta.url), "utf8"),
  ]);

  await Promise.all([
    access(new URL("../public/images/logo.jpg", import.meta.url)),
    access(new URL("../public/images/hero-restaurant.jpg", import.meta.url)),
    access(new URL("../public/images/portfolio-entry.jpg", import.meta.url)),
    access(new URL("../public/images/portfolio-hanok.jpg", import.meta.url)),
    access(new URL("../public/images/portfolio-living.jpg", import.meta.url)),
    access(new URL("../public/images/portfolio-storefront.jpg", import.meta.url)),
    access(new URL("../public/images/portfolio-wood.jpg", import.meta.url)),
    access(new URL("../public/og.png", import.meta.url)),
    access(new URL("../public/robots.txt", import.meta.url)),
  ]);

  const [robots] = await Promise.all([
    readFile(new URL("../public/robots.txt", import.meta.url), "utf8"),
  ]);

  assert.match(page, /calculateEstimate/);
  assert.match(page, /image-hero-project/);
  assert.doesNotMatch(page, /hero-word/);
  assert.doesNotMatch(page, /modern-hero-copy/);
  assert.match(page, /pricingCatalog\.processGroups/);
  assert.doesNotMatch(page, /formatUnitPrice/);
  assert.match(page, /\/api\/inquiries/);
  assert.match(page, /kakao-postcode-script/);
  assert.match(page, /주소 검색/);
  assert.match(page, /즉시 상담하기/);
  assert.match(page, /ConsultationPhoneLink/);
  assert.match(page, /견적 확인 전 안내/);
  assert.match(page, /해당 견적서는 실측 전 견적서로, 상담 후 금액이 변동할 수 있는 점 참고 부탁드립니다\./);
  assert.match(page, /filter\(\(item\) => item\.id !== "business-margin"\)/);
  assert.doesNotMatch(page, /portfolio-section|workflow-section|contact-section/);
  assert.match(portfolioPage, /PortfolioPageContent/);
  assert.match(processPage, /ProcessPageContent/);
  assert.match(portfolioContent, /useSiteContent/);
  assert.match(processContent, /useSiteContent/);
  assert.match(adminPage, /AdminLogin/);
  assert.doesNotMatch(adminPage, /ChatGPT|signin-with-chatgpt/);
  assert.match(adminLogin, /관리자 로그인/);
  assert.match(adminAuth, /HttpOnly/);
  assert.match(adminAuth, /SameSite=Strict/);
  assert.match(adminDashboard, /견적 문의/);
  assert.match(adminDashboard, /admin-sidebar/);
  assert.match(adminDashboard, /admin-section-tabs/);
  assert.doesNotMatch(adminDashboard, /admin-sidebar-subnav/);
  assert.match(adminDashboard, /pricingSection/);
  assert.match(adminDashboard, /단가 관리/);
  assert.match(adminDashboard, /이미지 관리/);
  assert.match(adminDashboard, /이미지 교체/);
  assert.match(adminDashboard, /0원 가능/);
  assert.match(adminDashboard, /텍스트 관리/);
  assert.match(adminDashboard, /찾아오는 길/);
  assert.match(adminDashboard, /문구 저장/);
  assert.match(adminDashboard, /포트폴리오 추가/);
  assert.match(adminDashboard, /대표 이미지/);
  assert.match(adminDashboard, /상세 사진 여러 장 추가/);
  assert.match(adminDashboard, /multiple/);
  assert.match(adminDashboard, /제한 없이 추가/);
  assert.match(adminDashboard, /1m당 단가/);
  assert.match(inquiryApi, /insertEstimateInquiry/);
  assert.match(mediaApi, /replaceSiteMedia/);
  assert.match(mediaApi, /MAX_IMAGE_SIZE/);
  assert.match(mediaApi, /isPortfolioMediaSlot/);
  assert.match(mediaConfig, /home-hero-main/);
  assert.match(contentApi, /normalizeSiteContent/);
  assert.match(siteContent, /DEFAULT_SITE_CONTENT/);
  assert.match(siteContent, /kakaoMapUrl/);
  assert.match(await readFile(new URL("../components/LocationPageContent.tsx", import.meta.url), "utf8"), /KakaoStaticMap/);
  assert.match(siteContent, /consultationPhone/);
  assert.match(layout, /generateMetadata/);
  assert.match(layout, /NAVER_SITE_VERIFICATION/);
  assert.match(layout, /bcee79b1c333790b5f59b43bea48734b3d57993c/);
  assert.match(layout, /Ep8Ehm53hOi0xbqhZBml0W1cWq7mBJq2uYj8p7G8g38/);
  assert.match(layout, /getSiteOrigin/);
  assert.match(layout, /pretendardvariable-dynamic-subset/);
  assert.match(layout, /ProfessionalService/);
  assert.match(robots, /Sitemap: https:\/\/hwadamid\.com\/sitemap\.xml/);
  assert.match(pricingCatalog, /PricingCatalog/);
  assert.match(inquiry, /InquiryGateway/);
  assert.match(inquiry, /baseAddress/);
  assert.match(inquiryServer, /우편번호/);
  assert.match(schema, /base_address/);
  assert.match(repositories, /detail_address/);
  assert.match(styles, /Pretendard Variable/);
  assert.doesNotMatch(packageJson, /react-loading-skeleton/);
  assert.doesNotMatch(page, /_sites-preview|SkeletonPreview/);
});
