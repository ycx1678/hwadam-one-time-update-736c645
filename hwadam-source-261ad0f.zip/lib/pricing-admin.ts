import type { PricingAdminUpdate } from "./admin.types";
import type {
  PricingCatalog,
  PricingMode,
  ProcessDetailOption,
  ProcessGroup,
  ProcessOption,
  SpaceType,
} from "./estimate";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function requireFiniteNumber(value: unknown, label: string, minimum: number, maximum: number) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < minimum || value > maximum) {
    throw new Error(`${label} 값이 허용 범위를 벗어났습니다.`);
  }
  return value;
}

function nextCatalogVersion(currentVersion: string, now: Date) {
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, "0");
  const prefix = `${year}.${month}.`;
  const currentSequence = currentVersion.startsWith(prefix)
    ? Number(currentVersion.slice(prefix.length))
    : 0;
  return `${prefix}${Number.isInteger(currentSequence) ? currentSequence + 1 : 1}`;
}

function requireText(value: unknown, label: string, maximumLength = 60) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > maximumLength) {
    throw new Error(`${label}을(를) 정확히 입력해 주세요.`);
  }
  return value.trim();
}

function requireIdentifier(value: unknown, label: string) {
  const identifier = requireText(value, label, 80);
  if (!/^[a-zA-Z0-9_-]+$/.test(identifier)) {
    throw new Error(`${label} 형식이 올바르지 않습니다.`);
  }
  return identifier;
}

function requireMode(value: unknown, label: string): PricingMode {
  if (value !== "perPyeong" && value !== "fixed" && value !== "perMeter") {
    throw new Error(`${label} 계산 방식을 선택해 주세요.`);
  }
  return value;
}

function normalizedLabel(value: string) {
  return value.trim().replace(/\s+/g, " ").toLocaleLowerCase("ko-KR");
}

function requireUniqueLabel(labels: Set<string>, value: string, message: string) {
  const key = normalizedLabel(value);
  if (labels.has(key)) throw new Error(message);
  labels.add(key);
}

function normalizeDetails(value: unknown, optionLabel: string): ProcessDetailOption[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 100) {
    throw new Error(`${optionLabel} 상세 옵션 수가 허용 범위를 벗어났습니다.`);
  }
  const ids = new Set<string>();
  const labels = new Set<string>();
  return value.map((candidate, index) => {
    if (!isRecord(candidate)) throw new Error(`${optionLabel} 상세 옵션 형식이 올바르지 않습니다.`);
    const label = requireText(candidate.label, `${optionLabel} 상세 옵션 ${index + 1}`);
    const id = requireIdentifier(candidate.id, `${label} 식별값`);
    if (ids.has(id)) throw new Error(`${optionLabel}에 중복된 상세 옵션이 있습니다.`);
    ids.add(id);
    requireUniqueLabel(labels, label, `${optionLabel}에 같은 이름의 하위 옵션이 있습니다.`);
    return {
      id,
      label,
      amount: Math.round(requireFiniteNumber(candidate.amount, `${label} 단가`, 0, 20_000_000)),
      mode: requireMode(candidate.mode, label),
      details: normalizeDetails(candidate.details, label),
    };
  });
}

function normalizeOptions(value: unknown, groupLabel: string): ProcessOption[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 100) {
    throw new Error(`${groupLabel} 옵션은 1개 이상 100개 이하로 구성해 주세요.`);
  }
  const ids = new Set<string>();
  const labels = new Set<string>();
  return value.map((candidate, index) => {
    if (!isRecord(candidate)) throw new Error(`${groupLabel} 옵션 형식이 올바르지 않습니다.`);
    const label = requireText(candidate.label, `${groupLabel} 옵션 ${index + 1}`);
    const id = requireIdentifier(candidate.id, `${label} 식별값`);
    if (ids.has(id)) throw new Error(`${groupLabel}에 중복된 옵션이 있습니다.`);
    ids.add(id);
    requireUniqueLabel(labels, label, `${groupLabel}에 같은 이름의 옵션이 있습니다.`);
    return {
      id,
      label,
      amount: Math.round(requireFiniteNumber(candidate.amount, `${label} 단가`, 0, 20_000_000)),
      mode: requireMode(candidate.mode, label),
      details: normalizeDetails(candidate.details, label),
    };
  });
}

function normalizeProcessGroups(value: unknown): ProcessGroup[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 30) {
    throw new Error("공정 대주제는 1개 이상 30개 이하로 구성해 주세요.");
  }

  const ids = new Set<string>();
  const labels = new Set<string>();
  return value.map((candidate, index) => {
    if (!isRecord(candidate)) throw new Error("공정 대주제 형식이 올바르지 않습니다.");
    const label = requireText(candidate.label, `공정 대주제 ${index + 1} 이름`, 40);
    const id = requireIdentifier(candidate.id, `${label} 식별값`);
    if (ids.has(id)) throw new Error("중복된 공정 대주제가 있습니다.");
    ids.add(id);
    requireUniqueLabel(labels, label, "같은 이름의 공정 대주제가 있습니다.");
    return {
      id,
      label,
      description: requireText(candidate.description, `${label} 설명`, 120),
      options: normalizeOptions(candidate.options, label),
    };
  });
}

function normalizeSpaceTypes(value: unknown): SpaceType[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 20) {
    throw new Error("업종은 1개 이상 20개 이하로 구성해 주세요.");
  }

  const ids = new Set<string>();
  const labels = new Set<string>();
  return value.map((candidate, index) => {
    if (!isRecord(candidate)) throw new Error("업종 형식이 올바르지 않습니다.");
    const label = requireText(candidate.label, `업종 ${index + 1} 이름`, 30);
    const id = requireIdentifier(candidate.id, `${label} 식별값`);
    if (ids.has(id)) throw new Error("중복된 업종이 있습니다.");
    ids.add(id);
    requireUniqueLabel(labels, label, "같은 이름의 업종이 있습니다.");
    return {
      id,
      label,
      multiplier: requireFiniteNumber(candidate.multiplier, `${label} 배수`, 0.5, 3),
      description: requireText(candidate.description, `${label} 설명`, 120),
    };
  });
}

export function applyPricingAdminUpdate(
  catalog: PricingCatalog,
  update: PricingAdminUpdate,
  now = new Date(),
): PricingCatalog {
  const managementCostPerPyeong = requireFiniteNumber(
    update.managementCostPerPyeong,
    "현장관리 단가",
    0,
    2_000_000,
  );
  const estimateRangeRate = requireFiniteNumber(
    update.estimateRangeRate,
    "예상 범위",
    0.01,
    0.5,
  );
  const businessMarginRate = requireFiniteNumber(
    update.businessMarginRate,
    "기업 이윤율",
    0,
    0.5,
  );

  const spaceTypes = normalizeSpaceTypes(update.spaceTypes);

  const processGroups = normalizeProcessGroups(update.processGroups);

  return {
    ...catalog,
    version: nextCatalogVersion(catalog.version, now),
    effectiveFrom: now.toISOString().slice(0, 10),
    managementCostPerPyeong: Math.round(managementCostPerPyeong),
    businessMarginRate,
    estimateRangeRate,
    spaceTypes,
    processGroups,
  };
}
