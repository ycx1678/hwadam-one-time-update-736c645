/**
 * Cloudflare에서는 Worker 바인딩을, 미니PC에서는 PM2 환경변수를 사용합니다.
 * 정적 import를 피해야 Node.js에서도 같은 앱을 실행할 수 있습니다.
 */
export async function getRuntimeValue(key: string) {
  const localValue = typeof process !== "undefined" ? process.env[key] : undefined;
  if (typeof localValue === "string" && localValue.trim()) return localValue.trim();

  try {
    const workers = await import("cloudflare:workers");
    const workerValue = (workers.env as Record<string, unknown>)[key];
    return typeof workerValue === "string" && workerValue.trim() ? workerValue.trim() : null;
  } catch {
    return null;
  }
}

export async function getWorkerBinding<T>(key: string): Promise<T | null> {
  try {
    const workers = await import("cloudflare:workers");
    return ((workers.env as Record<string, unknown>)[key] as T | undefined) ?? null;
  } catch {
    return null;
  }
}
