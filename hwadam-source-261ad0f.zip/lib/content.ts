import { mediaUrl } from "./media";

export const PORTFOLIO = [
  {
    slug: "restaurant-space",
    image: mediaUrl("portfolio-1-hq"),
    title: "음식점 공간",
    category: "브랜드와 동선이 만나는 공간",
    shape: "landscape",
    type: "음식점 인테리어",
    scope: "공간 기획 · 설계 · 시공",
    summary: "손님과 직원의 동선이 자연스럽게 교차하도록 좌석과 서비스 공간의 밀도를 세심하게 조율한 프로젝트입니다.",
    designNote: "첫인상은 편안하게, 운영은 효율적으로 이어지도록 재료의 온도와 조명 밝기를 한 흐름 안에서 설계했습니다.",
  },
  {
    slug: "commercial-lounge",
    image: mediaUrl("portfolio-2-hq"),
    title: "상업 라운지",
    category: "전통의 결을 담은 입면",
    shape: "portrait",
    type: "라운지 인테리어",
    scope: "공간 기획 · 마감 설계 · 시공",
    summary: "머무는 시간이 길어질수록 공간의 결이 드러나도록 여백과 동선을 차분하게 구성했습니다.",
    designNote: "입면의 리듬과 조도의 균형을 맞춰 브랜드가 지닌 깊이를 현대적인 방식으로 표현했습니다.",
  },
  {
    slug: "premium-store",
    image: mediaUrl("portfolio-3-hq"),
    title: "프리미엄 매장",
    category: "첫인상을 만드는 파사드",
    shape: "square",
    type: "리테일 인테리어",
    scope: "파사드 · 집기 설계 · 시공",
    summary: "방문 순간 브랜드의 분위기를 이해할 수 있도록 진입부와 상품 경험의 흐름을 설계했습니다.",
    designNote: "진열의 밀도는 낮추고 시선의 흐름은 선명하게 만들어 제품이 공간 안에서 돋보이게 했습니다.",
  },
  {
    slug: "wood-finish-space",
    image: mediaUrl("portfolio-4-hq"),
    title: "목재 마감 공간",
    category: "재료의 온도를 살린 디테일",
    shape: "square",
    type: "상업 공간 인테리어",
    scope: "마감 계획 · 가구 설계 · 시공",
    summary: "목재가 가진 질감과 시간이 쌓일수록 편안해지는 사용감을 중심에 둔 공간입니다.",
    designNote: "색과 질감의 차이를 과하게 드러내기보다, 빛에 따라 달라지는 재료의 표정을 살렸습니다.",
  },
  {
    slug: "bright-living-space",
    image: mediaUrl("portfolio-5-hq"),
    title: "밝은 주거 공간",
    category: "빛과 여백을 중심으로",
    shape: "portrait",
    type: "주거 공간 인테리어",
    scope: "공간 구성 · 마감 설계 · 시공",
    summary: "자연광의 방향과 일상의 수납 동선을 기준으로, 가볍고 밝은 생활 공간을 완성했습니다.",
    designNote: "필요한 기능은 충분히 담되, 시선이 머무는 곳에는 여백을 남겨 공간이 더 넓게 느껴지도록 했습니다.",
  },
  {
    slug: "alley-commercial-space",
    image: mediaUrl("portfolio-6-hq"),
    title: "골목 상업 공간",
    category: "기존 맥락과 어우러진 외관",
    shape: "landscape",
    type: "상업 공간 인테리어",
    scope: "리노베이션 · 공간 설계 · 시공",
    summary: "기존 건물의 분위기를 존중하면서도 새로운 브랜드 경험이 자연스럽게 드러나도록 정리했습니다.",
    designNote: "거리에서 마주하는 표정과 내부의 체류 경험이 끊기지 않도록 투명도와 재료의 대비를 조절했습니다.",
  },
] as const;

export function getPortfolioProject(slug: string) {
  return PORTFOLIO.find((project) => project.slug === slug);
}

export const WORKFLOW = [
  {
    title: "상담",
    description: "공간의 용도와 일정, 예산, 필요한 공사 범위를 함께 확인합니다.",
  },
  {
    title: "현장 실측",
    description: "현장을 방문해 치수와 설비, 기존 마감, 공사 여건을 꼼꼼히 살핍니다.",
  },
  {
    title: "설계",
    description: "동선과 운영 방식을 기준으로 평면, 마감재, 세부 견적을 구체화합니다.",
  },
  {
    title: "시공",
    description: "확정된 설계와 공정표를 기준으로 현장을 관리하며 공사를 진행합니다.",
  },
  {
    title: "마감",
    description: "완성도를 점검하고 보완 사항을 정리한 뒤 공간을 인도합니다.",
  },
] as const;
