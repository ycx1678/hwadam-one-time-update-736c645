const ERROR_MESSAGES: Record<string, string> = {
  invalid: "아이디 또는 비밀번호를 확인해 주세요.",
  config: "관리자 로그인이 아직 설정되지 않았습니다.",
  request: "올바르지 않은 요청입니다. 다시 시도해 주세요.",
};

export default function AdminLogin({ error }: Readonly<{ error?: string }>) {
  return (
    <main className="admin-login-shell">
      <section className="admin-login-card">
        <a className="admin-login-brand" href="/">화담아이디</a>
        <p>관리자 페이지</p>
        <h1>로그인</h1>
        <form action="/api/admin/session" method="post">
          <label>
            <span>아이디</span>
            <input name="username" type="text" autoComplete="username" required autoFocus />
          </label>
          <label>
            <span>비밀번호</span>
            <input name="password" type="password" autoComplete="current-password" required />
          </label>
          {error && <p className="admin-login-error" role="alert">{ERROR_MESSAGES[error] ?? ERROR_MESSAGES.invalid}</p>}
          <button type="submit">관리자 로그인</button>
        </form>
        <a className="admin-login-back" href="/">사이트로 돌아가기</a>
      </section>
    </main>
  );
}
