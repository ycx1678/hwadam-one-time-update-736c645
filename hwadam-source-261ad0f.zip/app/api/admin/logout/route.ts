import { clearAdminSessionCookie } from "../../../../lib/admin-auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const secure = new URL(request.url).protocol === "https:";
  return new Response(null, {
    status: 303,
    headers: {
      Location: new URL("/admin", request.url).toString(),
      "Set-Cookie": clearAdminSessionCookie(secure),
      "Cache-Control": "no-store",
    },
  });
}
