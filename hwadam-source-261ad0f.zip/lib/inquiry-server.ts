import { calculateEstimate, type EstimateInput, type PricingCatalog, type SpaceTypeId } from "./estimate";
import { createEstimateInquiryDraft, type EstimateInquiryDraft } from "./inquiry";

const CONSTRUCTION_SCHEDULES = new Set([
  "1개월 이내",
  "1~3개월",
  "3~6개월",
  "6개월 이후",
  "미정",
]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function requireString(value: unknown, label: string, maximumLength: number) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > maximumLength) {
    throw new Error(`${label}을(를) 정확히 입력해 주세요.`);
  }
  return value.trim();
}

export function createServerInquiryDraft(
  payload: unknown,
  catalog: PricingCatalog,
  now = new Date(),
): EstimateInquiryDraft {
  if (
    !isRecord(payload) ||
    !isRecord(payload.contact) ||
    !isRecord(payload.estimate) ||
    !isRecord(payload.privacyConsent) ||
    payload.privacyConsent.agreed !== true
  ) {
    throw new Error("견적 요청 형식이 올바르지 않습니다.");
  }

  const contact = payload.contact;
  const address = contact.address;
  const estimate = payload.estimate;
  const input = estimate.input;

  if (!isRecord(address) || !isRecord(input) || !isRecord(input.selections)) {
    throw new Error("견적 요청 형식이 올바르지 않습니다.");
  }

  const phone = requireString(contact.phone, "연락처", 20).replace(/\D/g, "");
  if (!/^01[016789]\d{7,8}$/.test(phone)) {
    throw new Error("연락처를 정확히 입력해 주세요.");
  }

  const postcode = requireString(address.postcode, "우편번호", 10);
  if (!/^\d{5}$/.test(postcode)) {
    throw new Error("주소 검색으로 우편번호를 입력해 주세요.");
  }

  const constructionSchedule = requireString(contact.constructionSchedule, "공사 예상 시기", 20);
  if (!CONSTRUCTION_SCHEDULES.has(constructionSchedule)) {
    throw new Error("공사 예상 시기를 정확히 선택해 주세요.");
  }

  const selections = Object.fromEntries(
    Object.entries(input.selections)
      .flatMap(([groupId, value]) => {
        if (typeof value === "string") return [[groupId, value]];
        if (!Array.isArray(value)) return [];
        const values = [...new Set(value.filter((item): item is string => typeof item === "string" && item.length > 0))]
          .slice(0, 100);
        return values.length ? [[groupId, values]] : [];
      })
      .slice(0, catalog.processGroups.length),
  );
  const estimateInput: EstimateInput = {
    spaceType: requireString(input.spaceType, "업종", 30) as SpaceTypeId,
    area: Number(input.area),
    selections,
  };
  const estimateResult = calculateEstimate(estimateInput, catalog);

  return createEstimateInquiryDraft({
    contact: {
      name: requireString(contact.name, "이름", 40),
      phone,
      address: {
        postcode,
        baseAddress: requireString(address.baseAddress, "기본 주소", 160),
        detailAddress: typeof address.detailAddress === "string" ? address.detailAddress.trim().slice(0, 160) : "",
        city: requireString(address.city, "시·도", 40),
        district: requireString(address.district, "시·군·구", 40),
        neighborhood: requireString(address.neighborhood, "읍·면·동", 60),
      },
      constructionSchedule,
    },
    privacyAgreed: true,
    estimateInput,
    estimateResult,
    now,
  });
}
