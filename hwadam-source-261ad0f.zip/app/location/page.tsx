import type { Metadata } from "next";
import LocationPageContent from "../../components/LocationPageContent";

export const metadata: Metadata = {
  title: "찾아오는 길",
  description: "화담아이디 방문 및 현장 상담 예약 안내입니다.",
  alternates: { canonical: "/location" },
};

export default function LocationPage() {
  return <LocationPageContent />;
}
