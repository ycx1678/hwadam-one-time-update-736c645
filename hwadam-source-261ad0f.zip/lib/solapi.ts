import type { EstimateInquiryDraft } from "./inquiry";
import { getRuntimeValue } from "./runtime-env";

const encoder = new TextEncoder();

// 솔라피 콘솔에서 검수 요청한 화담아이디 고객용 알림톡 템플릿입니다.
// 운영 환경에서 별도 템플릿을 입력하면 .env 값이 이 기본값보다 우선합니다.
const DEFAULT_CUSTOMER_TEMPLATE_ID = "KA01TP260823230624994UertNP9Ywig";
// 관리자 전용 템플릿을 아직 등록하지 않은 동안에는 고객용 승인 템플릿으로 접수 알림을 보냅니다.
const DEFAULT_ADMIN_TEMPLATE_ID = DEFAULT_CUSTOMER_TEMPLATE_ID;

interface SolapiConfig {
  readonly apiKey: string;
  readonly apiSecret: string;
  readonly sender: string;
  readonly channelId: string;
  readonly customerTemplateId: string;
  readonly adminTemplateId: string;
  readonly adminPhone: string;
}

interface SolapiMessage {
  readonly to: string;
  readonly from: string;
  readonly kakaoOptions: {
    readonly pfId: string;
    readonly templateId: string;
    readonly variables: Record<string, string>;
    readonly disableSms: true;
  };
}

interface SolapiMessageReceipt {
  readonly statusCode?: string | number;
  readonly statusMessage?: string;
}

interface SolapiSendResponse {
  readonly failedMessageList?: unknown;
  readonly messageList?: unknown;
}

export interface EstimateNotificationResult {
  readonly customer: "accepted" | "failed" | "skipped";
  readonly administrator: "accepted" | "failed" | "skipped";
}

async function getConfig(): Promise<{ config: SolapiConfig | null; missing: string[] }> {
  const [apiKey, apiSecret, sender, channelId, customerTemplateId, adminTemplateId, adminPhone] = await Promise.all([
    getRuntimeValue("SOLAPI_API_KEY"),
    getRuntimeValue("SOLAPI_API_SECRET"),
    getRuntimeValue("SOLAPI_SENDER"),
    getRuntimeValue("SOLAPI_KAKAO_CHANNEL_ID"),
    getRuntimeValue("SOLAPI_CUSTOMER_TEMPLATE_ID"),
    getRuntimeValue("SOLAPI_ADMIN_TEMPLATE_ID"),
    getRuntimeValue("SOLAPI_ADMIN_PHONE"),
  ]);
  const config = {
    apiKey: apiKey ?? "",
    apiSecret: apiSecret ?? "",
    sender: sender ?? "",
    channelId: channelId ?? "",
    customerTemplateId: customerTemplateId ?? DEFAULT_CUSTOMER_TEMPLATE_ID,
    adminTemplateId: adminTemplateId ?? DEFAULT_ADMIN_TEMPLATE_ID,
    adminPhone: (adminPhone ?? "").replace(/\D/g, ""),
  };

  const labels: Record<keyof SolapiConfig, string> = {
    apiKey: "API 키",
    apiSecret: "API 시크릿",
    sender: "발신번호",
    channelId: "카카오 채널",
    customerTemplateId: "고객용 템플릿",
    adminTemplateId: "관리자용 템플릿",
    adminPhone: "관리자 수신번호",
  };
  const missing = (Object.keys(labels) as Array<keyof SolapiConfig>)
    .filter((key) => !config[key])
    .map((key) => labels[key]);

  return { config: missing.length ? null : config, missing };
}

function toHex(bytes: Uint8Array | ArrayBuffer) {
  return Array.from(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}

async function createAuthorizationHeader(apiKey: string, apiSecret: string) {
  const date = new Date().toISOString();
  const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(apiSecret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = toHex(
    await crypto.subtle.sign("HMAC", key, encoder.encode(`${date}${salt}`)),
  );

  return `HMAC-SHA256 apiKey=${apiKey}, date=${date}, salt=${salt}, signature=${signature}`;
}

function formatWon(value: number) {
  if (value >= 100_000_000) {
    const eok = value / 100_000_000;
    return `${Number.isInteger(eok) ? eok : eok.toFixed(1)}억원`;
  }
  return `${Math.round(value / 10_000).toLocaleString("ko-KR")}만원`;
}

function getFullAddress(draft: EstimateInquiryDraft) {
  return [draft.contact.address.baseAddress, draft.contact.address.detailAddress]
    .filter(Boolean)
    .join(" ");
}

function getSelectedProcesses(draft: EstimateInquiryDraft) {
  return draft.estimate.result.breakdown
    .filter((item) => item.id !== "management" && item.id !== "business-margin")
    .map((item) => item.label)
    .join(", ") || "선택 없음";
}

function createMessage(
  to: string,
  templateId: string,
  variables: Record<string, string>,
  config: SolapiConfig,
): SolapiMessage {
  return {
    to,
    from: config.sender,
    kakaoOptions: {
      pfId: config.channelId,
      templateId,
      variables,
      // 알림톡 템플릿에 지정한 대로 실패 시 문자로 전환하지 않습니다.
      disableSms: true,
    },
  };
}

function asReceiptList(value: unknown): SolapiMessageReceipt[] {
  if (Array.isArray(value)) return value.filter((item): item is SolapiMessageReceipt => Boolean(item) && typeof item === "object");
  if (value && typeof value === "object") return Object.values(value).filter((item): item is SolapiMessageReceipt => Boolean(item) && typeof item === "object");
  return [];
}

/**
 * 견적을 저장한 뒤 고객과 담당자에게 각각 알림톡을 접수합니다.
 * 알림 서비스의 일시적 오류로 견적 접수 자체가 실패하지 않도록 오류를 내부에서 처리합니다.
 */
export async function sendEstimateInquiryNotifications(draft: EstimateInquiryDraft) {
  const { config, missing } = await getConfig();
  if (!config) {
    console.warn(`Solapi 알림톡 설정이 완료되지 않아 견적 접수 알림을 생략했습니다. 누락: ${missing.join(", ")}`);
    return { customer: "skipped", administrator: "skipped" } satisfies EstimateNotificationResult;
  }

  const estimateRange = `${formatWon(draft.estimate.result.minimum)} ~ ${formatWon(draft.estimate.result.maximum)}`;
  const commonVariables = {
    "#{고객명}": draft.contact.name,
    "#{현장주소}": getFullAddress(draft),
    "#{공사면적}": String(draft.estimate.input.area),
    "#{공사예정시기}": draft.contact.constructionSchedule,
    "#{예상견적범위}": estimateRange,
  };
  const sendMessage = async (recipient: "고객" | "관리자", message: SolapiMessage) => {
    try {
      const response = await fetch("https://api.solapi.com/messages/v4/send-many/detail", {
        method: "POST",
        headers: {
          Authorization: await createAuthorizationHeader(config.apiKey, config.apiSecret),
          "Content-Type": "application/json",
        },
        // 수신자별로 분리해 한쪽 템플릿 문제가 다른 쪽 발송을 막지 않게 합니다.
        body: JSON.stringify({ messages: [message], strict: true, showMessageList: true }),
      });

      if (!response.ok) {
        const details = (await response.text()).replace(/\s+/g, " ").slice(0, 500);
        console.error(`Solapi ${recipient} 알림톡 접수에 실패했습니다. (HTTP ${response.status}) ${details}`);
        return "failed" as const;
      }

      const receipt = await response.json() as SolapiSendResponse;
      const failed = asReceiptList(receipt.failedMessageList)[0];
      if (failed) {
        console.error(
          `Solapi ${recipient} 알림톡이 접수되지 않았습니다. (${String(failed.statusCode ?? "unknown")}) ${failed.statusMessage ?? "발송 결과를 확인해 주세요."}`,
        );
        return "failed" as const;
      }

      const accepted = asReceiptList(receipt.messageList)[0];
      if (accepted?.statusCode && String(accepted.statusCode) !== "2000") {
        console.error(
          `Solapi ${recipient} 알림톡이 접수되지 않았습니다. (${String(accepted.statusCode)}) ${accepted.statusMessage ?? "발송 결과를 확인해 주세요."}`,
        );
        return "failed" as const;
      }

      console.info(`Solapi ${recipient} 알림톡이 정상 접수되었습니다.${accepted?.statusCode ? ` (${accepted.statusCode})` : ""}`);
      return "accepted" as const;
    } catch (error) {
      const reason = error instanceof Error ? error.message : "알 수 없는 네트워크 오류";
      console.error(`Solapi ${recipient} 알림톡 접수 중 네트워크 오류가 발생했습니다. ${reason}`);
      return "failed" as const;
    }
  };

  const [customer, administrator] = await Promise.all([
    sendMessage(
      "고객",
      createMessage(
        draft.contact.phone,
        config.customerTemplateId,
        {
          "#{고객명}": commonVariables["#{고객명}"],
          "#{견적금액}": estimateRange,
        },
        config,
      ),
    ),
    sendMessage(
      "관리자",
      createMessage(
        config.adminPhone,
        config.adminTemplateId,
        config.adminTemplateId === config.customerTemplateId
          ? {
            "#{고객명}": commonVariables["#{고객명}"],
            "#{견적금액}": estimateRange,
          }
          : {
            ...commonVariables,
            "#{연락처}": draft.contact.phone,
            "#{선택공정}": getSelectedProcesses(draft),
          },
        config,
      ),
    ),
  ]);

  return { customer, administrator } satisfies EstimateNotificationResult;
}
