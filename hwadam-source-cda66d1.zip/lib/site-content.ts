import { getMediaSlot, isPortfolioMediaSlot, portfolioCoverSlot } from "./media";

export type PortfolioImageShape = "landscape" | "portrait" | "square";

export interface PortfolioProjectContent {
  id: string;
  slug: string;
  title: string;
  category: string;
  type: string;
  scope: string;
  summary: string;
  designNote: string;
  shape: PortfolioImageShape;
  coverSlot: string;
  gallerySlots: string[];
}

export interface SiteContent {
  home: {
    heroKicker: string;
    heroCategory: string;
    heroTitle: string;
    heroCta: string;
    heroLocation: string;
    heroCaptions: string[];
    estimateEyebrow: string;
    estimateTitle: string;
    estimateDescription: string;
  };
  portfolio: {
    eyebrow: string;
    title: string;
    description: string;
    projects: PortfolioProjectContent[];
  };
  process: {
    eyebrow: string;
    title: string;
    description: string;
    featureDescription: string;
    steps: Array<{ title: string; description: string }>;
  };
  consultation: {
    eyebrow: string;
    heroTitle: string;
    cta: string;
    preparationEyebrow: string;
    preparationTitle: string;
    items: Array<{ title: string; description: string }>;
  };
  location: {
    address: string;
    kakaoMapUrl: string;
    consultationPhone: string;
  };
}

export const DEFAULT_SITE_CONTENT: SiteContent = {
  home: {
    heroKicker: "인테리어 디자인 · 현장 시공",
    heroCategory: "카페 · 음식점 · 사무실 · 매장",
    heroTitle: "공간의 쓰임을 이해하는\n인테리어",
    heroCta: "내 공간\n견적 확인하기",
    heroLocation: "서울 · 경기\n상업공간 전문",
    heroCaptions: ["상업 라운지", "음식점 공간", "브랜드 파사드"],
    estimateEyebrow: "셀프 견적 계산기",
    estimateTitle: "내 공간, 얼마면 시작할 수 있을까요?",
    estimateDescription: "선택한 공간과 공사 조건을 기준으로\n예상 범위를 바로 계산합니다.",
  },
  portfolio: {
    eyebrow: "시공 포트폴리오",
    title: "현장에서 완성한\n화담의 공간",
    description: "보여주기 위한 디자인보다 오래 쓰이는 공간의 답을 찾습니다.",
    projects: [
      { id: "project-restaurant", slug: "restaurant-space", title: "음식점 공간", category: "브랜드와 동선이 만나는 공간", type: "음식점 인테리어", scope: "공간 기획 · 설계 · 시공", summary: "손님과 직원의 동선이 자연스럽게 교차하도록 좌석과 서비스 공간의 밀도를 세심하게 조율한 프로젝트입니다.", designNote: "첫인상은 편안하게, 운영은 효율적으로 이어지도록 재료의 온도와 조명 밝기를 한 흐름 안에서 설계했습니다.", shape: "landscape", coverSlot: "portfolio-1-hq", gallerySlots: [] },
      { id: "project-lounge", slug: "commercial-lounge", title: "상업 라운지", category: "전통의 결을 담은 입면", type: "라운지 인테리어", scope: "공간 기획 · 마감 설계 · 시공", summary: "머무는 시간이 길어질수록 공간의 결이 드러나도록 여백과 동선을 차분하게 구성했습니다.", designNote: "입면의 리듬과 조도의 균형을 맞춰 브랜드가 지닌 깊이를 현대적인 방식으로 표현했습니다.", shape: "portrait", coverSlot: "portfolio-2-hq", gallerySlots: [] },
      { id: "project-premium-store", slug: "premium-store", title: "프리미엄 매장", category: "첫인상을 만드는 파사드", type: "리테일 인테리어", scope: "파사드 · 집기 설계 · 시공", summary: "방문 순간 브랜드의 분위기를 이해할 수 있도록 진입부와 상품 경험의 흐름을 설계했습니다.", designNote: "진열의 밀도는 낮추고 시선의 흐름은 선명하게 만들어 제품이 공간 안에서 돋보이게 했습니다.", shape: "square", coverSlot: "portfolio-3-hq", gallerySlots: [] },
      { id: "project-wood-finish", slug: "wood-finish-space", title: "목재 마감 공간", category: "재료의 온도를 살린 디테일", type: "상업 공간 인테리어", scope: "마감 계획 · 가구 설계 · 시공", summary: "목재가 가진 질감과 시간이 쌓일수록 편안해지는 사용감을 중심에 둔 공간입니다.", designNote: "색과 질감의 차이를 과하게 드러내기보다, 빛에 따라 달라지는 재료의 표정을 살렸습니다.", shape: "square", coverSlot: "portfolio-4-hq", gallerySlots: [] },
      { id: "project-bright-living", slug: "bright-living-space", title: "밝은 주거 공간", category: "빛과 여백을 중심으로", type: "주거 공간 인테리어", scope: "공간 구성 · 마감 설계 · 시공", summary: "자연광의 방향과 일상의 수납 동선을 기준으로, 가볍고 밝은 생활 공간을 완성했습니다.", designNote: "필요한 기능은 충분히 담되, 시선이 머무는 곳에는 여백을 남겨 공간이 더 넓게 느껴지도록 했습니다.", shape: "portrait", coverSlot: "portfolio-5-hq", gallerySlots: [] },
      { id: "project-alley", slug: "alley-commercial-space", title: "골목 상업 공간", category: "기존 맥락과 어우러진 외관", type: "상업 공간 인테리어", scope: "리노베이션 · 공간 설계 · 시공", summary: "기존 건물의 분위기를 존중하면서도 새로운 브랜드 경험이 자연스럽게 드러나도록 정리했습니다.", designNote: "거리에서 마주하는 표정과 내부의 체류 경험이 끊기지 않도록 투명도와 재료의 대비를 조절했습니다.", shape: "landscape", coverSlot: "portfolio-6-hq", gallerySlots: [] },
    ],
  },
  process: {
    eyebrow: "프로젝트 진행 과정",
    title: "현장을 이해하는 것부터\n좋은 공간이 시작됩니다.",
    description: "상담에서 마감까지 한 흐름으로 관리해 디자인이 실제 현장에서 정확히 구현되도록 합니다.",
    featureDescription: "공간의 쓰임과 운영 동선을 먼저 듣고, 현장의 조건을 확인한 뒤 디자인과 공사를 구체화합니다.",
    steps: [
      { title: "상담", description: "공간의 용도와 일정, 예산, 필요한 공사 범위를 함께 확인합니다." },
      { title: "현장 실측", description: "현장을 방문해 치수와 설비, 기존 마감, 공사 여건을 꼼꼼히 살핍니다." },
      { title: "설계", description: "동선과 운영 방식을 기준으로 평면, 마감재, 세부 견적을 구체화합니다." },
      { title: "시공", description: "확정된 설계와 공정표를 기준으로 현장을 관리하며 공사를 진행합니다." },
      { title: "마감", description: "완성도를 점검하고 보완 사항을 정리한 뒤 공간을 인도합니다." },
    ],
  },
  consultation: {
    eyebrow: "상담 안내",
    heroTitle: "당신의 다음 공간을\n함께 준비하겠습니다.",
    cta: "인스타그램으로 상담하기",
    preparationEyebrow: "상담 전 준비 사항",
    preparationTitle: "조금 더 정확한 상담을 위해\n아래 내용을 준비해 주세요.",
    items: [
      { title: "공간 정보", description: "업종과 주소, 전용 면적을 알려주세요." },
      { title: "공사 범위", description: "필요한 공정과 유지하고 싶은 부분을 정리해 주세요." },
      { title: "일정과 예산", description: "희망 오픈일과 생각하시는 예산 범위를 알려주세요." },
      { title: "참고 자료", description: "도면이나 현장 사진, 선호하는 공간 이미지를 준비해 주세요." },
    ],
  },
  // 관리자 화면에서 실제 방문 주소와 지도 연결을 변경할 수 있습니다.
  location: {
    address: "경기도 하남시 미사강변중앙로 11 4층 W430호",
    kakaoMapUrl: "",
    consultationPhone: "010-6216-1894",
  },
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function text(value: unknown, label: string, maximum = 240) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > maximum) {
    throw new Error(`${label} 문구를 1자 이상 ${maximum}자 이하로 입력해 주세요.`);
  }
  return value.trim();
}

function optionalText(value: unknown, label: string, maximum = 240) {
  if (value === undefined || value === null || value === "") return "";
  return text(value, label, maximum);
}

function kakaoMapUrl(value: unknown) {
  const url = optionalText(value, "카카오 지도 링크", 500);
  if (!url) return "";
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:" || !["map.kakao.com", "place.map.kakao.com", "kko.to"].includes(parsed.hostname)) {
      throw new Error();
    }
    return parsed.toString();
  } catch {
    throw new Error("카카오 지도 링크를 정확히 입력해 주세요.");
  }
}

function consultationPhone(value: unknown) {
  const digits = optionalText(value, "상담 전화번호", 20).replace(/\D/g, "");
  if (!/^01[016789]\d{7,8}$/.test(digits)) {
    throw new Error("상담 전화번호를 정확히 입력해 주세요.");
  }
  return digits.length === 11
    ? `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`
    : `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
}

function itemList(value: unknown, label: string, count: number) {
  if (!Array.isArray(value) || value.length !== count) {
    throw new Error(`${label} 항목 수가 올바르지 않습니다.`);
  }
  return value.map((item, index) => {
    if (!isRecord(item)) throw new Error(`${label} ${index + 1}번 항목이 올바르지 않습니다.`);
    return {
      title: text(item.title, `${label} ${index + 1} 제목`, 60),
      description: text(item.description, `${label} ${index + 1} 설명`, 240),
    };
  });
}

function portfolioId(value: unknown, fallback: string, label: string) {
  const id = value === undefined ? fallback : text(value, label, 96);
  if (!/^[a-z0-9-]{6,96}$/.test(id)) throw new Error(`${label} 형식이 올바르지 않습니다.`);
  return id;
}

function portfolioSlug(value: unknown, fallback: string, label: string) {
  const slug = value === undefined ? fallback : text(value, label, 96);
  if (!/^[a-z0-9-]{3,96}$/.test(slug)) throw new Error(`${label} 형식이 올바르지 않습니다.`);
  return slug;
}

function portfolioMediaSlot(value: unknown, fallback: string, label: string) {
  const slot = value === undefined ? fallback : text(value, label, 220);
  if (!getMediaSlot(slot) && !isPortfolioMediaSlot(slot)) throw new Error(`${label} 형식이 올바르지 않습니다.`);
  return slot;
}

function portfolioShape(value: unknown, fallback: PortfolioImageShape, label: string): PortfolioImageShape {
  const shape = value === undefined ? fallback : value;
  if (shape !== "landscape" && shape !== "portrait" && shape !== "square") {
    throw new Error(`${label}을(를) 선택해 주세요.`);
  }
  return shape;
}

function projectList(value: unknown) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 60) {
    throw new Error("포트폴리오 항목 수가 올바르지 않습니다.");
  }
  const ids = new Set<string>();
  const slugs = new Set<string>();
  return value.map((item, index): PortfolioProjectContent => {
    if (!isRecord(item)) throw new Error(`포트폴리오 ${index + 1}번 항목이 올바르지 않습니다.`);
    const fallback = DEFAULT_SITE_CONTENT.portfolio.projects[index] ?? {
      id: `project-${index + 1}-legacy`,
      slug: `project-${index + 1}`,
      title: "새 포트폴리오",
      category: "공간 소개",
      type: "상업 공간 인테리어",
      scope: "기획 · 설계 · 시공",
      summary: "프로젝트 소개를 입력해 주세요.",
      designNote: "디자인 노트를 입력해 주세요.",
      shape: "landscape" as const,
      coverSlot: portfolioCoverSlot(`project-${index + 1}-legacy`),
      gallerySlots: [],
    };
    const id = portfolioId(item.id, fallback.id, `포트폴리오 ${index + 1} 식별값`);
    const slug = portfolioSlug(item.slug, fallback.slug, `포트폴리오 ${index + 1} 주소`);
    if (ids.has(id) || slugs.has(slug)) throw new Error("중복된 포트폴리오 항목이 있습니다.");
    ids.add(id);
    slugs.add(slug);
    const gallerySlots = item.gallerySlots === undefined ? fallback.gallerySlots : item.gallerySlots;
    if (!Array.isArray(gallerySlots)) {
      throw new Error(`포트폴리오 ${index + 1} 상세 사진 수가 올바르지 않습니다.`);
    }
    const normalizedGallerySlots = gallerySlots.map((slot, imageIndex) => portfolioMediaSlot(
      slot,
      "",
      `포트폴리오 ${index + 1} 상세 사진 ${imageIndex + 1}`,
    ));
    if (new Set(normalizedGallerySlots).size !== normalizedGallerySlots.length) {
      throw new Error(`포트폴리오 ${index + 1}에 중복된 상세 사진이 있습니다.`);
    }
    return {
      id,
      slug,
      title: text(item.title, `포트폴리오 ${index + 1} 제목`, 60),
      category: text(item.category, `포트폴리오 ${index + 1} 설명`, 160),
      type: item.type === undefined ? fallback.type : text(item.type, `포트폴리오 ${index + 1} 유형`, 80),
      scope: item.scope === undefined ? fallback.scope : text(item.scope, `포트폴리오 ${index + 1} 진행 범위`, 120),
      summary: item.summary === undefined ? fallback.summary : text(item.summary, `포트폴리오 ${index + 1} 프로젝트 개요`, 600),
      designNote: item.designNote === undefined ? fallback.designNote : text(item.designNote, `포트폴리오 ${index + 1} 디자인 노트`, 600),
      shape: portfolioShape(item.shape, fallback.shape, `포트폴리오 ${index + 1} 이미지 형태`),
      coverSlot: portfolioMediaSlot(item.coverSlot, fallback.coverSlot, `포트폴리오 ${index + 1} 대표 사진`),
      gallerySlots: normalizedGallerySlots,
    };
  });
}

export function normalizeSiteContent(value: unknown): SiteContent {
  if (!isRecord(value) || !isRecord(value.home) || !isRecord(value.portfolio) || !isRecord(value.process) || !isRecord(value.consultation)) {
    throw new Error("사이트 문구 형식이 올바르지 않습니다.");
  }
  const { home, portfolio, process, consultation } = value;
  // 기존에 저장된 콘텐츠는 위치 정보가 없으므로, 첫 저장 전에도 안전하게 열리도록 기본값을 채웁니다.
  const location = isRecord(value.location) ? value.location : DEFAULT_SITE_CONTENT.location;
  if (!Array.isArray(home.heroCaptions) || home.heroCaptions.length !== 3) {
    throw new Error("메인 이미지 설명 수가 올바르지 않습니다.");
  }
  return {
    home: {
      heroKicker: text(home.heroKicker, "메인 상단 문구", 60),
      heroCategory: text(home.heroCategory, "업종 안내", 80),
      heroTitle: text(home.heroTitle, "메인 제목", 100),
      heroCta: text(home.heroCta, "견적 버튼", 40),
      heroLocation: text(home.heroLocation, "지역 안내", 40),
      heroCaptions: home.heroCaptions.map((caption, index) => text(caption, `메인 이미지 ${index + 1}`, 40)),
      estimateEyebrow: text(home.estimateEyebrow, "견적 보조 제목", 40),
      estimateTitle: text(home.estimateTitle, "견적 제목", 100),
      estimateDescription: text(home.estimateDescription, "견적 설명", 180),
    },
    portfolio: {
      eyebrow: text(portfolio.eyebrow, "포트폴리오 보조 제목", 40),
      title: text(portfolio.title, "포트폴리오 제목", 100),
      description: text(portfolio.description, "포트폴리오 설명", 180),
      projects: projectList(portfolio.projects),
    },
    process: {
      eyebrow: text(process.eyebrow, "진행 과정 보조 제목", 40),
      title: text(process.title, "진행 과정 제목", 100),
      description: text(process.description, "진행 과정 설명", 200),
      featureDescription: text(process.featureDescription, "진행 과정 대표 설명", 240),
      steps: itemList(process.steps, "진행 과정", 5),
    },
    consultation: {
      eyebrow: text(consultation.eyebrow, "상담 안내 보조 제목", 40),
      heroTitle: text(consultation.heroTitle, "상담 안내 제목", 100),
      cta: text(consultation.cta, "상담 버튼", 40),
      preparationEyebrow: text(consultation.preparationEyebrow, "준비 사항 보조 제목", 40),
      preparationTitle: text(consultation.preparationTitle, "준비 사항 제목", 120),
      items: itemList(consultation.items, "상담 준비 사항", 4),
    },
    location: {
      address: optionalText(location.address, "방문 주소", 160) || DEFAULT_SITE_CONTENT.location.address,
      kakaoMapUrl: kakaoMapUrl(location.kakaoMapUrl),
      consultationPhone: consultationPhone(location.consultationPhone ?? DEFAULT_SITE_CONTENT.location.consultationPhone),
    },
  };
}
