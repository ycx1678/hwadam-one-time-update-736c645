param(
  [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
$environmentFile = Join-Path $ProjectRoot "selfhost\.env"
$caddyfile = Join-Path $ProjectRoot "Caddyfile"
$secretFile = Join-Path $PSScriptRoot "manual-deploy-secret.txt"

if (-not (Test-Path -LiteralPath $environmentFile)) {
  throw "selfhost/.env 파일을 찾지 못했습니다. 기존 미니PC 사이트 폴더에서 실행해 주세요."
}
if (-not (Test-Path -LiteralPath $caddyfile)) {
  throw "Caddyfile을 찾지 못했습니다. 기존 미니PC 사이트 폴더에서 실행해 주세요."
}
if (-not (Test-Path -LiteralPath $secretFile)) {
  throw "수동 배포 키 파일을 찾지 못했습니다. 새 설치 ZIP 전체를 다시 풀어 실행해 주세요."
}
$secretLine = Get-Content -LiteralPath $secretFile | Where-Object { $_ -match '^HWADAM_DEPLOY_SECRET=' } | Select-Object -First 1
$deploySecret = if ($secretLine) { ($secretLine -replace '^HWADAM_DEPLOY_SECRET=', '').Trim() } else { "" }
if ($deploySecret.Length -lt 40) { throw "수동 배포 키가 올바르지 않습니다. 새 설치 ZIP을 다시 받아 주세요." }

$environmentLines = Get-Content -LiteralPath $environmentFile
if (-not ($environmentLines -match '^HWADAM_DEPLOY_AGENT=')) { $environmentLines += 'HWADAM_DEPLOY_AGENT=1' }
if (-not ($environmentLines -match '^HWADAM_DEPLOY_AGENT_PORT=')) { $environmentLines += 'HWADAM_DEPLOY_AGENT_PORT=3010' }
$environmentLines = @($environmentLines | Where-Object { $_ -notmatch '^HWADAM_DEPLOY_SECRET=' })
$environmentLines += "HWADAM_DEPLOY_SECRET=$deploySecret"
Set-Content -LiteralPath $environmentFile -Value $environmentLines
Remove-Item -LiteralPath $secretFile -Force -ErrorAction SilentlyContinue

$caddyContents = Get-Content -LiteralPath $caddyfile -Raw
if ($caddyContents -notmatch '(?m)^\s*handle\s+/__hwadam-deploy\s*\{') {
  $proxyMatch = [regex]::Match($caddyContents, '(?m)^(?<indent>\s*)reverse_proxy\s+127\.0\.0\.1:3000\s*$')
  if (-not $proxyMatch.Success) { throw "Caddyfile에서 기존 사이트 프록시(127.0.0.1:3000)를 찾지 못했습니다." }
  Copy-Item -LiteralPath $caddyfile -Destination "$caddyfile.backup-before-manual-deploy" -Force
  $indent = $proxyMatch.Groups['indent'].Value
  $replacement = @"
${indent}handle /__hwadam-deploy {
${indent}    reverse_proxy 127.0.0.1:3010
${indent}}
${indent}handle {
${indent}    reverse_proxy 127.0.0.1:3000
${indent}}
"@
  $caddyContents = $caddyContents.Remove($proxyMatch.Index, $proxyMatch.Length).Insert($proxyMatch.Index, $replacement.TrimEnd())
  Set-Content -LiteralPath $caddyfile -Value $caddyContents
}

Push-Location $ProjectRoot
try {
  & pm2.cmd start selfhost\ecosystem.config.cjs
  if ($LASTEXITCODE -ne 0) { throw "배포 수신기 시작에 실패했습니다." }
  & pm2.cmd save
  if ($LASTEXITCODE -ne 0) { throw "PM2 설정 저장에 실패했습니다." }
  & pm2.cmd restart hwadam-proxy
  if ($LASTEXITCODE -ne 0) { throw "Caddy 프록시 재시작에 실패했습니다." }
} finally {
  Pop-Location
}

Write-Host "설치 완료: GitHub Actions에서 'Deploy Hwadam to Mini PC'를 수동 실행하면 이 PC로 배포됩니다."
