import {
  createAdminSessionCookie,
  hasSameOrigin,
  isAdminAuthConfigured,
  verifyAdminCredentials,
} from "../../../../lib/admin-auth";

export const dynamic = "force-dynamic";

function redirectToAdmin(request: Request, error?: string) {
  const location = new URL("/admin", request.url);
  if (error) location.searchParams.set("error", error);
  return location.toString();
}

export async function POST(request: Request) {
  if (!hasSameOrigin(request)) {
    return new Response(null, { status: 303, headers: { Location: redirectToAdmin(request, "request") } });
  }
  if (!(await isAdminAuthConfigured())) {
    return new Response(null, { status: 303, headers: { Location: redirectToAdmin(request, "config") } });
  }

  const formData = await request.formData();
  const username = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  if (!(await verifyAdminCredentials(username, password))) {
    return new Response(null, { status: 303, headers: { Location: redirectToAdmin(request, "invalid") } });
  }

  const secure = new URL(request.url).protocol === "https:";
  return new Response(null, {
    status: 303,
    headers: {
      Location: redirectToAdmin(request),
      "Set-Cookie": await createAdminSessionCookie(username, secure),
      "Cache-Control": "no-store",
    },
  });
}
