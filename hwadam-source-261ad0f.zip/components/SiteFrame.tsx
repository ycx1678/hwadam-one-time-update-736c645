"use client";

import { useEffect, useState } from "react";
import { mediaUrl } from "../lib/media";
import { SITE_INSTAGRAM_URL } from "../lib/site";

type CurrentPage = "home" | "portfolio" | "process" | "location";

const NAVIGATION = [
  { id: "portfolio", label: "포트폴리오", href: "/portfolio" },
  { id: "process", label: "진행 과정", href: "/process" },
  { id: "location", label: "찾아오는 길", href: "/location" },
] as const;

const SOCIAL_LINKS = [
  { label: "인스타그램", href: SITE_INSTAGRAM_URL },
] as const;

export default function SiteFrame({
  current,
  children,
}: Readonly<{ current: CurrentPage; children: React.ReactNode }>) {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!menuOpen) return;

    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [menuOpen]);

  return (
    <div className="site-frame editorial-site">
      <header className={`site-topbar editorial-topbar ${menuOpen ? "menu-open" : ""}`}>
        <a className="topbar-brand" href="/" aria-label="화담아이디 메인으로">
          <span className="topbar-mark"><img src="/images/logo.jpg" alt="" /></span>
          <span>화담아이디</span>
        </a>
        <button
          className={`menu-button ${menuOpen ? "open" : ""}`}
          type="button"
          aria-label={menuOpen ? "전체 메뉴 닫기" : "전체 메뉴 열기"}
          aria-expanded={menuOpen}
          aria-controls="전체메뉴"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span className="menu-icon" aria-hidden="true"><i /><i /></span>
        </button>
      </header>

      <div className={`menu-panel editorial-menu ${menuOpen ? "open" : ""}`} id="전체메뉴" aria-hidden={!menuOpen}>
        <div className="menu-panel-inner">
          <div className="menu-panel-visual" aria-hidden="true">
            <figure><img src={mediaUrl("menu-feature-hq")} alt="" /></figure>
          </div>
          <div className="menu-panel-navigation">
            <nav aria-label="전체 메뉴">
              {NAVIGATION.map((item) => (
                <a
                  key={item.id}
                  href={item.href}
                  aria-current={current === item.id ? "page" : undefined}
                  tabIndex={menuOpen ? 0 : -1}
                >
                  <strong>{item.label}</strong>
                  <i aria-hidden="true">↗</i>
                </a>
              ))}
              {SOCIAL_LINKS.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  target="_blank"
                  rel="noreferrer"
                  tabIndex={menuOpen ? 0 : -1}
                >
                  <strong>{item.label}</strong>
                  <i aria-hidden="true">↗</i>
                </a>
              ))}
            </nav>
          </div>
        </div>
      </div>

      <div className="site-content">{children}</div>
    </div>
  );
}
