// 관리자가 업종을 추가할 수 있으므로 고정된 목록 대신 문자열 식별자를 사용합니다.
export type SpaceTypeId = string;

/**
 * `perMeter`는 고객이 아직 길이·수량을 입력하지 않으므로 자동 견적에는 합산하지
 * 않고, 현장 실측이 필요한 항목으로 표시한다.
 */
export type PricingMode = "perPyeong" | "fixed" | "perMeter";

export interface SpaceType {
  readonly id: SpaceTypeId;
  readonly label: string;
  readonly multiplier: number;
  readonly description: string;
}

export interface ProcessOption {
  readonly id: string;
  readonly label: string;
  readonly amount: number;
  readonly mode: PricingMode;
  readonly details?: readonly ProcessDetailOption[];
}

export interface ProcessDetailOption {
  readonly id: string;
  readonly label: string;
  readonly amount: number;
  readonly mode: PricingMode;
  readonly details?: readonly ProcessDetailOption[];
}

export interface ProcessGroup {
  readonly id: string;
  readonly label: string;
  readonly description: string;
  readonly options: readonly ProcessOption[];
}

export interface PricingCatalog {
  readonly id: string;
  readonly version: string;
  readonly effectiveFrom: string;
  readonly currency: "KRW";
  readonly minimumArea: number;
  readonly maximumArea: number;
  readonly estimateRangeRate: number;
  readonly managementCostPerPyeong: number;
  /** 현장 실비를 포함한 공사 원가에 더하는 기업 이윤율입니다. */
  readonly businessMarginRate: number;
  readonly spaceTypes: readonly SpaceType[];
  readonly processGroups: readonly ProcessGroup[];
}

/**
 * 한 공정 대주제 안에서도 여러 옵션을 고를 수 있습니다.
 * 기존에 접수된 문의는 문자열 하나로 저장되어 있어 함께 허용합니다.
 */
export type ProcessSelectionValue = string | readonly string[];
export type ProcessSelections = Readonly<Record<string, ProcessSelectionValue>>;

export interface EstimateInput {
  readonly spaceType: SpaceTypeId;
  readonly area: number;
  readonly selections: ProcessSelections;
}

export interface EstimateBreakdown {
  readonly id: string;
  readonly label: string;
  readonly detail: string;
  readonly amount: number;
  /** 1m당 항목이 포함되어 길이 실측 뒤 별도 산정이 필요한지 여부입니다. */
  readonly requiresMeasurement?: boolean;
}

export interface EstimateResult {
  readonly catalogId: string;
  readonly catalogVersion: string;
  readonly currency: "KRW";
  readonly midpoint: number;
  readonly minimum: number;
  readonly maximum: number;
  readonly breakdown: readonly EstimateBreakdown[];
  readonly selectedCount: number;
  /** 자동 견적에 포함하지 않은 1m당 항목이 있는지 여부입니다. */
  readonly measurementRequired: boolean;
}
