"use client";

import SiteFrame from "./SiteFrame";
import { mediaUrl } from "../lib/media";
import { useSiteContent } from "../lib/use-site-content";

const PROCESS_IMAGES = [
  mediaUrl("process-step-1-hq"),
  mediaUrl("process-step-2-hq"),
  mediaUrl("process-step-3-hq"),
  mediaUrl("process-step-4-hq"),
  mediaUrl("process-step-5-hq"),
] as const;

export default function ProcessPageContent() {
  const content = useSiteContent().process;

  return (
    <SiteFrame current="process">
      <main className="subpage process-page reference-process-page">
        <section className="process-reference-shell" aria-labelledby="process-title">
          <header className="process-reference-header">
            <p>진행 과정</p>
            <h1 className="preserve-lines" id="process-title">{content.title}</h1>
            <span>{content.description}</span>
          </header>

          <ol className="process-reference-list">
            {content.steps.map((step, index) => (
              <li key={`${index}-${step.title}`}>
                <div className="process-step-copy">
                  <span>{String(index + 1).padStart(2, "0")}</span>
                  <h2>{step.title}</h2>
                  <p>{step.description}</p>
                </div>
                <span className="process-step-divider" aria-hidden="true" />
                <figure className="process-step-image">
                  <img src={PROCESS_IMAGES[index % PROCESS_IMAGES.length]} alt={`${step.title} 단계의 공간 이미지`} loading={index === 0 ? "eager" : "lazy"} />
                </figure>
              </li>
            ))}
          </ol>
        </section>
      </main>
    </SiteFrame>
  );
}
