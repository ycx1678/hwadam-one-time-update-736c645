const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

const projectRoot = path.resolve(__dirname, "..");
const environmentFile = path.join(__dirname, ".env");
const statusFile = path.join(__dirname, ".last-deploy-status.json");

// 개발 PC에서는 PM2에 손대지 않습니다. 미니PC의 실제 환경 설정 파일이 있을 때만
// 배포 후 사이트 실행 구성을 최신 ecosystem 파일로 다시 등록합니다.
if (!fs.existsSync(environmentFile)) process.exit(0);

const pm2 = process.platform === "win32" ? "pm2.cmd" : "pm2";
const options = { cwd: projectRoot, stdio: "inherit", shell: process.platform === "win32" };

fs.writeFileSync(
  statusFile,
  JSON.stringify({ state: "running", message: "빌드 전에 PM2 사이트와 배포 수신기를 최신 구성으로 다시 등록하고 있습니다.", updatedAt: new Date().toISOString() }),
  { mode: 0o600 },
);

for (const name of ["hwadam-site", "hwadam-deploy-agent"]) {
  const remove = spawnSync(pm2, ["delete", name], options);
  if (remove.error) {
    console.error(`기존 PM2 프로세스 종료에 실패했습니다: ${remove.error.message}`);
    process.exit(1);
  }
}

for (const name of ["hwadam-site", "hwadam-deploy-agent"]) {
  const start = spawnSync(pm2, ["start", "selfhost/ecosystem.config.cjs", "--only", name], options);
  if (start.error || start.status !== 0) {
    console.error(start.error ? `PM2 ${name} 시작에 실패했습니다: ${start.error.message}` : `PM2 ${name} 시작에 실패했습니다.`);
    process.exit(start.status || 1);
  }
}
