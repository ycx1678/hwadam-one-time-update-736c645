ALTER TABLE `estimate_inquiries` ADD `postcode` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `estimate_inquiries` ADD `base_address` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `estimate_inquiries` ADD `detail_address` text DEFAULT '' NOT NULL;