import type { EstimateInput, EstimateResult } from "./estimate";

export interface CustomerContact {
  readonly name: string;
  readonly phone: string;
  readonly address: {
    readonly postcode: string;
    readonly baseAddress: string;
    readonly detailAddress: string;
    readonly city: string;
    readonly district: string;
    readonly neighborhood: string;
  };
  readonly constructionSchedule: string;
}

export interface EstimateInquiryDraft {
  readonly schemaVersion: "1";
  readonly createdAt: string;
  readonly contact: CustomerContact;
  readonly privacyConsent: {
    readonly agreed: true;
    readonly agreedAt: string;
  };
  readonly estimate: {
    readonly input: EstimateInput;
    readonly result: EstimateResult;
  };
}

export interface InquirySubmission {
  readonly id: string;
  readonly status: "received";
  readonly receivedAt: string;
}

/** 향후 DB·알림 서버가 구현할 단일 연결 지점입니다. */
export interface InquiryGateway {
  submit(draft: EstimateInquiryDraft): Promise<InquirySubmission>;
}

interface CreateInquiryDraftInput {
  readonly contact: CustomerContact;
  readonly privacyAgreed: boolean;
  readonly estimateInput: EstimateInput;
  readonly estimateResult: EstimateResult;
  readonly now?: Date;
}

export function createEstimateInquiryDraft({
  contact,
  privacyAgreed,
  estimateInput,
  estimateResult,
  now = new Date(),
}: CreateInquiryDraftInput): EstimateInquiryDraft {
  if (!privacyAgreed) {
    throw new Error("개인정보 수집·이용 안내에 동의해 주세요.");
  }

  const createdAt = now.toISOString();

  return {
    schemaVersion: "1",
    createdAt,
    contact: {
      ...contact,
      name: contact.name.trim(),
      phone: contact.phone.replace(/\D/g, ""),
      address: {
        postcode: contact.address.postcode.trim(),
        baseAddress: contact.address.baseAddress.trim(),
        detailAddress: contact.address.detailAddress.trim(),
        city: contact.address.city.trim(),
        district: contact.address.district.trim(),
        neighborhood: contact.address.neighborhood.trim(),
      },
    },
    privacyConsent: {
      agreed: true,
      agreedAt: createdAt,
    },
    estimate: {
      input: estimateInput,
      result: estimateResult,
    },
  };
}
