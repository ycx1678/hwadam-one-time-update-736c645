CREATE TABLE `administrators` (
	`user_id` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`display_name` text NOT NULL,
	`role` text DEFAULT 'owner' NOT NULL,
	`created_at` text NOT NULL,
	`last_login_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `estimate_inquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`status` text DEFAULT 'new' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`city` text NOT NULL,
	`district` text NOT NULL,
	`neighborhood` text NOT NULL,
	`construction_schedule` text NOT NULL,
	`privacy_agreed_at` text NOT NULL,
	`space_type` text NOT NULL,
	`area` integer NOT NULL,
	`selections_json` text NOT NULL,
	`midpoint` integer NOT NULL,
	`minimum` integer NOT NULL,
	`maximum` integer NOT NULL,
	`breakdown_json` text NOT NULL,
	`selected_count` integer NOT NULL,
	`catalog_version` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_estimate_inquiries_status_created` ON `estimate_inquiries` (`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_estimate_inquiries_created` ON `estimate_inquiries` (`created_at`);--> statement-breakpoint
CREATE TABLE `pricing_catalogs` (
	`id` text PRIMARY KEY NOT NULL,
	`version` text NOT NULL,
	`catalog_json` text NOT NULL,
	`is_active` integer DEFAULT 1 NOT NULL,
	`updated_by` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_pricing_catalogs_active_updated` ON `pricing_catalogs` (`is_active`,`updated_at`);