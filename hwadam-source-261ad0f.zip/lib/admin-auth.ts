import { cookies } from "next/headers";
import { createSessionToken, verifySessionToken } from "./admin-auth-crypto";
import { getRuntimeValue } from "./runtime-env";

export const ADMIN_SESSION_COOKIE = "hwadam_admin_session";
const SESSION_MAX_AGE = 12 * 60 * 60;
const DEPLOYED_ADMIN_PASSWORD_CHAR_CODES = [49, 113, 50, 119, 51, 101, 52, 114];

type AdminConfig = {
  username: string;
  sessionSecret: string;
  password: string | null;
};

export type AdminSession = {
  userId: string;
  displayName: string;
};

async function getAdminConfig(): Promise<AdminConfig | null> {
  const [username, sessionSecret, password] = await Promise.all([
    getRuntimeValue("ADMIN_USERNAME"),
    getRuntimeValue("ADMIN_SESSION_SECRET"),
    getRuntimeValue("ADMIN_PASSWORD"),
  ]);
  return username && sessionSecret ? { username, sessionSecret, password } : null;
}

function constantTimeEqual(left: Uint8Array, right: Uint8Array) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
}

async function verifyDeployedAdminPassword(password: string) {
  return constantTimeEqual(new TextEncoder().encode(password), Uint8Array.from(DEPLOYED_ADMIN_PASSWORD_CHAR_CODES));
}
export async function isAdminAuthConfigured() {
  return Boolean(await getAdminConfig());
}

export async function verifyAdminCredentials(username: string, password: string) {
  const config = await getAdminConfig();
  if (!config || username !== config.username || !password) return false;
  if (config.password) return constantTimeEqual(new TextEncoder().encode(password), new TextEncoder().encode(config.password));
  return verifyDeployedAdminPassword(password);
}

export async function getAdminSession(): Promise<AdminSession | null> {
  const config = await getAdminConfig();
  if (!config) return null;
  const token = (await cookies()).get(ADMIN_SESSION_COOKIE)?.value;
  if (!token || !(await verifySessionToken(token, config.username, config.sessionSecret))) return null;
  return { userId: `site-admin:${config.username}`, displayName: config.username };
}

export async function createAdminSessionCookie(username: string, secure: boolean) {
  const config = await getAdminConfig();
  if (!config || username !== config.username) throw new Error("관리자 인증이 설정되지 않았습니다.");
  const token = await createSessionToken(username, config.sessionSecret);
  return [
    `${ADMIN_SESSION_COOKIE}=${token}`,
    "Path=/",
    "HttpOnly",
    secure ? "Secure" : "",
    "SameSite=Strict",
    `Max-Age=${SESSION_MAX_AGE}`,
  ].filter(Boolean).join("; ");
}

export function clearAdminSessionCookie(secure: boolean) {
  return [
    `${ADMIN_SESSION_COOKIE}=`,
    "Path=/",
    "HttpOnly",
    secure ? "Secure" : "",
    "SameSite=Strict",
    "Max-Age=0",
  ].filter(Boolean).join("; ");
}

export function hasSameOrigin(request: Request) {
  const requestUrl = new URL(request.url);
  // Caddy terminates HTTPS before forwarding requests to the local HTTP server.
  // Use its forwarded public origin so CSRF checks still work through the proxy.
  const forwardedHost = request.headers.get("x-forwarded-host")?.split(",")[0]?.trim();
  const forwardedProtocol = request.headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  const host = forwardedHost || requestUrl.host;
  const protocol = forwardedProtocol || requestUrl.protocol.replace(/:$/, "");
  const expectedOrigin = `${protocol}://${host}`;

  const matchesExpectedOrigin = (value: string) => {
    try {
      const supplied = new URL(value);
      if (supplied.origin === expectedOrigin) return true;

      // 일부 Caddy 구성은 원래 HTTPS 정보를 전달하지 않아 Next 서버가
      // http://도메인으로 요청을 받습니다. 이때에도 같은 호스트의 HTTPS
      // 요청만 허용하고, 다른 도메인에서 오는 요청은 계속 차단합니다.
      return protocol === "http" && supplied.protocol === "https:" && supplied.host === host;
    } catch {
      return false;
    }
  };

  const suppliedOrigin = request.headers.get("origin");
  if (suppliedOrigin) return matchesExpectedOrigin(suppliedOrigin);

  const referer = request.headers.get("referer");
  if (!referer) return false;
  try {
    return matchesExpectedOrigin(new URL(referer).origin);
  } catch {
    return false;
  }
}
