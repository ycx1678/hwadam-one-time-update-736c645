import {
  getActivePricingCatalog,
  insertEstimateInquiry,
} from "../../../db/repositories";
import { createServerInquiryDraft } from "../../../lib/inquiry-server";
import { sendEstimateInquiryNotifications } from "../../../lib/solapi";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const payload = await request.json();
    const catalog = await getActivePricingCatalog();
    const draft = createServerInquiryDraft(payload, catalog);
    const submission = await insertEstimateInquiry(draft);
    const notifications = await sendEstimateInquiryNotifications(draft);

    return Response.json(
      { submission, estimateResult: draft.estimate.result, notifications },
      { status: 201, headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "견적 문의를 접수하지 못했습니다." },
      { status: 400 },
    );
  }
}
