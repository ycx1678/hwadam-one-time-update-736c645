import { getAdminSession, hasSameOrigin } from "./admin-auth";

export async function getAuthorizedAdministrator(request?: Request) {
  if (request && request.method !== "GET" && !hasSameOrigin(request)) return null;
  return getAdminSession();
}
