@echo off
setlocal
set "UPDATE_ROOT=%~dp0"
if "%UPDATE_ROOT:~-1%"=="\" set "UPDATE_ROOT=%UPDATE_ROOT:~0,-1%"

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%UPDATE_ROOT%\selfhost\apply-local-update.ps1" -UpdateRoot "%UPDATE_ROOT%" -ProjectRoot "C:\Users\User\Desktop\hwadam-mini-pc-one-click-package"
if errorlevel 1 (
  echo.
  echo Update failed. Please send the last error message.
  pause
  exit /b 1
)

echo.
echo Update and health check completed.
pause
