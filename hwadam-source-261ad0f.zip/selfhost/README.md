# 미니PC 실행 방법

이 구성은 별도 유료 서버 없이 미니PC에서 사이트, SQLite DB, 업로드 이미지를 함께 실행합니다.

## 최초 1회

```bash
git clone https://github.com/FlashStudio-KR/hwadam.git
cd hwadam
npm ci
cp selfhost/.env.example selfhost/.env
nano selfhost/.env
npm run build
npm install -g pm2
pm2 start selfhost/ecosystem.config.cjs
pm2 save
pm2 startup
```

`pm2 startup`이 출력하는 마지막 명령도 한 번 실행해야 미니PC 재부팅 뒤 자동으로 다시 켜집니다.

## 개발 PC 수동 배포 (권장)

클라이언트 미니PC에는 GitHub 계정이나 개인 토큰을 저장하지 않습니다. 개발 PC에만 있는 배포 전용 키로 HTTPS 요청을 서명해 배포 파일을 전송합니다. 미니PC는 서명과 5분 이내 요청만 확인하고, SQLite DB·업로드 이미지·`.env`는 그대로 유지합니다.

미니PC 최초 설치가 끝난 뒤, 개발 PC의 프로젝트 폴더에서 아래 한 줄만 실행하면 현재 Git `HEAD` 버전이 배포됩니다.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File selfhost\send-manual-deploy.ps1
```

배포 요청이 수락되면 미니PC가 자체적으로 `npm ci`, 빌드, PM2 재시작을 진행합니다. 완료까지는 보통 수 분이 걸리며, 그동안 기존 사이트는 계속 열립니다.

## GitHub Actions 수동 배포 (선택)

클라이언트 미니PC에는 GitHub 계정이나 개인 토큰을 저장하지 않습니다. GitHub의 **Actions → Deploy Hwadam to Mini PC → Run workflow**를 실행할 때만, GitHub가 자체 서명한 일회용 인증서로 배포 ZIP을 전송합니다. 수신기는 `FlashStudio-KR/hwadam`의 `main` 브랜치에서 수동 실행한 배포만 허용합니다.

### 미니PC 최초 1회 설치

개발자가 전달한 `hwadam-manual-deploy-bootstrap.zip`의 내용을 현재 사이트 폴더에 덮어쓴 뒤, `INSTALL-MANUAL-DEPLOY.cmd`를 더블클릭합니다. 설치기는 수신기와 Caddy 경로를 설정하고 PM2에 저장합니다. 기존 `.env`, SQLite DB, 업로드 이미지, 사이트는 유지됩니다.

설치 후 아래 두 가지가 확인되면 준비 완료입니다.

```powershell
pm2.cmd status
curl.exe -I http://127.0.0.1:3000
```

`hwadam-site`와 `hwadam-deploy-agent`가 `online`, 사이트 요청이 `200 OK`이면 정상입니다.

### 이후 배포

GitHub 저장소에서 **Actions → Deploy Hwadam to Mini PC → Run workflow → Run workflow**만 누르면 됩니다. 배포 완료까지는 보통 빌드 시간을 포함해 수 분이 걸리며, 그동안 기존 사이트는 계속 열립니다.

## GitHub 자동 배포 — GitHub 로그인 방식 (선택, 최초 1회)

조직 승인이나 별도 토큰 없이, 미니PC에서 사용하는 GitHub 계정으로 로그인해 자동 배포할 수 있습니다. 이 방식은 로그인한 계정이 `FlashStudio-KR/hwadam`을 읽을 수 있을 때만 동작하며, 접근 권한은 Windows 사용자 프로필에만 보관됩니다.

미니PC의 사이트 폴더에서 아래 순서대로 실행하세요.

```powershell
winget install --id GitHub.cli
```

설치가 끝나면 PowerShell을 한 번 닫았다가 다시 열고, 사이트 폴더에서 아래 명령을 차례로 실행하세요.

```powershell
gh auth login
gh auth setup-git
$repo='FlashStudio-KR/hwadam'; $tmp=Join-Path $env:TEMP 'hwadam-auto-deploy-installer'; Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue; gh repo clone $repo $tmp -- --depth 1; powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$tmp\selfhost\install-git-auto-deploy.ps1" -ProjectRoot (Get-Location).Path
```

`gh auth login`에서는 `GitHub.com` → `HTTPS` → `Login with a web browser`를 차례로 고르고, 표시되는 일회용 코드를 브라우저에 입력해 로그인합니다. 설치가 끝나면 GitHub `main` 브랜치에 푸시한 변경이 최대 5분 안에 미니PC에 반영됩니다.

## GitHub 자동 배포 — 읽기 전용 토큰 방식 (선택, 최초 1회)

비공개 저장소이므로 먼저 GitHub의 **fine-grained personal access token**을 만들고, `Contents: Read-only` 권한을 `FlashStudio-KR/hwadam` 저장소에만 부여하세요. 발급한 토큰을 미니PC의 `selfhost/.env`에 아래처럼 입력합니다. SQLite DB, 업로드 이미지, 기존 환경값, `Caddyfile`은 유지됩니다.

```txt
GITHUB_DEPLOY_TOKEN=발급한_읽기전용_토큰
```

그다음 아래 두 줄을 미니PC의 사이트 폴더에서 실행하면, 이후 GitHub `main` 브랜치에 푸시된 변경 사항을 5분 이내에 자동으로 내려받아 빌드·재시작합니다.

```powershell
curl.exe -L --fail https://raw.githubusercontent.com/FlashStudio-KR/hwadam/main/selfhost/install-auto-deploy.ps1 -o selfhost\install-auto-deploy.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File selfhost\install-auto-deploy.ps1
```

PM2가 `selfhost/.env`를 자동으로 읽습니다. 전달용 압축 파일에는 설정된 `.env`가 포함될 수 있으므로, 그 경우에는 위의 `cp`와 `nano` 단계 없이 그대로 실행하면 됩니다.

## 운영 명령

```bash
pm2 status
pm2 logs hwadam-site
pm2 restart hwadam-site
```

## 데이터 위치

`LOCAL_DATA_DIR` 아래에 다음 항목이 저장됩니다.

- `hwadam.sqlite`: 견적 문의, 단가, 사이트 문구
- `media/`: 관리자에서 올린 이미지

이 폴더 전체를 매일 외장 저장장치나 별도 백업 공간에 복사하세요. 기존 Cloudflare 데이터는 미니PC 연결 직전에 별도로 내보내 이 SQLite DB로 옮깁니다.

## 외부 공개

미니PC가 사이트를 실행해도 외부에서 접속하려면 도메인을 미니PC로 연결해야 합니다. 공인 IP가 있으면 HTTPS 역방향 프록시와 공유기 포트 설정을, 공인 IP가 없으면 무료 터널 서비스를 사용합니다. DB 포트는 외부에 열지 않습니다.
