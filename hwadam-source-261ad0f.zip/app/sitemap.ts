import type { MetadataRoute } from "next";
import { getSiteOrigin } from "../lib/site-origin";

const portfolioSlugs = [
  "restaurant-space",
  "commercial-lounge",
  "premium-store",
  "wood-finish-space",
  "bright-living-space",
  "alley-commercial-space",
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteOrigin = await getSiteOrigin();

  return [
    { url: siteOrigin, changeFrequency: "weekly", priority: 1 },
    { url: `${siteOrigin}/portfolio`, changeFrequency: "weekly", priority: 0.9 },
    { url: `${siteOrigin}/process`, changeFrequency: "monthly", priority: 0.8 },
    { url: `${siteOrigin}/location`, changeFrequency: "monthly", priority: 0.8 },
    ...portfolioSlugs.map((slug) => ({
      url: `${siteOrigin}/portfolio/${slug}`,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
  ];
}
