import {
  getSiteMediaObject,
  removeSiteMedia,
  replaceSiteMedia,
} from "../../../../db/repositories";
import { getAuthorizedAdministrator } from "../../../../lib/admin-server";
import { getMediaSlot, isManagedMediaSlot, isPortfolioMediaSlot } from "../../../../lib/media";

export const dynamic = "force-dynamic";

const ALLOWED_IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/avif"]);
const MAX_IMAGE_SIZE = 12 * 1024 * 1024;
const NEW_PORTFOLIO_COVER_FALLBACK = "/images/inspiration/restaurant-sunlight.jpg";

function fallbackResponse(request: Request, fallback: string) {
  return new Response(null, {
    status: 307,
    headers: {
      Location: new URL(fallback, request.url).toString(),
      "Cache-Control": "no-store",
    },
  });
}

export async function GET(request: Request, { params }: { params: Promise<{ slot: string }> }) {
  const { slot: slotId } = await params;
  const slot = getMediaSlot(slotId);
  if (!slot && !isPortfolioMediaSlot(slotId)) return new Response("Not found", { status: 404 });

  try {
    const stored = await getSiteMediaObject(slotId);
    if (!stored) {
      if (!slot && slotId.endsWith("-cover")) return fallbackResponse(request, NEW_PORTFOLIO_COVER_FALLBACK);
      if (!slot) return new Response("Not found", { status: 404 });
      return fallbackResponse(request, slot.fallback);
    }
    return new Response(stored.object.body, {
      headers: {
        "Content-Type": stored.media.contentType,
        "Content-Length": String(stored.media.size),
        ETag: stored.object.httpEtag,
        "Cache-Control": "public, max-age=0, must-revalidate",
        "Last-Modified": stored.media.updatedAt,
      },
    });
  } catch {
    if (slot) return fallbackResponse(request, slot.fallback);
    if (slotId.endsWith("-cover")) return fallbackResponse(request, NEW_PORTFOLIO_COVER_FALLBACK);
    return new Response("Not found", { status: 404 });
  }
}

export async function POST(request: Request, { params }: { params: Promise<{ slot: string }> }) {
  const administrator = await getAuthorizedAdministrator(request);
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  try {
    const { slot: slotId } = await params;
    if (!isManagedMediaSlot(slotId)) throw new Error("유효한 이미지 영역이 아닙니다.");
    const formData = await request.formData();
    const image = formData.get("image");
    if (!(image instanceof File)) throw new Error("교체할 이미지를 선택해 주세요.");
    if (!ALLOWED_IMAGE_TYPES.has(image.type)) throw new Error("JPG, PNG, WEBP, AVIF 이미지만 업로드할 수 있습니다.");
    if (image.size <= 0 || image.size > MAX_IMAGE_SIZE) throw new Error("이미지는 12MB 이하로 업로드해 주세요.");
    const media = await replaceSiteMedia(slotId, image, administrator.userId);
    return Response.json({ media });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "이미지를 교체하지 못했습니다." }, { status: 400 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ slot: string }> }) {
  const administrator = await getAuthorizedAdministrator(request);
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  try {
    const { slot: slotId } = await params;
    if (!isManagedMediaSlot(slotId)) throw new Error("유효한 이미지 영역이 아닙니다.");
    await removeSiteMedia(slotId);
    return Response.json({ slotId, reset: true });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "기본 이미지로 되돌리지 못했습니다." }, { status: 400 });
  }
}
