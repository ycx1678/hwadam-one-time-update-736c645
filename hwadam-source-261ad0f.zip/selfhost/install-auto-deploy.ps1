$ErrorActionPreference = "Stop"

$autoDeployPath = Join-Path $PSScriptRoot "auto-deploy.ps1"
$repository = "FlashStudio-KR/hwadam"
$environmentFile = Join-Path $PSScriptRoot ".env"
$tokenLine = if (Test-Path -LiteralPath $environmentFile) { Get-Content -LiteralPath $environmentFile | Where-Object { $_ -match '^GITHUB_DEPLOY_TOKEN=' } | Select-Object -First 1 } else { $null }
$deployToken = if ($tokenLine) { ($tokenLine -replace '^GITHUB_DEPLOY_TOKEN=', '').Trim().Trim('"').Trim("'") } else { "" }
if (-not $deployToken) { throw "selfhost/.env에 GITHUB_DEPLOY_TOKEN을 먼저 입력해 주세요." }
$headers = @{ "User-Agent" = "Hwadam-MiniPC-AutoDeploy"; "Authorization" = "Bearer $deployToken"; "Accept" = "application/vnd.github+json" }

Write-Host "자동 배포 도구를 설치합니다."
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/$repository/main/selfhost/auto-deploy.ps1" -Headers $headers -OutFile $autoDeployPath

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $autoDeployPath -Force
if ($LASTEXITCODE -ne 0) { throw "첫 배포에 실패했습니다." }

$taskName = "Hwadam Auto Deploy"
$taskAction = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$autoDeployPath`""
& schtasks.exe /Create /TN $taskName /SC MINUTE /MO 5 /TR $taskAction /F | Out-Null
if ($LASTEXITCODE -ne 0) { throw "5분 자동 배포 작업 등록에 실패했습니다." }

Write-Host "설치 완료: GitHub에 푸시하면 최대 5분 안에 미니PC가 자동으로 반영합니다."
