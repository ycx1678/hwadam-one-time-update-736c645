import type { Metadata } from "next";
import {
  SITE_DESCRIPTION,
  SITE_INSTAGRAM_URL,
  SITE_KEYWORDS,
  SITE_NAME,
  SITE_TITLE,
} from "../lib/site";
import { getRuntimeValue } from "../lib/runtime-env";
import { getSiteOrigin } from "../lib/site-origin";
import "./globals.css";

const NAVER_SITE_VERIFICATION = "bcee79b1c333790b5f59b43bea48734b3d57993c";
const GOOGLE_SITE_VERIFICATION = "Ep8Ehm53hOi0xbqhZBml0W1cWq7mBJq2uYj8p7G8g38";

export async function generateMetadata(): Promise<Metadata> {
  const [origin, naverSiteVerification, googleSiteVerification] = await Promise.all([
    getSiteOrigin(),
    getRuntimeValue("NAVER_SITE_VERIFICATION"),
    getRuntimeValue("GOOGLE_SITE_VERIFICATION"),
  ]);

  return {
    metadataBase: new URL(origin),
    title: {
      default: SITE_TITLE,
      template: `%s | ${SITE_NAME}`,
    },
    description: SITE_DESCRIPTION,
    keywords: [...SITE_KEYWORDS],
    alternates: { canonical: "/" },
    robots: {
      index: true,
      follow: true,
      googleBot: { index: true, follow: true },
    },
    verification: {
      google: googleSiteVerification || GOOGLE_SITE_VERIFICATION,
      other: { "naver-site-verification": naverSiteVerification || NAVER_SITE_VERIFICATION },
    },
    icons: {
      icon: "/images/logo.jpg",
      shortcut: "/images/logo.jpg",
    },
    openGraph: {
      title: "공간의 쓰임을 이해하는 인테리어 | 화담아이디",
      description: "상업공간 인테리어 예상 견적을 간편하게 확인해 보세요.",
      url: origin,
      siteName: SITE_NAME,
      locale: "ko_KR",
      type: "website",
      images: [{ url: `${origin}/og.png`, width: 1536, height: 1024, alt: "화담아이디 상업 인테리어 간편 견적" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "공간의 쓰임을 이해하는 인테리어 | 화담아이디",
      description: "상업공간 인테리어 예상 견적을 간편하게 확인해 보세요.",
      images: [`${origin}/og.png`],
    },
  };
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const origin = await getSiteOrigin();
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": `${origin}/#website`,
        url: origin,
        name: SITE_NAME,
        description: SITE_DESCRIPTION,
        inLanguage: "ko-KR",
      },
      {
        "@type": ["ProfessionalService", "Organization"],
        "@id": `${origin}/#business`,
        name: SITE_NAME,
        url: origin,
        description: SITE_DESCRIPTION,
        sameAs: [SITE_INSTAGRAM_URL],
        areaServed: ["서울", "경기"],
        serviceType: ["상업 인테리어", "카페 인테리어", "음식점 인테리어", "매장 인테리어"],
      },
    ],
  };

  return (
    <html lang="ko">
      <head>
        <link rel="preconnect" href="https://cdn.jsdelivr.net" />
        <link
          rel="stylesheet"
          crossOrigin="anonymous"
          href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(structuredData).replace(/</g, "\\u003c"),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
