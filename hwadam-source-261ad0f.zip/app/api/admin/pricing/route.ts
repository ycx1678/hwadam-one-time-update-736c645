import { getActivePricingCatalog, savePricingCatalog } from "../../../../db/repositories";
import type { PricingAdminUpdate } from "../../../../lib/admin.types";
import { getAuthorizedAdministrator } from "../../../../lib/admin-server";
import { applyPricingAdminUpdate } from "../../../../lib/pricing-admin";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request) {
  const administrator = await getAuthorizedAdministrator(request);
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  try {
    const payload = (await request.json()) as PricingAdminUpdate;
    const currentCatalog = await getActivePricingCatalog();
    const catalog = applyPricingAdminUpdate(currentCatalog, payload);
    await savePricingCatalog(catalog, administrator.userId);
    return Response.json({ catalog });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "단가를 저장하지 못했습니다." },
      { status: 400 },
    );
  }
}
