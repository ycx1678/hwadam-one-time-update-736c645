const path = require("node:path");
const fs = require("node:fs");

const projectRoot = path.resolve(__dirname, "..");
const environmentFile = path.join(__dirname, ".env");

// Node.js 22가 전달본의 설정 파일을 직접 읽게 하므로,
// PM2 실행 전에 별도 환경변수 명령을 입력할 필요가 없습니다.
if (fs.existsSync(environmentFile)) {
  process.loadEnvFile(environmentFile);
}

const localDataDirectory = process.env.LOCAL_DATA_DIR
  ? path.resolve(projectRoot, process.env.LOCAL_DATA_DIR)
  : path.join(projectRoot, "data");
const deployAgentEnabled = process.env.HWADAM_DEPLOY_AGENT === "1";
const deployAgentPort = Number.parseInt(process.env.HWADAM_DEPLOY_AGENT_PORT || "3010", 10);
// PM2 재시작 뒤에도 .env의 알림톡 값을 확실히 전달합니다.
const solapiEnvironment = Object.fromEntries([
  "SOLAPI_API_KEY",
  "SOLAPI_API_SECRET",
  "SOLAPI_SENDER",
  "SOLAPI_KAKAO_CHANNEL_ID",
  "SOLAPI_CUSTOMER_TEMPLATE_ID",
  "SOLAPI_ADMIN_TEMPLATE_ID",
  "SOLAPI_ADMIN_PHONE",
].flatMap((key) => process.env[key] ? [[key, process.env[key]]] : []));

module.exports = {
  apps: [
    {
      name: "hwadam-site",
      cwd: projectRoot,
      // cmd.exe/npm.cmd를 PM2가 직접 실행하면 재시작마다 콘솔 창이 앞으로 뜰 수 있습니다.
      // Windows에서는 Vinext CLI를 Node로 직접 실행해 화면을 가리지 않게 합니다.
      script: process.platform === "win32" ? process.execPath : "npm",
      args: process.platform === "win32" ? "node_modules/vinext/dist/cli.js start" : "run start",
      interpreter: process.platform === "win32" ? "none" : undefined,
      autorestart: true,
      max_memory_restart: "500M",
      env: {
        NODE_ENV: "production",
        HWADAM_STORAGE: "local",
        LOCAL_DATA_DIR: localDataDirectory,
        ...solapiEnvironment,
      },
    },
    ...(deployAgentEnabled
      ? [
          {
            name: "hwadam-deploy-agent",
            cwd: projectRoot,
            script: path.join(__dirname, "deploy-agent.cjs"),
            autorestart: true,
            max_memory_restart: "250M",
            env: {
              NODE_ENV: "production",
              HWADAM_DEPLOY_AGENT_PORT: String(deployAgentPort),
              HWADAM_DEPLOY_SECRET: process.env.HWADAM_DEPLOY_SECRET || "",
            },
          },
        ]
      : []),
  ],
};
