CREATE TABLE `site_media` (
	`slot_id` text PRIMARY KEY NOT NULL,
	`object_key` text NOT NULL,
	`content_type` text NOT NULL,
	`original_name` text NOT NULL,
	`size` integer NOT NULL,
	`updated_by` text NOT NULL,
	`updated_at` text NOT NULL
);
