import type { PricingCatalog } from "./estimate.types";

/**
 * 관리자 기능이 연결되기 전 사용하는 초기 단가표입니다.
 * 이후 API에서 같은 PricingCatalog 형태를 내려주면 화면과 계산 로직을
 * 변경하지 않고 관리자 단가를 적용할 수 있습니다.
 */
export const DEFAULT_PRICING_CATALOG: PricingCatalog = {
  id: "hwadam-commercial-interior",
  version: "2026.08.1",
  effectiveFrom: "2026-08-01",
  currency: "KRW",
  minimumArea: 3,
  maximumArea: 500,
  estimateRangeRate: 0.1,
  managementCostPerPyeong: 50_000,
  // 기존 견적 금액을 유지하고, 필요할 때만 관리자에서 별도로 설정합니다.
  businessMarginRate: 0,
  spaceTypes: [
    { id: "cafe", label: "카페", multiplier: 1.1, description: "바·설비가 포함된 공간" },
    { id: "restaurant", label: "음식점", multiplier: 1.2, description: "주방·배기 설비 중심" },
    { id: "office", label: "사무실", multiplier: 0.95, description: "업무 효율 중심 공간" },
    { id: "shop", label: "매장", multiplier: 1, description: "판매·서비스 공간" },
    { id: "other", label: "기타", multiplier: 1, description: "그 외 상업 공간" },
  ],
  processGroups: [
    {
      id: "demolition",
      label: "철거",
      description: "기존 마감과 구조물을 정리합니다.",
      options: [
        { id: "partial", label: "부분 철거", amount: 80_000, mode: "perPyeong" },
        { id: "full", label: "전체 철거", amount: 180_000, mode: "perPyeong" },
      ],
    },
    {
      id: "paint",
      label: "페인트",
      description: "벽과 천장의 도장 범위를 선택합니다.",
      options: [
        { id: "wall", label: "벽만", amount: 90_000, mode: "perPyeong" },
        { id: "ceiling", label: "천장만", amount: 60_000, mode: "perPyeong" },
        { id: "all", label: "벽 + 천장", amount: 140_000, mode: "perPyeong" },
      ],
    },
    {
      id: "floor",
      label: "바닥",
      description: "공간 성격에 맞는 마감재를 선택합니다.",
      options: [
        { id: "deco", label: "데코타일", amount: 100_000, mode: "perPyeong" },
        { id: "wood", label: "강마루", amount: 170_000, mode: "perPyeong" },
        { id: "porcelain", label: "포세린타일", amount: 260_000, mode: "perPyeong" },
      ],
    },
    {
      id: "carpentry",
      label: "목공",
      description: "천장·벽체와 공간 구조를 만듭니다.",
      options: [
        { id: "basic", label: "기본 목공", amount: 180_000, mode: "perPyeong" },
        { id: "extended", label: "확장 목공", amount: 320_000, mode: "perPyeong" },
      ],
    },
    {
      id: "electric",
      label: "전기·조명",
      description: "배선과 조명 계획의 범위를 선택합니다.",
      options: [
        { id: "basic", label: "기본 전기", amount: 120_000, mode: "perPyeong" },
        { id: "full", label: "전체 전기", amount: 220_000, mode: "perPyeong" },
      ],
    },
    {
      id: "plumbing",
      label: "설비",
      description: "급·배수와 주방 설비 범위를 선택합니다.",
      options: [
        { id: "basic", label: "기본 설비", amount: 150_000, mode: "perPyeong" },
        { id: "intensive", label: "집중 설비", amount: 300_000, mode: "perPyeong" },
      ],
    },
    {
      id: "furniture",
      label: "가구",
      description: "수납과 제작 가구 수준을 선택합니다.",
      options: [
        { id: "basic", label: "기본 가구", amount: 180_000, mode: "perPyeong" },
        { id: "custom", label: "맞춤 가구", amount: 400_000, mode: "perPyeong" },
      ],
    },
    {
      id: "signage",
      label: "사인",
      description: "브랜드를 보여주는 내·외부 사인입니다.",
      options: [
        { id: "inside", label: "내부 사인", amount: 1_500_000, mode: "fixed" },
        { id: "all", label: "내·외부 사인", amount: 3_000_000, mode: "fixed" },
      ],
    },
  ],
};
