import type { Metadata } from "next";
import PortfolioPageContent from "../../components/PortfolioPageContent";

export const metadata: Metadata = {
  title: "시공 포트폴리오",
  description: "화담아이디가 완성한 음식점, 카페, 매장, 상업공간 인테리어 시공 사례를 확인하세요.",
  alternates: { canonical: "/portfolio" },
  openGraph: {
    title: "시공 포트폴리오 | 화담아이디",
    description: "현장에서 완성한 화담아이디의 상업공간 인테리어 사례입니다.",
    url: "/portfolio",
  },
};

export default function PortfolioPage() {
  return <PortfolioPageContent />;
}
