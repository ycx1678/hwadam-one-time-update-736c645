export const MEDIA_SECTIONS = [
  {
    id: "home",
    label: "메인 화면",
    description: "첫 화면과 전체 메뉴에 노출되는 이미지입니다.",
    location: "메인 페이지 · 첫 화면과 전체 메뉴",
    href: "/#처음",
  },
  {
    id: "portfolio",
    label: "포트폴리오",
    description: "포트폴리오 페이지의 시공 사례 이미지입니다.",
    location: "포트폴리오 페이지 · 이미지 카드 목록",
    href: "/portfolio",
  },
  {
    id: "process",
    label: "진행 과정",
    description: "진행 과정 페이지의 단계별 오른쪽 이미지입니다.",
    location: "진행 과정 페이지 · 각 단계 오른쪽 이미지",
    href: "/process",
  },
] as const;

export const MEDIA_SLOTS = [
  { id: "home-hero-main-hq", section: "home", label: "메인 대표 이미지", location: "메인 페이지 · 포트폴리오로 연결되는 대표 사진", description: "가로형과 세로형 모두 원본 비율을 유지하며, 클릭하면 음식점 공간 포트폴리오 상세 페이지로 이동하는 메인 대표 사진입니다.", href: "/portfolio/restaurant-space", fallback: "/images/inspiration/restaurant-sunlight.jpg", ratio: "responsive" },
  { id: "menu-feature-hq", section: "home", label: "전체 메뉴 이미지", location: "전체 메뉴 · 왼쪽 대형 이미지", description: "오른쪽 상단 메뉴 버튼을 눌렀을 때 왼쪽에 보이는 사진입니다.", href: "/", fallback: "/images/inspiration/restaurant-mirrored.jpg", ratio: "portrait" },
  { id: "portfolio-1-hq", section: "portfolio", label: "시공 사례 1 이미지", location: "포트폴리오 · 첫 번째 가로 카드", description: "포트폴리오 목록에서 첫 번째로 보이는 가로형 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/restaurant-sunlight.jpg", ratio: "landscape" },
  { id: "portfolio-2-hq", section: "portfolio", label: "시공 사례 2 이미지", location: "포트폴리오 · 두 번째 세로 카드", description: "포트폴리오 목록에서 두 번째로 보이는 세로형 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/boutique.jpg", ratio: "portrait" },
  { id: "portfolio-3-hq", section: "portfolio", label: "시공 사례 3 이미지", location: "포트폴리오 · 세 번째 정사각 카드", description: "포트폴리오 목록의 세 번째 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/retail-moma.jpg", ratio: "square" },
  { id: "portfolio-4-hq", section: "portfolio", label: "시공 사례 4 이미지", location: "포트폴리오 · 네 번째 정사각 카드", description: "포트폴리오 목록의 네 번째 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/restaurant-bar.jpg", ratio: "square" },
  { id: "portfolio-5-hq", section: "portfolio", label: "시공 사례 5 이미지", location: "포트폴리오 · 다섯 번째 세로 카드", description: "포트폴리오 목록의 다섯 번째 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/office-warm.jpg", ratio: "portrait" },
  { id: "portfolio-6-hq", section: "portfolio", label: "시공 사례 6 이미지", location: "포트폴리오 · 여섯 번째 가로 카드", description: "포트폴리오 목록의 여섯 번째 시공 사진입니다.", href: "/portfolio", fallback: "/images/inspiration/retail-concrete.jpg", ratio: "landscape" },
  { id: "process-step-1-hq", section: "process", label: "진행 1단계 이미지", location: "진행 과정 · 1단계 오른쪽 이미지", description: "진행 과정의 첫 번째 단계 옆에 보이는 사진입니다.", href: "/process", fallback: "/images/inspiration/retail-moma.jpg", ratio: "landscape" },
  { id: "process-step-2-hq", section: "process", label: "진행 2단계 이미지", location: "진행 과정 · 2단계 오른쪽 이미지", description: "진행 과정의 두 번째 단계 옆에 보이는 사진입니다.", href: "/process", fallback: "/images/inspiration/retail-concrete.jpg", ratio: "landscape" },
  { id: "process-step-3-hq", section: "process", label: "진행 3단계 이미지", location: "진행 과정 · 3단계 오른쪽 이미지", description: "진행 과정의 세 번째 단계 옆에 보이는 사진입니다.", href: "/process", fallback: "/images/inspiration/restaurant-sunlight.jpg", ratio: "landscape" },
  { id: "process-step-4-hq", section: "process", label: "진행 4단계 이미지", location: "진행 과정 · 4단계 오른쪽 이미지", description: "진행 과정의 네 번째 단계 옆에 보이는 사진입니다.", href: "/process", fallback: "/images/inspiration/restaurant-mirrored.jpg", ratio: "landscape" },
  { id: "process-step-5-hq", section: "process", label: "진행 5단계 이미지", location: "진행 과정 · 5단계 오른쪽 이미지", description: "진행 과정의 다섯 번째 단계 옆에 보이는 사진입니다.", href: "/process", fallback: "/images/inspiration/office-warm.jpg", ratio: "landscape" },
] as const;

export type MediaSlotId = (typeof MEDIA_SLOTS)[number]["id"];

const PORTFOLIO_MEDIA_SLOT = /^portfolio-project-[a-z0-9-]{6,96}-(?:cover|gallery-[a-z0-9-]{6,96})$/;

export function getMediaSlot(id: string) {
  return MEDIA_SLOTS.find((slot) => slot.id === id);
}

export function isPortfolioMediaSlot(id: string) {
  return PORTFOLIO_MEDIA_SLOT.test(id);
}

export function isManagedMediaSlot(id: string) {
  return Boolean(getMediaSlot(id)) || isPortfolioMediaSlot(id);
}

export function portfolioCoverSlot(projectId: string) {
  return `portfolio-project-${projectId}-cover`;
}

export function portfolioGallerySlot(projectId: string, imageId: string) {
  return `portfolio-project-${projectId}-gallery-${imageId}`;
}

export function mediaUrl(id: string) {
  return `/api/media/${id}`;
}
