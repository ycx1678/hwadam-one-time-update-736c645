param(
  [string]$DeployUrl = "https://hwadam.flashstudio.kr/__hwadam-deploy"
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$secretFile = Join-Path $PSScriptRoot ".manual-deploy-sender.env"

function Get-DeploySecret {
  if ($env:HWADAM_DEPLOY_SECRET) { return $env:HWADAM_DEPLOY_SECRET.Trim() }
  if (-not (Test-Path -LiteralPath $secretFile)) { return "" }
  $line = Get-Content -LiteralPath $secretFile | Where-Object { $_ -match '^HWADAM_DEPLOY_SECRET=' } | Select-Object -First 1
  if (-not $line) { return "" }
  return ($line -replace '^HWADAM_DEPLOY_SECRET=', '').Trim()
}

$deploySecret = Get-DeploySecret
if ($deploySecret.Length -lt 40) { throw "수동 배포 키를 찾지 못했습니다." }

$timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString()
$hmac = [System.Security.Cryptography.HMACSHA256]::new([System.Text.Encoding]::UTF8.GetBytes($deploySecret))
try {
  $signature = ([System.BitConverter]::ToString($hmac.ComputeHash([System.Text.Encoding]::UTF8.GetBytes("$timestamp.status")))).Replace("-", "").ToLowerInvariant()
} finally {
  $hmac.Dispose()
}

$response = Invoke-WebRequest -UseBasicParsing -Method Post -Uri $DeployUrl -Headers @{
  "X-Hwadam-Timestamp" = $timestamp
  "X-Hwadam-Signature" = "sha256=$signature"
  "X-Hwadam-Status" = "1"
}
Write-Output $response.Content
