import { saveSiteContent } from "../../../../db/repositories";
import { getAuthorizedAdministrator } from "../../../../lib/admin-server";
import { normalizeSiteContent } from "../../../../lib/site-content";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request) {
  const administrator = await getAuthorizedAdministrator(request);
  if (!administrator) return Response.json({ error: "관리자 권한이 필요합니다." }, { status: 403 });

  try {
    const content = normalizeSiteContent(await request.json());
    await saveSiteContent(content, administrator.userId);
    return Response.json({ content });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "사이트 문구를 저장하지 못했습니다." }, { status: 400 });
  }
}
