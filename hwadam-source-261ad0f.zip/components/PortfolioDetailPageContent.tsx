import SiteFrame from "./SiteFrame";
import { mediaUrl } from "../lib/media";
import type { PortfolioProjectContent } from "../lib/site-content";

export default function PortfolioDetailPageContent({ project }: Readonly<{ project: PortfolioProjectContent }>) {
  return (
    <SiteFrame current="portfolio">
      <main className="subpage portfolio-detail-page">
        <article className="portfolio-post">
          <header className="portfolio-post-header">
            <a href="/portfolio" className="portfolio-back">← 목록으로</a>
            <p>{project.type}</p>
            <h1>{project.title}</h1>
            <span>{project.category}</span>
          </header>

          <figure className="portfolio-post-hero">
            <img src={mediaUrl(project.coverSlot)} alt={`${project.title} 인테리어`} />
          </figure>

          <div className="portfolio-post-content">
            <dl className="portfolio-post-meta">
              <div><dt>프로젝트</dt><dd>{project.type}</dd></div>
              <div><dt>진행 범위</dt><dd>{project.scope}</dd></div>
              <div><dt>작업 키워드</dt><dd>{project.category}</dd></div>
            </dl>

            <div className="portfolio-post-body">
              <section>
                <h2>프로젝트 개요</h2>
                <p>{project.summary}</p>
              </section>
              <section>
                <h2>디자인 노트</h2>
                <p>{project.designNote}</p>
              </section>
            </div>
          </div>

          {project.gallerySlots.length > 0 && (
            <section className="portfolio-post-gallery" aria-label={`${project.title} 상세 사진`}>
              {project.gallerySlots.map((slot, index) => (
                <figure key={slot}>
                  <img src={mediaUrl(slot)} alt={`${project.title} 상세 사진 ${index + 1}`} loading="lazy" />
                </figure>
              ))}
            </section>
          )}

          <footer className="portfolio-post-footer">
            <a href="/portfolio">포트폴리오 목록</a>
          </footer>
        </article>
      </main>
    </SiteFrame>
  );
}
