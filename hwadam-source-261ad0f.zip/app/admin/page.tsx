import type { Metadata } from "next";
import AdminDashboard from "../../components/AdminDashboard";
import AdminLogin from "../../components/AdminLogin";
import { getAuthorizedAdministrator } from "../../lib/admin-server";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "관리자",
  robots: { index: false, follow: false },
};

export default async function AdminPage({ searchParams }: Readonly<{ searchParams: Promise<{ error?: string }> }>) {
  const administrator = await getAuthorizedAdministrator();
  if (!administrator) return <AdminLogin error={(await searchParams).error} />;

  const { getActivePricingCatalog, getSiteContent, listEstimateInquiries } = await import("../../db/repositories");

  const [catalog, inquiries, content] = await Promise.all([
    getActivePricingCatalog(),
    listEstimateInquiries(),
    getSiteContent(),
  ]);

  return (
    <AdminDashboard
      initialData={{ catalog, inquiries, content }}
      signOutHref="/api/admin/logout"
    />
  );
}
