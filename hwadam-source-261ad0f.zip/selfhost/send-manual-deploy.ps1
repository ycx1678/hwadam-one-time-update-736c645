param(
  [string]$DeployUrl = "https://hwadam.flashstudio.kr/__hwadam-deploy",
  [string]$Revision = "HEAD"
)

$ErrorActionPreference = "Stop"
$appRoot = Split-Path -Parent $PSScriptRoot
$secretFile = Join-Path $PSScriptRoot ".manual-deploy-sender.env"

function Get-DeploySecret {
  if ($env:HWADAM_DEPLOY_SECRET) { return $env:HWADAM_DEPLOY_SECRET.Trim() }
  if (-not (Test-Path -LiteralPath $secretFile)) { return "" }
  $line = Get-Content -LiteralPath $secretFile | Where-Object { $_ -match '^HWADAM_DEPLOY_SECRET=' } | Select-Object -First 1
  if (-not $line) { return "" }
  return ($line -replace '^HWADAM_DEPLOY_SECRET=', '').Trim()
}

$deploySecret = Get-DeploySecret
if ($deploySecret.Length -lt 40) { throw "수동 배포 키를 찾지 못했습니다." }

$temporaryArchive = Join-Path $env:TEMP "hwadam-manual-send-$([guid]::NewGuid().ToString('N')).zip"
try {
  Push-Location $appRoot
  try {
    & git.exe archive --format=zip --output $temporaryArchive $Revision
    if ($LASTEXITCODE -ne 0) { throw "배포할 Git 버전을 압축하지 못했습니다." }
  } finally {
    Pop-Location
  }

  $archive = [System.IO.File]::ReadAllBytes($temporaryArchive)
  $timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString()
  $prefix = [System.Text.Encoding]::UTF8.GetBytes("$timestamp.")
  $signedPayload = New-Object byte[] ($prefix.Length + $archive.Length)
  [Array]::Copy($prefix, 0, $signedPayload, 0, $prefix.Length)
  [Array]::Copy($archive, 0, $signedPayload, $prefix.Length, $archive.Length)
  $hmac = [System.Security.Cryptography.HMACSHA256]::new([System.Text.Encoding]::UTF8.GetBytes($deploySecret))
  try {
    $signature = ([System.BitConverter]::ToString($hmac.ComputeHash($signedPayload))).Replace("-", "").ToLowerInvariant()
  } finally {
    $hmac.Dispose()
  }

  $response = Invoke-WebRequest -UseBasicParsing -Method Post -Uri $DeployUrl -ContentType "application/zip" -InFile $temporaryArchive -Headers @{
    "X-Hwadam-Timestamp" = $timestamp
    "X-Hwadam-Signature" = "sha256=$signature"
  }
  if ($response.StatusCode -ne 202) { throw "배포 서버가 요청을 수락하지 않았습니다. ($($response.StatusCode))" }
  Write-Host "배포 요청 완료: $($response.Content)"
} finally {
  if ($temporaryArchive -and [System.IO.File]::Exists($temporaryArchive)) {
    [System.IO.File]::Delete($temporaryArchive)
  }
}
