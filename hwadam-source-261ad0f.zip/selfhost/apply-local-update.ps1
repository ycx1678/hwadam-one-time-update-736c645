param(
  [Parameter(Mandatory = $true)]
  [string]$UpdateRoot,
  [Parameter(Mandatory = $true)]
  [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"

$UpdateRoot = (Resolve-Path -LiteralPath $UpdateRoot).Path
$ProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path

if (-not (Test-Path -LiteralPath (Join-Path $UpdateRoot "package.json"))) {
  throw "package.json was not found in the update folder. Extract the entire ZIP first."
}
if (-not (Test-Path -LiteralPath (Join-Path $ProjectRoot "selfhost\.env"))) {
  throw "The existing Mini PC site folder was not found: $ProjectRoot"
}

# A failed detached receiver job can keep the deployment lock forever.
# A locally initiated update explicitly replaces that job, so clear only that
# exact PowerShell process before copying the new source.
$stalledDeployments = @(
  Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" |
    Where-Object { $_.CommandLine -and $_.CommandLine -match "selfhost\\deploy-from-upload\.ps1" }
)
if ($stalledDeployments.Count -gt 0) {
  Write-Host "Stopping an interrupted deployment job."
  foreach ($deployment in $stalledDeployments) {
    Stop-Process -Id $deployment.ProcessId -Force -ErrorAction SilentlyContinue
  }
  Start-Sleep -Seconds 1
}

# Keep the existing data directory, selfhost/.env, and Caddyfile untouched.
# Only replace the application source with the contents of the update package.
$sourceDirectories = @(".openai", "app", "build", "components", "db", "drizzle", "examples", "lib", "public", "selfhost", "tests", "worker")
foreach ($directory in $sourceDirectories) {
  $source = Join-Path $UpdateRoot $directory
  if (-not (Test-Path -LiteralPath $source)) { continue }
  $destination = Join-Path $ProjectRoot $directory
  & robocopy.exe $source $destination /E /NFL /NDL /NJH /NJS /NP | Out-Null
  if ($LASTEXITCODE -gt 7) { throw "Could not copy $directory. (robocopy: $LASTEXITCODE)" }
}

$sourceFiles = @(".gitignore", "drizzle.config.ts", "eslint.config.mjs", "next-env.d.ts", "next.config.ts", "package-lock.json", "package.json", "postcss.config.mjs", "README.md", "tsconfig.json", "vite.config.ts")
foreach ($file in $sourceFiles) {
  $source = Join-Path $UpdateRoot $file
  if (Test-Path -LiteralPath $source) {
    Copy-Item -LiteralPath $source -Destination (Join-Path $ProjectRoot $file) -Force
  }
}

$siteStopped = $false
Push-Location $ProjectRoot
try {
  Write-Host "1/5 Stopping the running site to release locked build files."
  & pm2.cmd stop hwadam-site
  if ($LASTEXITCODE -ne 0) { throw "Could not stop hwadam-site." }
  $siteStopped = $true

  Write-Host "2/5 Installing current dependencies."
  & npm.cmd ci
  if ($LASTEXITCODE -ne 0) { throw "npm ci failed." }

  Write-Host "3/5 Building the site."
  & npm.cmd run build
  if ($LASTEXITCODE -ne 0) { throw "Site build failed." }

  Write-Host "4/5 Restarting the site and deployment receiver."
  & pm2.cmd restart hwadam-site
  if ($LASTEXITCODE -ne 0) { throw "Could not restart hwadam-site." }
  $siteStopped = $false
  & pm2.cmd restart hwadam-deploy-agent
  if ($LASTEXITCODE -ne 0) { throw "Could not restart hwadam-deploy-agent." }
  & pm2.cmd save
  if ($LASTEXITCODE -ne 0) { throw "Could not save the PM2 configuration." }

  Write-Host "5/5 Checking the local site response."
  $health = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:3000/" -TimeoutSec 20
  if ($health.StatusCode -ne 200) { throw "Site health check failed. (HTTP $($health.StatusCode))" }
} catch {
  if ($siteStopped) {
    & pm2.cmd restart hwadam-site | Out-Null
  }
  throw
} finally {
  Pop-Location
}

Write-Host "Complete: the latest site was applied to the Mini PC."
