import { getRuntimeValue } from "./runtime-env";

const DEFAULT_SITE_ORIGIN = "https://hwadamid.com";

function normalizeOrigin(value: string | null) {
  if (!value) return null;

  try {
    const parsed = new URL(value);
    if (parsed.protocol !== "https:" && parsed.protocol !== "http:") return null;
    return parsed.origin;
  } catch {
    return null;
  }
}

/**
 * 검색엔진에 제출하는 대표 도메인입니다.
 * 운영 환경의 SITE_ORIGIN으로 바꿀 수 있고, 기본값은 hwadamid.com입니다.
 */
export async function getSiteOrigin() {
  return normalizeOrigin(await getRuntimeValue("SITE_ORIGIN")) ?? DEFAULT_SITE_ORIGIN;
}

